
  # PharmaShelf Inventory Management

  This is a code bundle for PharmaShelf Inventory Management. The original project is available at https://www.figma.com/design/CAVPqcYPNwYZkxZkmbOLRv/PharmaShelf-Inventory-Management.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  "# pharmaUserInterface" 
