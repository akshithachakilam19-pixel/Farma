# UI Updates for Backend Security Configuration

## Summary of Changes

This document summarizes all UI updates made to align with the Spring Security configuration provided.

---

## 1. Updated Files

### A. `src/app/constants/accessControl.js`
**Changes Made:**
- ✅ Updated `ROLE_MODULE_ACCESS` to match backend endpoint permissions
- ✅ Added `ROLE_ACTION_PERMISSIONS` object for granular CRUD control
- ✅ Added `canPerformAction(role, resource, action)` function
- ✅ Enhanced `normalizeRole()` to properly handle `ROLE_` prefix from Spring Security

**Key Additions:**
```javascript
// Role-specific action permissions aligned with @PreAuthorize annotations
export const ROLE_ACTION_PERMISSIONS = {
  PRODUCT: {
    CREATE: ["ADMINISTRATOR"],
    READ: ["ADMINISTRATOR", "PHARMACIST", "CLINICIAN"],
    UPDATE: ["ADMINISTRATOR", "PHARMACIST"],
    DELETE: ["ADMINISTRATOR", "PHARMACIST"],
  },
  BATCH: {
    CREATE: ["ADMINISTRATOR", "PHARMACIST"],
    READ: ["ADMINISTRATOR", "PHARMACIST", "CLINICIAN"],
    UPDATE: ["ADMINISTRATOR", "PHARMACIST"],
    DELETE: ["ADMINISTRATOR", "PHARMACIST"],
  },
  // ... more resources
};

export const canPerformAction = (role, resource, action) => {
  // Check if role can perform specific action on resource
};
```

### B. `src/app/components/ProductMaster.jsx`
**Changes Made:**
- ✅ Imported `canPerformAction` and `getCurrentUserRole` from accessControl
- ✅ Added role-based permission flags:
  - `canCreateProduct`
  - `canUpdateProduct`
  - `canDeleteProduct`
  - `canCreateBatch`
  - `canUpdateBatch`
  - `canDeleteBatch`
- ✅ Conditionally render "Add Product" button (only for ADMINISTRATOR)
- ✅ Conditionally render "Add Batch" button (only for ADMINISTRATOR, PHARMACIST)
- ✅ Conditionally render Edit/Delete actions in product menu
- ✅ Conditionally render Delete button in batch rows

**UI Changes:**
```jsx
{canCreateProduct && (
  <button onClick={() => setShowAddForm(!showAddForm)}>
    <Plus /> Product
  </button>
)}

{canCreateBatch && (
  <button onClick={() => setShowAddBatchForm(!showAddBatchForm)}>
    <Layers /> Batch
  </button>
)}

{canUpdateProduct && <button>Edit</button>}
{canDeleteProduct && <button>Delete</button>}
```

### C. `src/app/components/Login.jsx`
**Previous Changes (Already Applied):**
- ✅ Updated JWT token extraction to use `extractUserIdFromToken()`
- ✅ Properly handles `userId` claim from JwtUtil
- ✅ Uses `tokenUsername` (decoded.sub) instead of email
- ✅ Enhanced role normalization with Spring Security compatibility

---

## 2. Backend Endpoints Mapping

### Product Operations
| Action | Endpoint | Required Roles | UI Permission |
|--------|----------|----------------|---------------|
| List All | `/pharmaShelf/products/fetchAllProducts` | ADMINISTRATOR, PHARMACIST | READ |
| Get One | `/pharmaShelf/products/fetchByProductId/{id}` | ADMINISTRATOR, PHARMACIST | READ |
| Create | `/pharmaShelf/products/insertProduct` | ADMINISTRATOR | CREATE |
| Update | `/pharmaShelf/products/updateProduct/{id}` | ADMINISTRATOR, PHARMACIST | UPDATE |
| Delete | `/pharmaShelf/products/deleteProduct/{id}` | ADMINISTRATOR, PHARMACIST | DELETE |

### Batch Operations
| Action | Endpoint | Required Roles | UI Permission |
|--------|----------|----------------|---------------|
| List All | `/pharmaShelf/batches/fetchAllBatches` | ADMINISTRATOR, PHARMACIST | READ |
| Get One | `/pharmaShelf/batches/fetchByBatchId/{id}` | ADMINISTRATOR, PHARMACIST | READ |
| By Product | `/pharmaShelf/batches/fetchByProductId/{productId}` | ADMINISTRATOR, PHARMACIST | READ |
| Create | `/pharmaShelf/batches/insertBatch` | ADMINISTRATOR, PHARMACIST | CREATE |
| Update | `/pharmaShelf/batches/updateBatch/{id}` | ADMINISTRATOR, PHARMACIST | UPDATE |
| Delete | `/pharmaShelf/batches/DeleteBatch/{id}` | ADMINISTRATOR, PHARMACIST | DELETE |

---

## 3. Role-Based Permissions Matrix

### ADMINISTRATOR
- **Products:** CREATE ✓ READ ✓ UPDATE ✓ DELETE ✓
- **Batches:** CREATE ✓ READ ✓ UPDATE ✓ DELETE ✓
- **Can See Buttons:** Add Product, Add Batch, Edit, Delete

### PHARMACIST
- **Products:** READ ✓ UPDATE ✓ DELETE ✓ (CREATE ✗)
- **Batches:** CREATE ✓ READ ✓ UPDATE ✓ DELETE ✓
- **Can See Buttons:** Add Batch, Edit Product, Delete Product

### CLINICIAN
- **Products:** READ ✓ (CREATE ✗ UPDATE ✗ DELETE ✗)
- **Batches:** READ ✓ (CREATE ✗ UPDATE ✗ DELETE ✗)
- **Can See Buttons:** None (View-only)

### Other Roles
- PROCUREMENT_OFFICER, STOREKEEPER, COMPLIANCE_OFFICER, AUDITOR
- **Cannot access** Product/Batch management screens
- **Will not see** Add Product/Batch buttons

---

## 4. JWT Token Handling

### Token Structure (from JwtUtil.java)
```json
{
  "sub": "user@email.com",
  "role": "PHARMACIST",
  "userId": 12345,
  "iat": 1234567890,
  "exp": 1234611690
}
```

### UI Extraction Logic
```javascript
// From decoded JWT:
const tokenUsername = decoded.sub;        // "user@email.com"
const userRole = decoded.role;            // "PHARMACIST"
const userId = decoded.userId;            // 12345

// Stored in localStorage as:
{
  "userId": 12345,
  "email": "user@email.com",
  "role": "PHARMACIST",
  "loginTime": "2026-04-27T10:30:00Z"
}
```

---

## 5. Session & Error Handling

### Session Expiration
- Token expires after **10 hours** (from backend)
- UI automatically detects 401 Unauthorized
- Clears `authToken` and `pharmaShelfUser` from localStorage
- Redirects to login page

### Authorization Failures
- **403 Forbidden:** User role lacks permission for endpoint
- **401 Unauthorized:** Token expired or invalid
- **500 Server Error:** Backend processing error

---

## 6. Testing the Changes

### Test Scenario 1: ADMINISTRATOR Login
1. Login with ADMINISTRATOR role
2. ✅ Should see "Add Product" button
3. ✅ Should see "Add Batch" button
4. ✅ Should see Edit/Delete options in menu
5. ✅ Can create/edit/delete products and batches

### Test Scenario 2: PHARMACIST Login
1. Login with PHARMACIST role
2. ✅ Should NOT see "Add Product" button (CREATE not allowed)
3. ✅ Should see "Add Batch" button
4. ✅ Should see Edit/Delete in product menu
5. ✅ Can create batches, edit/delete products

### Test Scenario 3: CLINICIAN Login
1. Login with CLINICIAN role
2. ✅ Should NOT see "Add Product" button
3. ✅ Should NOT see "Add Batch" button
4. ✅ Should NOT see Edit/Delete options
5. ❌ Navigation to product page may be blocked at route level

### Test Scenario 4: Other Roles
1. Login with PROCUREMENT_OFFICER, STOREKEEPER, etc.
2. ✅ Should not be able to access product management
3. ✅ Should see appropriate error if forced to URL

---

## 7. Documentation Files Created

### `BACKEND_SECURITY_ALIGNMENT.md`
- Comprehensive mapping of all backend endpoints to roles
- Detailed role-based permission matrix
- Session management and error handling guide
- Testing procedures for each role

---

## 8. API Endpoints Status

### Product Service (`/pharmaShelf/products/**`)
- ✅ All endpoints authenticated via JWT
- ✅ @PreAuthorize annotations applied
- ✅ UI permissions aligned

### Batch Service (`/pharmaShelf/batches/**`)
- ✅ All endpoints authenticated via JWT
- ✅ @PreAuthorize annotations applied
- ✅ UI permissions aligned

### Authentication (`/pharmaShelf/auth/**`)
- ✅ Login/Signup permitted for all
- ✅ JWT generation with userId, role, username
- ✅ 10-hour token expiration

---

## 9. Known Limitations & Notes

1. **Other Components:** Only ProductMaster has been updated with role-based UI controls. Other components (Dispensing, Recalls, etc.) should follow the same pattern using `canPerformAction()`.

2. **Route-Level Protection:** This update adds button-level controls. Consider adding route-level protection in `routes.jsx` to prevent unauthorized users from accessing pages at all.

3. **Error Messages:** When users lack permissions, API will return 403. UI should show friendly error messages instead of technical details.

4. **Audit Logging:** Backend should log all failed authorization attempts for compliance.

---

## 10. Next Steps

1. ✅ **COMPLETED:** Update access control constants
2. ✅ **COMPLETED:** Update ProductMaster component
3. ⏳ **TODO:** Apply same pattern to other components:
   - Dispensing.jsx
   - RecallManagement.jsx
   - ExpiryMonitoring.jsx
   - UserManagement.jsx
   - etc.
4. ⏳ **TODO:** Add route-level protection in routes.jsx
5. ⏳ **TODO:** Improve error handling and user feedback
6. ⏳ **TODO:** Add audit logging for failed attempts

---

## 11. Backward Compatibility

✅ **All changes are backward compatible:**
- Existing JWT tokens with different role formats are still supported
- `normalizeRole()` handles multiple role field names
- UI gracefully degrades for users without proper roles
- No breaking changes to API contracts
