# Backend Security Alignment

This document maps the Spring Security configuration to the UI's role-based access control (RBAC) system.

## Security Configuration Summary

### Backend: SecurityConfig.java
The backend uses `@PreAuthorize` annotations with Spring Security to control endpoint access based on JWT token roles.

### JWT Token Structure (from JwtUtil.java)
```
Header:  { "alg": "HS256", "typ": "JWT" }
Payload: {
  "sub": "username@email.com",    // Username
  "role": "PHARMACIST",            // Role (without ROLE_ prefix in token)
  "userId": 12345,                 // User ID
  "iat": 1234567890,              // Issued at
  "exp": 1234611690               // Expiration (10 hours)
}
```

### UI Role Normalization
The UI automatically handles the `ROLE_` prefix that Spring Security adds:
- Backend stores: `PHARMACIST`
- Spring Security adds: `ROLE_PHARMACIST`
- UI normalizes back to: `PHARMACIST`

---

## Endpoint Access Control

### Authentication Endpoints
**Routes:** `/pharmaShelf/auth/**`
- **Access:** PERMIT_ALL (No authentication required)
- **Methods:** POST /login, POST /signup

### User Management
**Routes:** `/pharmaShelf/users/**`
- **Access:** PERMIT_ALL (Open, but backend may validate further)
- **Role Check:** All logged-in users

### Notification System
**Routes:** `/pharmaShelf/notifications/**`
- **Required Roles:** 
  - ADMINISTRATOR
  - PHARMACIST
  - STOREKEEPER
  - PROCUREMENT_OFFICER
  - COMPLIANCE_OFFICER
  - CLINICIAN
  - AUDITOR
- **Permission:** ROLE_ACTION_PERMISSIONS.NOTIFICATION.READ

### Product Management
**Routes:** `/pharmaShelf/products/**`

| Method | Endpoint | Required Role | UI Action |
|--------|----------|---------------|-----------|
| GET | /fetchAllProducts | ADMINISTRATOR, PHARMACIST, CLINICIAN | canPerformAction("PRODUCT", "READ") |
| GET | /fetchByProductId/{id} | ADMINISTRATOR, PHARMACIST, CLINICIAN | Read product details |
| POST | /insertProduct | ADMINISTRATOR | canPerformAction("PRODUCT", "CREATE") |
| PUT | /updateProduct/{id} | ADMINISTRATOR, PHARMACIST | canPerformAction("PRODUCT", "UPDATE") |
| DELETE | /deleteProduct/{id} | ADMINISTRATOR, PHARMACIST | canPerformAction("PRODUCT", "DELETE") |

### Batch Management
**Routes:** `/pharmaShelf/batches/**`

| Method | Endpoint | Required Role | UI Action |
|--------|----------|---------------|-----------|
| GET | /fetchAllBatches | ADMINISTRATOR, PHARMACIST, CLINICIAN | canPerformAction("BATCH", "READ") |
| GET | /fetchByBatchId/{id} | ADMINISTRATOR, PHARMACIST, CLINICIAN | Read batch details |
| GET | /fetchByProductId/{productId} | ADMINISTRATOR, PHARMACIST, CLINICIAN | Get batches by product |
| POST | /insertBatch | ADMINISTRATOR, PHARMACIST | canPerformAction("BATCH", "CREATE") |
| PUT | /updateBatch/{id} | ADMINISTRATOR, PHARMACIST | canPerformAction("BATCH", "UPDATE") |
| DELETE | /DeleteBatch/{id} | ADMINISTRATOR, PHARMACIST | canPerformAction("BATCH", "DELETE") |

### Dispensing
**Routes:** `/pharmaShelf/dispenses/**`
- **Required Roles:** PHARMACIST
- **Permission:** ROLE_ACTION_PERMISSIONS.DISPENSE

### Recalls
**Routes:** `/pharmaShelf/recalls/**`
- **Required Roles:** COMPLIANCE_OFFICER
- **Permission:** ROLE_ACTION_PERMISSIONS.RECALL

### Consumption Logs
**Routes:** `/pharmaShelf/consumption-logs/**`
- **Required Roles:** PHARMACIST, COMPLIANCE_OFFICER, STOREKEEPER, AUDITOR
- **Permission:** ROLE_ACTION_PERMISSIONS.CONSUMPTION_LOG

### Returns
**Routes:** `/pharmaShelf/returns/**`
- **Required Roles:** PHARMACIST
- **Permission:** ROLE_ACTION_PERMISSIONS.RETURN

### Goods Receipts
**Routes:** `/pharmaShelf/goodsreceipts/** or /pharmaShelf/goodsReceipts/**`
- **Required Roles:** PROCUREMENT_OFFICER
- **Permission:** ROLE_ACTION_PERMISSIONS.GOODSRECEIPT

### Purchase Orders
**Routes:** `/pharmaShelf/purchaseOrders/**`
- **Required Roles:** PROCUREMENT_OFFICER
- **Permission:** ROLE_ACTION_PERMISSIONS.PURCHASE_ORDER

### Suppliers
**Routes:** `/pharmaShelf/suppliers/**`
- **Required Roles:** PROCUREMENT_OFFICER
- **Permission:** ROLE_ACTION_PERMISSIONS.SUPPLIER

### Audit Logs
**Routes:** `/pharmaShelf/audit/**`
- **Required Roles:** AUDITOR, COMPLIANCE_OFFICER, PHARMACIST, STOREKEEPER
- **Permission:** ROLE_ACTION_PERMISSIONS.AUDIT_LOG.READ

### Expiry Alerts
**Routes:** `/pharmaShelf/expiryalerts/**`
- **Required Roles:** COMPLIANCE_OFFICER
- **Permission:** ROLE_ACTION_PERMISSIONS.EXPIRY_ALERT

### KPI
**Routes:** `/pharmaShelf/KPI/**`
- **Required Roles:** ADMINISTRATOR, COMPLIANCE_OFFICER, AUDITOR
- **Permission:** ROLE_ACTION_PERMISSIONS.KPI.READ

### Reports
**Routes:** `/pharmaShelf/reports/**`
- **Required Roles:** COMPLIANCE_OFFICER, ADMINISTRATOR, AUDITOR
- **Permission:** ROLE_ACTION_PERMISSIONS.REPORT.READ

### Quarantine
**Routes:** `/pharmaShelf/quarantine/**`
- **Required Roles:** PHARMACIST, AUDITOR
- **Permission:** ROLE_ACTION_PERMISSIONS.QUARANTINE

### Stock Counts
**Routes:** `/pharmaShelf/stockcounts/**`
- **Required Roles:** STOREKEEPER
- **Permission:** ROLE_ACTION_PERMISSIONS.STOCK_COUNT

### Reconciliations
**Routes:** `/pharmaShelf/reconciliations/**`
- **Required Roles:** STOREKEEPER
- **Permission:** ROLE_ACTION_PERMISSIONS.RECONCILIATION

### Alert Rules
**Routes:** `/pharmaShelf/alert-rules/**`
- **Required Roles:** ADMINISTRATOR
- **Permission:** ROLE_ACTION_PERMISSIONS.ALERT_RULE

---

## Role-Based Module Access

### PHARMACIST
- **Modules:** DISPENSE, BATCH, PRODUCT, EXPIRY_ALERT, QUARANTINE, RETURN, AUDIT_LOG
- **Can Create:** Batches, Dispenses, Returns, Quarantine entries
- **Can Read:** Products, Batches, Dispenses, Expiry data, Audit logs
- **Can Update:** Products, Batches, Dispenses
- **Can Delete:** Products, Batches, Dispenses

### ADMINISTRATOR
- **Modules:** USER, PRODUCT, BATCH, LOCATION, KPI, REPORT, ALERT_RULE
- **Permissions:** Full CRUD for Products, Batches, Users, Alert Rules
- **Can Read:** KPI, Reports

### PROCUREMENT_OFFICER
- **Modules:** SUPPLIER, PURCHASE_ORDER, GOODS_RECEIPT
- **Permissions:** Full CRUD for all procurement-related entities

### STOREKEEPER
- **Modules:** STOCK_COUNT, RECONCILIATION, LOCATION, AUDIT_LOG, CONSUMPTION_LOG
- **Permissions:** Full CRUD for inventory management

### COMPLIANCE_OFFICER
- **Modules:** EXPIRY_ALERT, RECALL, KPI, AUDIT_LOG, CONSUMPTION_LOG, REPORT
- **Permissions:** Can manage recalls, view audit logs, reports, and KPI data

### CLINICIAN
- **Modules:** PRODUCT, BATCH, DISPENSE
- **Permissions:** Read-only access to products, batches, and dispense records

### AUDITOR
- **Modules:** AUDIT_LOG, REPORT, KPI, QUARANTINE, RETURN, CONSUMPTION_LOG
- **Permissions:** Read-only audit data, reports, and KPI

---

## UI Access Control Implementation

### File: `src/app/constants/accessControl.js`

This file defines:
1. **MODULES** - All available modules in the system
2. **ROLE_MODULE_ACCESS** - Maps each role to accessible modules
3. **ROLE_ACTION_PERMISSIONS** - Defines role-specific CRUD permissions
4. **normalizeRole()** - Handles `ROLE_` prefix from Spring Security
5. **canAccessModule()** - Check if role can access a module
6. **canPerformAction()** - Check if role can perform an action on a resource

### Usage Example (ProductMaster.jsx)
```javascript
import { canPerformAction, getCurrentUserRole } from "../constants/accessControl";

const userRole = getCurrentUserRole();
const canCreateProduct = canPerformAction(userRole, "PRODUCT", "CREATE");
const canUpdateProduct = canPerformAction(userRole, "PRODUCT", "UPDATE");
const canDeleteProduct = canPerformAction(userRole, "PRODUCT", "DELETE");

// In JSX:
{canCreateProduct && <button>Add Product</button>}
{canUpdateProduct && <button>Edit Product</button>}
{canDeleteProduct && <button>Delete Product</button>}
```

---

## Session Management

### Token Storage
- **Location:** localStorage.key: `authToken`
- **Format:** JWT string
- **Expiration:** 10 hours (600 minutes)

### User Info Storage
- **Location:** localStorage.key: `pharmaShelfUser`
- **Format:** JSON object with:
  ```json
  {
    "userId": 12345,
    "email": "user@example.com",
    "role": "PHARMACIST",
    "loginTime": "2026-04-27T10:30:00.000Z"
  }
  ```

### Automatic Logout
- Session expires after 10 hours
- UI detects 401 Unauthorized responses
- Automatically clears tokens and redirects to login

---

## Error Handling

### 401 Unauthorized
- Token expired or invalid
- User must log in again
- Automatic redirect to `/login`

### 403 Forbidden
- User lacks required role for endpoint
- Error message shown in UI
- User remains on current page

### 500 Server Error
- Backend processing error
- Generic error message shown
- Retry mechanism available

---

## Testing Role-Based Access

### Test Users
1. **Admin** (ADMINISTRATOR role)
   - Full system access
   - Can create/edit/delete all resources

2. **Pharmacist** (PHARMACIST role)
   - Product and batch management
   - Dispensing functionality
   - Limited admin functions

3. **Compliance Officer** (COMPLIANCE_OFFICER role)
   - Recall management
   - Audit log viewing
   - Report generation

4. **Storekeeper** (STOREKEEPER role)
   - Stock count management
   - Reconciliation
   - Inventory tracking

---

## Migration Notes

### From Old to New System
1. All existing users need role assignment
2. Roles must match backend role names exactly
3. The UI automatically normalizes roles
4. No changes needed to existing token structure

### Backward Compatibility
- System handles multiple role field formats
- Automatically strips `ROLE_` prefix
- Supports legacy role claim locations
