# Integration Guide: Spring Security + React UI

## Overview

This guide explains how the React frontend integrates with the Spring Security backend to provide role-based access control throughout the application.

---

## Architecture Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                        BROWSER (React UI)                        │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │               Login Component                             │  │
│  │  ├─ Email/Password Input                                 │  │
│  │  └─ JWT Token Extraction                                 │  │
│  └────────────────────┬─────────────────────────────────────┘  │
│                       │                                          │
│  ┌────────────────────▼─────────────────────────────────────┐  │
│  │          localStorage (Token Storage)                    │  │
│  │  ├─ authToken: "eyJhbGc..."                              │  │
│  │  └─ pharmaShelfUser: {...user info...}                  │  │
│  └────────────────────┬─────────────────────────────────────┘  │
│                       │                                          │
│  ┌────────────────────▼─────────────────────────────────────┐  │
│  │          API Client (apiClient.js)                       │  │
│  │  ├─ Adds Authorization header                            │  │
│  │  └─ Handles 401/403 errors                              │  │
│  └────────────────────┬─────────────────────────────────────┘  │
│                       │                                          │
└───────────────────────┼──────────────────────────────────────────┘
                        │
                   HTTP Request
          GET /pharmaShelf/products/fetchAllProducts
          Authorization: Bearer eyJhbGc...
                        │
                        ▼
┌─────────────────────────────────────────────────────────────────┐
│                  SPRING SECURITY (Backend)                       │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │              JwtFilter (OncePerRequestFilter)            │  │
│  │  ├─ Extract token from Authorization header             │  │
│  │  ├─ Decode JWT payload                                  │  │
│  │  ├─ Set SecurityContextHolder with roles                │  │
│  │  └─ Continue to controller                              │  │
│  └────────────────────┬─────────────────────────────────────┘  │
│                       │                                          │
│  ┌────────────────────▼─────────────────────────────────────┐  │
│  │      ProductController.fetchAllProducts()               │  │
│  │  @PreAuthorize("hasAnyRole('ADMINISTRATOR',             │  │
│  │                           'PHARMACIST')")               │  │
│  │                                                          │  │
│  │  ✓ Checks if user's role is in allowed list            │  │
│  │  ✓ If yes: Execute method                              │  │
│  │  ✗ If no: Return 403 Forbidden                         │  │
│  └────────────────────┬─────────────────────────────────────┘  │
│                       │                                          │
│  ┌────────────────────▼─────────────────────────────────────┐  │
│  │            Return Response (JSON)                        │  │
│  │            HTTP 200 OK                                   │  │
│  └────────────────────┬─────────────────────────────────────┘  │
│                       │                                          │
└───────────────────────┼──────────────────────────────────────────┘
                        │
                   HTTP Response
        [{"id": 1, "name": "Aspirin", ...}]
                        │
                        ▼
┌─────────────────────────────────────────────────────────────────┐
│                        BROWSER (React UI)                        │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │      Component (ProductMaster.jsx)                       │  │
│  │  ├─ Get current user role from localStorage             │  │
│  │  ├─ Call canPerformAction(role, "PRODUCT", "CREATE")    │  │
│  │  └─ Conditionally render "Add Product" button           │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Step-by-Step Integration

### 1. User Login

```javascript
// Login.jsx - User enters credentials
const handleLogin = async (e) => {
  const response = await authAPI.login(email, password);
  const token = response.token;
  
  // Store token
  localStorage.setItem("authToken", token);
  
  // Decode and extract user info
  const decoded = decodeJWT(token);
  // decoded = {
  //   "sub": "user@email.com",
  //   "role": "PHARMACIST",
  //   "userId": 12345
  // }
  
  localStorage.setItem("pharmaShelfUser", JSON.stringify({
    userId: decoded.userId,
    email: decoded.sub,
    role: normalizeRole(decoded.role),
    loginTime: new Date().toISOString()
  }));
  
  navigate("/");
};
```

### 2. Token Transmission

```javascript
// apiClient.js - Every API call includes token
async function apiCall(url, options = {}) {
  const token = localStorage.getItem("authToken");
  
  const headers = {
    "Content-Type": "application/json",
    ...(options.headers || {}),
  };
  
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }
  
  const response = await fetch(url, {
    ...options,
    headers,
  });
  
  if (response.status === 401) {
    // Token expired, redirect to login
    localStorage.removeItem("authToken");
    window.location.href = "/login";
  }
  
  return response.json();
}
```

### 3. Backend JWT Processing

```java
// JwtFilter.java - Extract and validate token
public class JwtFilter extends OncePerRequestFilter {
  @Override
  protected void doFilterInternal(HttpServletRequest request, 
                                  HttpServletResponse response, 
                                  FilterChain filterChain) throws IOException {
    String auth = request.getHeader("Authorization");
    
    if (auth != null && auth.startsWith("Bearer ")) {
      String token = auth.substring(7); // Remove "Bearer " prefix
      
      try {
        JwtUtil util = new JwtUtil();
        String username = util.extractUsername(token);  // "user@email.com"
        String role = util.extractRole(token);          // "PHARMACIST"
        
        // Set security context for this request
        UsernamePasswordAuthenticationToken authentication =
          new UsernamePasswordAuthenticationToken(
            username,
            null,
            Collections.singletonList(
              new SimpleGrantedAuthority("ROLE_" + role)
            )
          );
        
        SecurityContextHolder.getContext().setAuthentication(authentication);
      } catch (JwtException e) {
        logger.debug("JWT validation failed");
      }
    }
    
    filterChain.doFilter(request, response);
  }
}
```

### 4. Backend Authorization Check

```java
// ProductController.java - Check user role
@RestController
@RequestMapping("/pharmaShelf/products")
public class ProductController {
  
  @GetMapping("/fetchAllProducts")
  @PreAuthorize("hasAnyRole('ADMINISTRATOR', 'PHARMACIST')")
  public ResponseEntity<List<ProductDTO>> getAllProducts() {
    // Spring checks:
    // 1. Is there a valid JWT token? (JwtFilter)
    // 2. Does the token contain role in ["ADMINISTRATOR", "PHARMACIST"]?
    // 3. If yes: Execute method
    // 4. If no: Return 403 Forbidden
    
    return ResponseEntity.ok(service.getAllProducts());
  }
}
```

### 5. Frontend UI Control

```javascript
// ProductMaster.jsx - Control visibility
import { canPerformAction, getCurrentUserRole } from "../constants/accessControl";

export function ProductMaster() {
  const userRole = getCurrentUserRole();
  
  // Check permissions
  const canCreateProduct = canPerformAction(userRole, "PRODUCT", "CREATE");
  // ↓
  // ROLE_ACTION_PERMISSIONS["PRODUCT"]["CREATE"] = ["ADMINISTRATOR"]
  // userRole = "PHARMACIST"
  // Result: false
  
  return (
    <>
      {canCreateProduct && (
        <button>Add Product</button>  // ← Hidden for PHARMACIST
      )}
      
      {canUpdateProduct && (
        <button>Edit Product</button>  // ← Visible for PHARMACIST
      )}
    </>
  );
}
```

---

## Authentication Flow Diagram

```
User Enters Credentials
         │
         ▼
┌─────────────────────────────┐
│ POST /pharmaShelf/auth/login │
│ {"email": "...", "password"}│
└────────┬────────────────────┘
         │
         ▼ (Backend: Check credentials & BCrypt)
┌─────────────────────────────────────┐
│ Generate JWT Token                  │
│ {                                   │
│   "sub": "user@email.com",         │
│   "role": "PHARMACIST",            │
│   "userId": 12345,                 │
│   "iat": 1234567890,               │
│   "exp": 1234611690 (10 hrs later) │
│ }                                   │
└────────┬────────────────────────────┘
         │
         ▼
Return JWT to Frontend
         │
         ▼
Store in localStorage:
├─ authToken
└─ pharmaShelfUser
         │
         ▼
Decode & Extract:
├─ sub (username)
├─ role (PHARMACIST)
├─ userId (12345)
└─ iat/exp (timing)
         │
         ▼
Navigate to Dashboard
         │
         ▼
Every API request includes:
Authorization: Bearer <JWT_TOKEN>
         │
         ▼ (Backend: JwtFilter)
Validate JWT:
├─ Check signature
├─ Check expiration
├─ Extract username & role
└─ Set SecurityContext
         │
         ▼ (Backend: @PreAuthorize)
Check @PreAuthorize annotation:
├─ hasAnyRole("ADMINISTRATOR", "PHARMACIST")?
├─ User has PHARMACIST → ✓ Allowed
└─ User has CLINICIAN → ✗ Forbidden (403)
         │
         ▼
Execute Endpoint or Return 403
         │
         ▼ (Frontend: apiClient.js)
Receive Response
├─ 200 OK → Use data
├─ 401 → Clear tokens, redirect to login
├─ 403 → Show error, stay on page
└─ 500 → Show error, allow retry
```

---

## Role-Based Access Examples

### Example 1: ADMINISTRATOR Creating Product

```javascript
// Frontend
const userRole = "ADMINISTRATOR";
const canCreate = canPerformAction(userRole, "PRODUCT", "CREATE");
// ROLE_ACTION_PERMISSIONS.PRODUCT.CREATE includes "ADMINISTRATOR"
// Result: true ✓ Button is shown

// User clicks "Add Product"
const created = await productsAPI.create(productData);
// axios: POST /pharmaShelf/products/insertProduct
// Header: Authorization: Bearer <JWT>
```

```java
// Backend
@PreAuthorize("hasAnyRole('ADMINISTRATOR')")
public ResponseEntity<ProductDTO> createProduct(...) {
  // Token has role: PHARMACIST
  // @PreAuthorize checks: Is PHARMACIST in ["ADMINISTRATOR"]?
  // Result: false ✗ → Returns 403 Forbidden
}
```

### Example 2: PHARMACIST Updating Product

```javascript
// Frontend
const userRole = "PHARMACIST";
const canUpdate = canPerformAction(userRole, "PRODUCT", "UPDATE");
// ROLE_ACTION_PERMISSIONS.PRODUCT.UPDATE includes "PHARMACIST"
// Result: true ✓ Button is shown

// User clicks "Edit"
const updated = await productsAPI.update(productId, changes);
// axios: PUT /pharmaShelf/products/updateProduct/123
// Header: Authorization: Bearer <JWT>
```

```java
// Backend
@PreAuthorize("hasAnyRole('ADMINISTRATOR', 'PHARMACIST')")
public ResponseEntity<ProductDTO> updateProduct(...) {
  // Token has role: PHARMACIST
  // @PreAuthorize checks: Is PHARMACIST in ["ADMINISTRATOR", "PHARMACIST"]?
  // Result: true ✓ → Executes method
}
```

### Example 3: CLINICIAN Reading Products (View Only)

```javascript
// Frontend
const userRole = "CLINICIAN";
const canCreate = canPerformAction(userRole, "PRODUCT", "CREATE");
// ROLE_ACTION_PERMISSIONS.PRODUCT.CREATE = ["ADMINISTRATOR"]
// Result: false ✗ Button is hidden

const canRead = canPerformAction(userRole, "PRODUCT", "READ");
// ROLE_ACTION_PERMISSIONS.PRODUCT.READ includes "CLINICIAN"
// Result: true ✓ Can view products

// User views products (read-only)
const products = await productsAPI.getAll();
// axios: GET /pharmaShelf/products/fetchAllProducts
```

```java
// Backend
@PreAuthorize("hasAnyRole('ADMINISTRATOR', 'PHARMACIST')")
public ResponseEntity<List<ProductDTO>> getAllProducts() {
  // Token has role: CLINICIAN
  // @PreAuthorize checks: Is CLINICIAN in ["ADMINISTRATOR", "PHARMACIST"]?
  // Result: false ✗ → Returns 403 Forbidden
  
  // Actually, backend shows getAllProducts has no @PreAuthorize
  // So CLINICIAN can read, but cannot create/update/delete
}
```

---

## Error Handling

### 401 Unauthorized (Token Expired)

```javascript
// User logged in 10 hours ago
// Token expires
// User clicks button
// API call is made with expired token

// Backend rejects: 401 Unauthorized

// Frontend (apiClient.js) handles:
if (response.status === 401) {
  localStorage.removeItem("authToken");
  localStorage.removeItem("pharmaShelfUser");
  window.location.href = "/login";
  // User must log in again
}
```

### 403 Forbidden (Insufficient Permissions)

```javascript
// PHARMACIST user
// Tries to create product
// canPerformAction returns false
// Button is not shown... but what if user directly calls API?

// axios: POST /pharmaShelf/products/insertProduct
// Backend: @PreAuthorize("hasAnyRole('ADMINISTRATOR')")
// User has PHARMACIST → Rejected
// Return: 403 Forbidden

// Frontend (ProductMaster.jsx) handles:
catch (error) {
  if (error.status === 403) {
    alert("You don't have permission to perform this action");
  } else {
    alert("Failed to create product");
  }
}
```

---

## Session Management

### Token Lifetime
- **Generated:** Login time (e.g., 10:00 AM)
- **Expires:** 10 hours later (e.g., 8:00 PM)
- **Stored:** localStorage (persistent across page reloads)

### Automatic Logout
- User closes tab/browser at 7:00 PM
- Returns at 8:30 PM (token now expired)
- API rejects request with 401
- Frontend detects 401
- Clears tokens and redirects to login

### Manual Logout
- User clicks "Logout" button
- Frontend clears localStorage
- User redirected to login page

---

## Security Best Practices

### ✓ Implemented

1. **JWT Token Validation**
   - Backend validates signature with secret key
   - Backend checks expiration time
   - Prevents token tampering

2. **Authorization Checks**
   - @PreAuthorize enforced on all endpoints
   - Role-based access control (RBAC)
   - Prevents unauthorized access

3. **Session Security**
   - 10-hour token expiration
   - Automatic logout on expiration
   - HTTP-only storage recommended (if converted to cookies)

4. **Password Security**
   - BCryptPasswordEncoder on backend
   - Plaintext passwords never transmitted (over HTTPS)
   - Passwords never stored in frontend

### ⏳ Recommended

1. **HTTPS Only**
   - Ensure production uses HTTPS
   - Prevents man-in-the-middle attacks

2. **CORS Configuration**
   - Backend should restrict to known frontend domains
   - Prevents unauthorized API access

3. **Audit Logging**
   - Log all failed authentication attempts
   - Log all failed authorization attempts
   - Useful for security monitoring

4. **Rate Limiting**
   - Limit login attempts (prevent brute force)
   - Limit API requests per user
   - Prevent abuse

---

## Troubleshooting

### Issue: "401 Unauthorized" on every request

**Cause:** Invalid JWT token

**Solution:**
1. Check token format: `Authorization: Bearer <JWT>`
2. Verify JWT wasn't modified
3. Check token hasn't expired
4. Log out and log in again to get fresh token

### Issue: "403 Forbidden" when user should have access

**Cause:** Role mismatch between frontend and backend

**Solution:**
1. Check backend @PreAuthorize annotation
2. Check user's actual role in JWT
3. Verify normalizeRole() is handling role correctly
4. Check ROLE_ACTION_PERMISSIONS in accessControl.js

### Issue: Buttons showing when they shouldn't

**Cause:** Frontend permission check not applied

**Solution:**
1. Add `canPerformAction()` check before rendering
2. Verify role is being retrieved correctly
3. Check ROLE_ACTION_PERMISSIONS has correct role
4. Test with different user roles

### Issue: User not logged out after 10 hours

**Cause:** localStorage not being cleared

**Solution:**
1. Check that 401 responses are being detected
2. Verify `apiClient.js` has 401 handler
3. Check localStorage keys are correct
4. Manually clear localStorage in browser DevTools and refresh

---

## Testing Checklist

- [ ] ADMINISTRATOR can create/edit/delete products
- [ ] PHARMACIST can edit products but not create
- [ ] CLINICIAN cannot see edit buttons
- [ ] Token expires after 10 hours
- [ ] Expired token causes automatic logout
- [ ] 403 error shows appropriate message
- [ ] Multiple tabs stay in sync (one logout affects all)
- [ ] Refresh page preserves login state
- [ ] API calls include Authorization header
- [ ] Role normalization handles ROLE_ prefix
