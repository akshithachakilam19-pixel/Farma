# Quick Reference: Role-Based Access Control

## At-a-Glance Role Permissions

### ADMINISTRATOR
```
Products:  ✓ Create  ✓ Read  ✓ Update  ✓ Delete
Batches:   ✓ Create  ✓ Read  ✓ Update  ✓ Delete
Users:     ✓ Full management
KPI:       ✓ View
Reports:   ✓ View
Alert Rules: ✓ Full management
```

### PHARMACIST
```
Products:  ✗ Create  ✓ Read  ✓ Update  ✓ Delete
Batches:   ✓ Create  ✓ Read  ✓ Update  ✓ Delete
Dispenses: ✓ Full management
Quarantine: ✓ Manage
Returns:   ✓ Manage
Audit Logs: ✓ View
```

### PROCUREMENT_OFFICER
```
Suppliers:        ✓ Full management
Purchase Orders:  ✓ Full management
Goods Receipts:   ✓ Full management
```

### STOREKEEPER
```
Stock Counts:     ✓ Full management
Reconciliations:  ✓ Full management
Locations:        ✓ Full management
Audit Logs:       ✓ View
```

### COMPLIANCE_OFFICER
```
Recalls:          ✓ Full management
Expiry Alerts:    ✓ Full management
Audit Logs:       ✓ View
Reports:          ✓ View
KPI:              ✓ View
```

### CLINICIAN
```
Products:  ✗ Create  ✓ Read  ✗ Update  ✗ Delete
Batches:   ✗ Create  ✓ Read  ✗ Update  ✗ Delete
Dispenses: ✓ View (read-only)
```

### AUDITOR
```
Audit Logs: ✓ View (read-only)
Reports:    ✓ View (read-only)
KPI:        ✓ View (read-only)
Quarantine: ✓ View
Returns:    ✓ View
```

---

## Code Snippets

### Check if user can perform action

```javascript
import { canPerformAction, getCurrentUserRole } from "../constants/accessControl";

const userRole = getCurrentUserRole();
const canDelete = canPerformAction(userRole, "PRODUCT", "DELETE");

if (canDelete) {
  // Show delete button
} else {
  // Hide delete button
}
```

### Conditionally render buttons

```jsx
import { canPerformAction, getCurrentUserRole } from "../constants/accessControl";

export function ProductMaster() {
  const userRole = getCurrentUserRole();
  
  return (
    <>
      {canPerformAction(userRole, "PRODUCT", "CREATE") && (
        <button>Add Product</button>
      )}
      
      {canPerformAction(userRole, "PRODUCT", "UPDATE") && (
        <button>Edit Product</button>
      )}
      
      {canPerformAction(userRole, "PRODUCT", "DELETE") && (
        <button>Delete Product</button>
      )}
    </>
  );
}
```

### API call with error handling

```javascript
try {
  const products = await productsAPI.getAll();
  setProducts(products);
} catch (error) {
  if (error.status === 401) {
    // Token expired, user will be logged out automatically
    console.log("Session expired");
  } else if (error.status === 403) {
    alert("You don't have permission to view this data");
  } else {
    alert("Failed to load products");
  }
}
```

---

## Endpoint Quick Reference

### Products
- GET `/pharmaShelf/products/fetchAllProducts` → ADMIN, PHARMACIST, CLINICIAN
- GET `/pharmaShelf/products/fetchByProductId/{id}` → ADMIN, PHARMACIST, CLINICIAN
- POST `/pharmaShelf/products/insertProduct` → **ADMIN only**
- PUT `/pharmaShelf/products/updateProduct/{id}` → ADMIN, PHARMACIST
- DELETE `/pharmaShelf/products/deleteProduct/{id}` → ADMIN, PHARMACIST

### Batches
- GET `/pharmaShelf/batches/fetchAllBatches` → ADMIN, PHARMACIST, CLINICIAN
- GET `/pharmaShelf/batches/fetchByBatchId/{id}` → ADMIN, PHARMACIST, CLINICIAN
- GET `/pharmaShelf/batches/fetchByProductId/{id}` → ADMIN, PHARMACIST, CLINICIAN
- POST `/pharmaShelf/batches/insertBatch` → ADMIN, PHARMACIST
- PUT `/pharmaShelf/batches/updateBatch/{id}` → ADMIN, PHARMACIST
- DELETE `/pharmaShelf/batches/DeleteBatch/{id}` → ADMIN, PHARMACIST

### Dispenses
- All endpoints → **PHARMACIST only**

### Recalls
- All endpoints → **COMPLIANCE_OFFICER only**

### Goods Receipts
- All endpoints → **PROCUREMENT_OFFICER only**

### Stock Counts
- All endpoints → **STOREKEEPER only**

### Audit Logs
- GET endpoints → AUDITOR, COMPLIANCE_OFFICER, PHARMACIST, STOREKEEPER

---

## Token Details

### Structure
```json
{
  "sub": "user@example.com",
  "role": "PHARMACIST",
  "userId": 12345,
  "iat": 1234567890,
  "exp": 1234611690
}
```

### Storage
```javascript
// localStorage keys:
localStorage.getItem("authToken") // JWT string
localStorage.getItem("pharmaShelfUser") // User object as JSON
```

### Lifetime
- **Valid:** 10 hours from login
- **After expiration:** 401 Unauthorized → Automatic logout

---

## Error Codes

| Code | Meaning | Action |
|------|---------|--------|
| 200 | Success | Use response data |
| 401 | Token expired/invalid | Automatic logout |
| 403 | Insufficient permissions | Show error message |
| 500 | Server error | Show error & allow retry |

---

## Files to Update When Adding New Resource

When adding new CRUD operations for a new resource:

1. **accessControl.js**
   ```javascript
   ROLE_ACTION_PERMISSIONS.NEW_RESOURCE = {
     CREATE: ["ROLE1", "ROLE2"],
     READ: ["ROLE1", "ROLE2", "ROLE3"],
     UPDATE: ["ROLE1"],
     DELETE: ["ROLE1"]
   };
   ```

2. **Component (e.g., NewResource.jsx)**
   ```javascript
   const canCreate = canPerformAction(userRole, "NEW_RESOURCE", "CREATE");
   const canUpdate = canPerformAction(userRole, "NEW_RESOURCE", "UPDATE");
   const canDelete = canPerformAction(userRole, "NEW_RESOURCE", "DELETE");
   ```

3. **Backend (e.g., NewResourceController.java)**
   ```java
   @PreAuthorize("hasAnyRole('ROLE1', 'ROLE2')")
   public ResponseEntity<?> createNewResource(...) { }
   ```

---

## Testing Different Roles

### Login as ADMINISTRATOR
- Email: admin@hospital.com
- Expected: See all buttons, full CRUD access

### Login as PHARMACIST
- Email: pharmacist@hospital.com
- Expected: See product/batch buttons, limited actions

### Login as COMPLIANCE_OFFICER
- Email: compliance@hospital.com
- Expected: Recall management, audit logs

### Login as CLINICIAN
- Email: clinician@hospital.com
- Expected: Read-only access to products/batches

---

## Debug Checklist

If buttons are showing/hiding incorrectly:

1. [ ] Check localStorage.getItem("pharmaShelfUser")
2. [ ] Verify role is correct in pharmaShelfUser.role
3. [ ] Check ROLE_ACTION_PERMISSIONS for the resource
4. [ ] Verify normalizeRole() is handling role correctly
5. [ ] Compare with backend @PreAuthorize annotation
6. [ ] Check that component is imported correctly
7. [ ] Verify canPerformAction() is called with correct params

---

## Common Issues & Fixes

### Issue: Button always hidden
```javascript
// Wrong
{canCreate && <button>Add</button>}

// Check:
console.log(getCurrentUserRole()); // What role?
console.log(canPerformAction(role, "PRODUCT", "CREATE")); // True or false?
```

### Issue: 403 Forbidden on every request
```javascript
// Check:
console.log(localStorage.getItem("authToken")); // Valid token?
console.log(localStorage.getItem("pharmaShelfUser")); // Role correct?
// Backend: @PreAuthorize annotation matches role?
```

### Issue: Logged out immediately after login
```javascript
// Check token expiration time in JWT
// Default: 10 hours from login
// If set to 0 or past time: Token already expired
```

---

## Production Checklist

- [ ] All endpoints have @PreAuthorize annotations
- [ ] All UI components check permissions before rendering
- [ ] Token expiration is set appropriately
- [ ] Error messages are user-friendly
- [ ] Audit logging is enabled
- [ ] HTTPS is enforced
- [ ] CORS is properly configured
- [ ] Rate limiting is implemented
- [ ] All roles are documented
- [ ] Tests cover all role scenarios
