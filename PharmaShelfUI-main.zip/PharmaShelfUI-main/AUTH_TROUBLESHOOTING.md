# Troubleshooting: Redirected to Login Issue

## Problem
When accessing ProductMaster or ConsumptionLog, you're being redirected to the login page (401 Unauthorized error).

## Root Causes

### ❌ Cause 1: No Token in LocalStorage
**Symptom:** Console shows "No auth token found"
**Fix:** 
- Log out and log back in
- Check that Login component is storing the token correctly
- Clear browser cache and localStorage

### ❌ Cause 2: Token is Expired
**Symptom:** Token exists but API returns 401
**Fix:**
- Log out and log back in
- Default expiration is 10 hours
- Check backend JWT configuration

### ❌ Cause 3: Token Format is Wrong
**Symptom:** Token exists but doesn't decode properly
**Fix:**
- Check token starts with eyJ (base64 for {)
- Verify token has 3 parts separated by dots (header.payload.signature)
- Check no spaces or line breaks in token

### ❌ Cause 4: JWT Secret Mismatch
**Symptom:** Token decodes but backend rejects it
**Fix:**
- Verify frontend and backend use same secret key
- Check no typos in the secret
- Restart backend after changing secret

### ❌ Cause 5: Endpoint Path Wrong
**Symptom:** 401 on specific endpoints only
**Fix:**
- Check serviceEndpoints.js matches backend routes
- Verify paths start with /pharmaShelf
- Check for trailing slashes

### ❌ Cause 6: Backend Not Running
**Symptom:** All API calls fail with 401
**Fix:**
- Verify backend is running
- Check it's listening on correct port
- Check network connectivity

### ❌ Cause 7: CORS Issue
**Symptom:** Preflight request fails
**Fix:**
- Check backend has @CrossOrigin configured
- Verify allowed origins include your frontend URL
- Check allowed methods include GET, POST, etc.

## Diagnostic Steps

### Step 1: Check Browser Console
1. Open Developer Tools (F12)
2. Go to Console tab
3. Look for error messages starting with ❌ or ⚠️
4. Note any "API Error" messages

### Step 2: Check LocalStorage
1. Open Developer Tools (F12)
2. Go to Application → LocalStorage
3. Find your domain
4. Check keys:
   - `authToken` - Should exist and be long string
   - `pharmaShelfUser` - Should be valid JSON with role

### Step 3: Inspect the Token
In browser console, run:
```javascript
const token = localStorage.getItem("authToken");
if (token) {
  const decoded = JSON.parse(atob(token.split('.')[1]));
  console.log("Token decoded:", decoded);
} else {
  console.log("No token!");
}
```

Expected output:
```javascript
{
  sub: "user@email.com",
  role: "PHARMACIST",
  userId: 12345,
  exp: 1234567890,
  iat: 1234523690
}
```

### Step 4: Test API Directly
In browser console:
```javascript
fetch('/pharmaShelf/products/fetchAllProducts', {
  headers: {
    'Authorization': `Bearer ${localStorage.getItem("authToken")}`,
    'Content-Type': 'application/json'
  }
})
.then(r => {
  console.log("Status:", r.status);
  return r.json();
})
.then(d => console.log("Data:", d))
.catch(e => console.error("Error:", e));
```

Expected: Status 200 with product data

### Step 5: Run Full Diagnostic
In browser console:
```javascript
import { fullDiagnostic } from '../../utils/jwtDebug';
fullDiagnostic();
```

This will show all auth status checks.

## Quick Fixes

### Quick Fix 1: Clear and Re-login
```javascript
// In browser console:
localStorage.removeItem("authToken");
localStorage.removeItem("pharmaShelfUser");
// Then reload page and log in again
```

### Quick Fix 2: Check Token Expiration
```javascript
// In browser console:
const token = localStorage.getItem("authToken");
const decoded = JSON.parse(atob(token.split('.')[1]));
const expiryDate = new Date(decoded.exp * 1000);
console.log("Token expires at:", expiryDate);
console.log("Is expired?", expiryDate < new Date());
```

### Quick Fix 3: Verify Backend URL
```javascript
// In browser console:
console.log("API Base URL:", import.meta.env.VITE_API_BASE_URL);
console.log("Environment:", import.meta.env.DEV ? 'Dev' : 'Prod');
```

## Common Scenarios

### Scenario 1: Fresh Login → Immediately Redirected
**Likely cause:** Backend not running or wrong URL
**Check:**
1. Is backend running? `http://localhost:8080` (or your port)
2. Can you access `http://localhost:8080/pharmaShelf/auth/login`?
3. Is VITE_API_BASE_URL configured correctly?

### Scenario 2: Works for 10 hours → Then Redirected
**Likely cause:** Token expired (normal)
**Fix:** Just log in again

### Scenario 3: Works on ProductMaster → Redirected on ConsumptionLog
**Likely cause:** Different endpoint or permission issue
**Check:**
1. Is ConsumptionLog endpoint configured in backend?
2. Does your role have permission for that endpoint?
3. Check @PreAuthorize annotation on backend

### Scenario 4: Works on Some Days → Redirected Other Days
**Likely cause:** Backend secret changed or restart
**Check:**
1. Did backend restart?
2. Did JWT secret get updated?
3. Are timestamps synchronized between frontend/backend?

## Debug Mode

### Enable Verbose Logging
Add to your .env file:
```
VITE_DEBUG_AUTH=true
```

Then in apiClient.js, the logging will be more detailed.

### Create Minimal Test
```jsx
import { useEffect, useState } from 'react';
import { productsAPI } from '../../services/api';

export function TestAuth() {
  const [status, setStatus] = useState('loading');
  const [error, setError] = useState('');

  useEffect(() => {
    const test = async () => {
      try {
        console.log('Starting auth test...');
        
        // Test 1: Check token
        const token = localStorage.getItem('authToken');
        console.log('Token exists?', !!token);
        
        // Test 2: Try API call
        console.log('Calling products API...');
        const data = await productsAPI.getAll();
        console.log('Success! Data:', data);
        setStatus('✅ Auth working!');
      } catch (err) {
        console.error('Auth test failed:', err);
        setStatus('❌ Auth failed');
        setError(err.message);
      }
    };
    test();
  }, []);

  return (
    <div className="p-4 border">
      <h2>Auth Test</h2>
      <p>{status}</p>
      {error && <p className="text-red-600">{error}</p>}
    </div>
  );
}
```

Add this to a route temporarily to test.

## Checklist

- [ ] Token exists in localStorage
- [ ] Token has 3 parts (header.payload.signature)
- [ ] Token decodes to JSON with sub, role, userId
- [ ] Token has not expired
- [ ] Backend is running
- [ ] Backend URL is correct
- [ ] Endpoint path is correct
- [ ] User role has permission for endpoint
- [ ] No CORS errors in browser console
- [ ] Network tab shows requests being sent
- [ ] Authorization header is being added

## Still Stuck?

1. Check browser console for exact error message
2. Copy that error message to documentation search
3. Run the diagnostic steps above
4. Check if backend logs show any errors
5. Try the debug utility: `fullDiagnostic()`

## Related Documentation
- BACKEND_SECURITY_ALIGNMENT.md - Endpoint permissions
- INTEGRATION_GUIDE.md - How auth works
- QUICK_REFERENCE.md - Common issues
