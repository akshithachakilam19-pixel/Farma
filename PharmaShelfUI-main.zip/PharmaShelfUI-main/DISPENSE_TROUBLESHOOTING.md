# Dispense Page Redirect to Login - Troubleshooting Guide

## Issue
When navigating to the Dispense page, the application redirects back to the login page.

## Root Causes

The redirect typically happens when:
1. **Auth Token Expired** - Session token is no longer valid
2. **Backend API Returns 401** - The `/pharmaShelf/dispenses` endpoint rejects the request
3. **User Role Mismatch** - User doesn't have PHARMACIST or CLINICIAN role
4. **User Not Properly Stored** - `pharmaShelfUser` not in localStorage

---

## Diagnosis Steps

### Step 1: Check Browser Console
Open DevTools (F12) → Console tab

**Look for:**
```
⚠️ 401 Unauthorized - Token may be expired. Redirecting to login...
✗ Failed to fetch requisitions: [error message]
```

If you see a 401 error, the backend is rejecting your request.

### Step 2: Verify User Role in LocalStorage
In DevTools → Application → Local Storage → your site

**Check:**
```json
{
  "pharmaShelfUser": {
    "name": "John Doe",
    "email": "john@hospital.com",
    "role": "PHARMACIST",  // ← Must be PHARMACIST, CLINICIAN, or admin role
    "userId": 123
  },
  "authToken": "eyJhbGc..."  // ← Should exist
}
```

**Allowed roles for Dispense page:**
- `PHARMACIST` ✅
- `CLINICIAN` ✅
- `ADMINISTRATOR` ✅

### Step 3: Check Auth Token
In DevTools → Application → Local Storage

**Check:**
- `authToken` should exist and not be empty
- `authToken` should look like: `eyJhbGciOiJ...` (JWT format)

### Step 4: Test Directly with curl/Postman
Replace with your actual values:

```bash
curl -H "Authorization: Bearer YOUR_AUTH_TOKEN" \
  http://localhost:8080/pharmaShelf/dispenses
```

**Expected response:**
- `200 OK` with dispensing data
- `401 Unauthorized` means token is invalid/expired
- `403 Forbidden` means user lacks permission

---

## Solutions

### Solution 1: Log Out and Log Back In
1. Click User Menu (top-right) → Logout
2. Log back in
3. Try accessing Dispense page again

This refreshes the auth token and user data.

### Solution 2: Clear Browser Cache
1. Press `Ctrl+Shift+Delete` (or `Cmd+Shift+Delete` on Mac)
2. Select "All time"
3. Clear Cookies and Cached images/files
4. Reload the page
5. Log in again

### Solution 3: Check User Role on Backend
Ask your backend admin to verify:
- Your user account has role `PHARMACIST` or `CLINICIAN`
- Account is not disabled
- Account is assigned to correct access level

### Solution 4: Check Backend API Status
```bash
# Test if backend is running
curl http://localhost:8080/pharmaShelf/dispenses \
  -H "Authorization: Bearer YOUR_TOKEN"

# Should return 200 OK (even if empty array)
# NOT 401 or 500
```

---

## What We Fixed

✅ **Route Added**: `/dispense` route now exists in routes.jsx  
✅ **Navigation Updated**: Layout.jsx now shows "Dispensing" in menu  
✅ **Better Error Logging**: Console now shows why requests are failing  
✅ **Token Cleanup**: Auth token and user data removed on 401 error  

---

## Quick Checklist

- [ ] I'm logged in with a PHARMACIST or CLINICIAN role
- [ ] Auth token exists in localStorage (not expired)
- [ ] `pharmaShelfUser` exists in localStorage
- [ ] Browser console shows no 401 errors
- [ ] Backend `/pharmaShelf/dispenses` API is running
- [ ] I've tried logging out and back in

---

## Still Having Issues?

1. **Check backend logs** for 401/403 responses
2. **Verify JWT token expiration** - May need to increase token TTL
3. **Ensure CORS is enabled** on backend if frontend and backend are on different ports
4. **Check if `/pharmaShelf/dispenses` endpoint exists** - May be `/dispenses` instead

---

## Routes Available

| Path | Component | Required Role |
|------|-----------|----------------|
| `/requisition` | DispensingWorkflow (Requisition) | PHARMACIST, CLINICIAN |
| `/dispense` | Dispensing | PHARMACIST, CLINICIAN |
| `/returns` | Returns | PHARMACIST, AUDITOR |
| `/consumption-log` | ConsumptionLog | PHARMACIST, COMPLIANCE_OFFICER, STOREKEEPER |
