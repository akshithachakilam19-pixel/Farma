/**
 * Debug utilities for quarantine 403 Forbidden issue
 * Run these in browser console to diagnose
 */

// 1. Check if token exists and decode it
export function debugToken() {
  const token = localStorage.getItem("authToken");
  
  if (!token) {
    console.error("❌ NO TOKEN FOUND - User not authenticated");
    return null;
  }
  
  console.log("✅ Token found:", token.substring(0, 20) + "...");
  
  try {
    const parts = token.split(".");
    if (parts.length !== 3) {
      console.error("❌ Invalid token format (not 3 parts)");
      return null;
    }
    
    const decoded = JSON.parse(atob(parts[1]));
    console.log("🔐 Decoded JWT:", decoded);
    
    // Check for role
    const role = decoded.role;
    const authorities = decoded.authorities;
    const roles = decoded.roles;
    
    console.log("\n📋 Role Info:");
    console.log("  - role claim:", role);
    console.log("  - authorities:", authorities);
    console.log("  - roles:", roles);
    
    if (!role && !authorities && !roles) {
      console.error("❌ NO ROLE INFORMATION IN TOKEN - This is the problem!");
      console.log("   Expected at least one of: 'role', 'authorities', 'roles'");
      return null;
    }
    
    if (role) {
      console.log(`✅ Found role: ${role}`);
      if (role === "PHARMACIST" || role === "ROLE_PHARMACIST") {
        console.log("✅ Role is PHARMACIST - Should have access!");
      } else {
        console.warn(`⚠️  Role is '${role}' but backend expects PHARMACIST, COMPLIANCE_OFFICER, or ADMINISTRATOR`);
      }
    }
    
    return decoded;
  } catch (e) {
    console.error("❌ Failed to decode token:", e.message);
    return null;
  }
}

// 2. Check user info stored in localStorage
export function debugUserInfo() {
  const userInfo = localStorage.getItem("userInfo");
  
  if (!userInfo) {
    console.log("ℹ️  No userInfo in localStorage");
    return null;
  }
  
  try {
    const user = JSON.parse(userInfo);
    console.log("👤 User Info:", user);
    console.log("  - role:", user.role);
    console.log("  - roles:", user.roles);
    return user;
  } catch (e) {
    console.error("❌ Failed to parse userInfo:", e.message);
    return null;
  }
}

// 3. Test the quarantine API with current token
export async function testQuarantineAPI() {
  const token = localStorage.getItem("authToken");
  
  if (!token) {
    console.error("❌ No token - cannot test API");
    return;
  }
  
  try {
    console.log("🧪 Testing POST /pharmaShelf/quarantines/insert...");
    
    const response = await fetch("/pharmaShelf/quarantines/insert", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
      },
      body: JSON.stringify({
        batchId: 1,
        reason: "Test quarantine",
      }),
    });
    
    console.log("📊 Response Status:", response.status);
    console.log("📊 Response Headers:", {
      "content-type": response.headers.get("content-type"),
      "www-authenticate": response.headers.get("www-authenticate"),
    });
    
    const text = await response.text();
    console.log("📊 Response Body:", text);
    
    if (!response.ok) {
      try {
        const data = JSON.parse(text);
        console.error("❌ API Error:", data);
      } catch {
        console.error("❌ API Error (raw):", text);
      }
    } else {
      console.log("✅ API Success:", JSON.parse(text));
    }
  } catch (e) {
    console.error("❌ Test failed:", e.message);
  }
}

// 4. Check pharmaShelfUser (alternative storage)
export function debugPharmaShelfUser() {
  const user = localStorage.getItem("pharmaShelfUser");
  
  if (!user) {
    console.log("ℹ️  No pharmaShelfUser in localStorage");
    return null;
  }
  
  try {
    const parsed = JSON.parse(user);
    console.log("👤 pharmaShelfUser:", parsed);
    return parsed;
  } catch (e) {
    console.error("❌ Failed to parse pharmaShelfUser:", e.message);
    return null;
  }
}

// Run all diagnostics
export function runAllDiagnostics() {
  console.log("\n" + "=".repeat(60));
  console.log("🔍 QUARANTINE 403 ERROR DIAGNOSTICS");
  console.log("=".repeat(60));
  
  console.log("\n1️⃣ Checking JWT Token...");
  const decoded = debugToken();
  
  console.log("\n2️⃣ Checking User Info...");
  debugUserInfo();
  
  console.log("\n3️⃣ Checking pharmaShelfUser...");
  debugPharmaShelfUser();
  
  console.log("\n4️⃣ Testing API Endpoint...");
  testQuarantineAPI();
  
  console.log("\n" + "=".repeat(60));
}

// Export for console use
if (typeof window !== "undefined") {
  window.debugQuarantine = {
    debugToken,
    debugUserInfo,
    debugPharmaShelfUser,
    testQuarantineAPI,
    runAll: runAllDiagnostics,
  };
  
  console.log("✅ Debug utilities loaded. Use: window.debugQuarantine.runAll()");
}
