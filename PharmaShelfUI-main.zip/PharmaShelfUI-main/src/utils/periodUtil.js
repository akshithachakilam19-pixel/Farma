/**
 * Period utility for formatting and calculating date ranges
 * Compatible with backend PeriodUtil (format: "MMMM yyyy")
 */

const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

/**
 * Get the current month period string (e.g., "April 2026")
 */
export function getCurrentMonthPeriod() {
  const now = new Date();
  const month = MONTHS[now.getMonth()];
  const year = now.getFullYear();
  return `${month} ${year}`;
}

/**
 * Get the current quarter period string (e.g., "Q2 2026" or "April 2026" format)
 * Returns start month of the quarter in "MMMM yyyy" format
 */
export function getCurrentQuarterPeriod() {
  const now = new Date();
  const quarter = Math.floor(now.getMonth() / 3);
  const startMonth = quarter * 3;
  const month = MONTHS[startMonth];
  const year = now.getFullYear();
  return `${month} ${year}`;
}

/**
 * Get the current year period string (e.g., "January 2026")
 * Returns January of current year in "MMMM yyyy" format
 */
export function getCurrentYearPeriod() {
  const now = new Date();
  const month = MONTHS[0]; // January
  const year = now.getFullYear();
  return `${month} ${year}`;
}

/**
 * Get period display label (for UI dropdown)
 */
export function getPeriodLabel(periodType) {
  switch (periodType) {
    case "monthly":
      return `Monthly (${getCurrentMonthPeriod()})`;
    case "quarterly":
      return `Quarterly (${getCurrentQuarterPeriod()})`;
    case "yearly":
      return `Yearly (${getCurrentYearPeriod()})`;
    default:
      return periodType;
  }
}

/**
 * Convert period type to date-based period string
 */
export function getPeriodString(periodType) {
  switch (periodType) {
    case "monthly":
      return getCurrentMonthPeriod();
    case "quarterly":
      return getCurrentQuarterPeriod();
    case "yearly":
      return getCurrentYearPeriod();
    default:
      return periodType;
  }
}
