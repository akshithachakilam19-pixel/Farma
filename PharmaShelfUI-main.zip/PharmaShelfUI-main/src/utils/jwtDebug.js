// ================================
// JWT Debug Utility - Comprehensive
// Helps diagnose authentication issues
// ================================

export const inspectToken = () => {
  const token = localStorage.getItem("authToken");
  if (!token) {
    console.warn("❌ No auth token found in localStorage");
    return null;
  }

  try {
    const decoded = JSON.parse(atob(token.split('.')[1]));
    console.log("📋 JWT Token Decoded:", {
      subject: decoded.sub,
      roles: decoded.roles,
      authorities: decoded.authorities,
      role: decoded.role,
      scope: decoded.scope,
      iss: decoded.iss,
      exp: decoded.exp ? new Date(decoded.exp * 1000) : null,
      iat: decoded.iat ? new Date(decoded.iat * 1000) : null,
      full: decoded
    });
    return decoded;
  } catch (err) {
    console.error("❌ Failed to decode token:", err);
    return null;
  }
};

export const checkRoleInToken = () => {
  const decoded = inspectToken();
  if (!decoded) return;

  const hasRoles = decoded.roles || decoded.authorities || [];
  const rolesArray = Array.isArray(hasRoles) ? hasRoles : [hasRoles];
  
  console.log("🔐 Roles/Authorities in token:", rolesArray);
  console.log("✓ Token expects PHARMACIST in one of these formats: PHARMACIST, ROLE_PHARMACIST, etc.");
};

export const compareStoredVsToken = () => {
  const stored = JSON.parse(localStorage.getItem("pharmaShelfUser") || "{}");
  const decoded = inspectToken();
  
  if (!decoded) return;

  console.log("📊 Comparison:");
  console.log("  Stored (from users API): ", stored.role);
  console.log("  In JWT token (authorities):", decoded.authorities || decoded.roles);
  console.log("  In JWT token (role claim):", decoded.role);
};

export const fullDiagnostic = () => {
  console.log("========================================");
  console.log("🔍 FULL AUTHENTICATION DIAGNOSTIC");
  console.log("========================================\n");
  
  // Check 1: Token exists
  const token = localStorage.getItem("authToken");
  console.log("✓ CHECK 1: Token in localStorage");
  if (token) {
    console.log("  ✅ Token found");
    console.log("  Token length:", token.length);
    console.log("  Token preview:", token.substring(0, 50) + "...");
  } else {
    console.log("  ❌ No token found - User not authenticated");
    return;
  }
  
  // Check 2: Token can be decoded
  console.log("\n✓ CHECK 2: Token can be decoded");
  const decoded = inspectToken();
  if (decoded) {
    console.log("  ✅ Token decoded successfully");
  } else {
    console.log("  ❌ Failed to decode token");
    return;
  }
  
  // Check 3: Token has subject (username)
  console.log("\n✓ CHECK 3: Token has subject (username)");
  if (decoded.sub) {
    console.log("  ✅ Username:", decoded.sub);
  } else {
    console.log("  ❌ No subject claim in token");
  }
  
  // Check 4: Token has role claim
  console.log("\n✓ CHECK 4: Token has role claim");
  if (decoded.role) {
    console.log("  ✅ Role claim found:", decoded.role);
  } else {
    console.log("  ❌ No 'role' claim in token");
  }
  
  // Check 5: Token has authorities
  console.log("\n✓ CHECK 5: Token has authorities for Spring Security");
  if (decoded.authorities) {
    console.log("  ✅ Authorities found:", decoded.authorities);
    const authorities = Array.isArray(decoded.authorities) ? decoded.authorities : [decoded.authorities];
    authorities.forEach(auth => {
      console.log(`    - ${auth}`);
    });
  } else {
    console.log("  ❌ No 'authorities' claim - SPRING SECURITY WILL REJECT THIS");
    console.log("     Backend needs to add: .claim('authorities', Arrays.asList('ROLE_' + role))");
  }
  
  // Check 6: Token expiration
  console.log("\n✓ CHECK 6: Token expiration");
  if (decoded.exp) {
    const expDate = new Date(decoded.exp * 1000);
    const now = new Date();
    if (expDate > now) {
      console.log("  ✅ Token is valid until:", expDate);
    } else {
      console.log("  ❌ Token has EXPIRED:", expDate);
    }
  } else {
    console.log("  ⚠️  No expiration in token");
  }
  
  // Check 7: Stored user data
  console.log("\n✓ CHECK 7: Stored user data in localStorage");
  const user = JSON.parse(localStorage.getItem("pharmaShelfUser") || "{}");
  if (user.role) {
    console.log("  ✅ Stored role:", user.role);
  } else {
    console.log("  ❌ No role in stored user data");
  }
  
  console.log("\n========================================");
  console.log("🎯 SUMMARY:");
  console.log("========================================");
  
  if (decoded.authorities) {
    console.log("✅ Authentication should WORK");
  } else {
    console.log("❌ Authentication will FAIL");
    console.log("\nFIX NEEDED:");
    console.log("1. Update JwtUtil.generateToken() to include:");
    console.log("   .claim('authorities', Arrays.asList('ROLE_' + role))");
    console.log("2. Restart backend");
    console.log("3. Clear localStorage (DevTools → Application → LocalStorage)");
    console.log("4. Log out and log back in");
  }
  
  console.log("========================================\n");
};
