import { apiCall, API_BASE_URL } from './apiClient';
const MODULE43_URL = API_BASE_URL;
 
// Supplier API (Matches Java SupplierController)
export const supplierAPI = {
  getAll: () =>
    apiCall('/pharmaShelf/suppliers/fetchAllSuppliers', {}, MODULE43_URL),
  getById: (supplierId) =>
    apiCall(`/pharmaShelf/suppliers/fetchBySupplierId/${supplierId}`, {}, MODULE43_URL),
  create: (data) =>
    apiCall('/pharmaShelf/suppliers/insertSupplier', {
      method: 'POST',
      body: JSON.stringify(data),
    }, MODULE43_URL),
  update: (supplierId, data) =>
    apiCall(`/pharmaShelf/suppliers/updateSupplier/${supplierId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }, MODULE43_URL),
  delete: (supplierId) =>
    apiCall(`/pharmaShelf/suppliers/deleteSupplier/${supplierId}`, {
      method: 'DELETE',
    }, MODULE43_URL),
}