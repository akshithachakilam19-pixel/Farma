import { apiCall } from "./apiClient";

// Matches Spring controller: @RequestMapping("/pharmaShelf/quarantines")
const API_BASE = "/pharmaShelf/quarantines";

const resolveId = (record) =>
  record?.quarantineId ??
  record?.QuarantineID ??
  record?.id ??
  record?.ID ??
  null;

export const quarantineService = {
  // -----------------------------
  // GET /pharmaShelf/quarantines
  // Compliance Officer Dashboard
  // -----------------------------
  getAll: () => apiCall(API_BASE),

  // -----------------------------------
  // GET /pharmaShelf/quarantines/{id}
  // Compliance Officer Reviews Details
  // -----------------------------------
  getById: (id) => apiCall(`${API_BASE}/${id}`),

  // -------------------------------------------------
  // POST /pharmaShelf/quarantines/insert  ✅ SAFE
  // Pharmacist: Flag and quarantine an item
  // Sets: QuarantinedBy (current pharmacist), QuarantinedAt (system time)
  // -------------------------------------------------
  quarantineBatch: async (batchId, reason) => {
    if (!batchId || batchId === "-" || batchId === "undefined") {
      throw new Error("Invalid Batch ID. Cannot create quarantine record.");
    }

    const cleanedReason = String(reason || "").trim();
    if (cleanedReason.length < 3) {
      throw new Error("Reason must be at least 3 characters");
    }

    // Get current user (pharmacist)
    let quarantinedBy = "Pharmacist";
    try {
      const user = JSON.parse(localStorage.getItem("pharmaShelfUser") || "{}");
      quarantinedBy = user?.name || user?.username || user?.email || "Pharmacist";
    } catch (e) {
      console.warn("Could not get user from localStorage:", e);
    }

    // ✅ EXACT payload that works in Postman
    const payload = {
      batchId: Number(batchId),
      reason: cleanedReason,
      quarantinedBy: quarantinedBy,
      quarantinedAt: new Date().toISOString(),
    };

    console.log("✅ Quarantine payload (SAFE):", payload);

    return apiCall(`${API_BASE}/insert`, {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // ========== NEW: COMPLIANCE OFFICER ACTIONS ==========

  /**
   * COMPLIANCE OFFICER: Release quarantined batch to stock
   * POST /pharmaShelf/quarantines/{id}/release
   * Status: QUARANTINED → RELEASED
   */
  releaseToStock: async (id) => {
    if (!id) throw new Error("Quarantine ID is required");

    const payload = {
      releasedBy: "Released",
    };

    console.log("✅ Release payload:", payload);

    return apiCall(`${API_BASE}/${id}/release`, {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  /**
   * COMPLIANCE OFFICER: Approve/Lock quarantined batch
   * POST /pharmaShelf/quarantines/{id}/approve
   * Status: QUARANTINE → APPROVED or LOCKED
   * Leaves: ReleasedBy, ReleasedAt as NULL (triggers recall/destruction)
   */
  approveLock: async (id, approvalStatus, reason = "") => {
    if (!id) throw new Error("Quarantine ID is required");
    if (!["APPROVED", "LOCKED"].includes(approvalStatus)) {
      throw new Error("Status must be APPROVED or LOCKED");
    }
    if (!reason || reason.trim().length < 5) {
      throw new Error("Approval reason must be at least 5 characters");
    }

    const payload = {
      status: approvalStatus,
      reason: reason,
      // ReleasedBy and ReleasedAt intentionally left NULL
      // This signals to compliance system: initiate recall/destruction
    };

    console.log("✅ Approve/Lock payload:", payload);

    return apiCall(`${API_BASE}/${id}/approve`, {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // -----------------------------------
  // PUT /pharmaShelf/quarantines/{id}
  // Administrator: General updates
  // -----------------------------------
  update: (id, data) => {
    const resolvedId = id ?? resolveId(data);
    if (!resolvedId) {
      throw new Error("Quarantine ID is required for update");
    }

    return apiCall(`${API_BASE}/${resolvedId}`, {
      method: "PUT",
      body: JSON.stringify(data),
    });
  },

  // -----------------------------------
  // DELETE /pharmaShelf/quarantines/{id}
  // Administrator: Delete records
  // -----------------------------------
  delete: (id) =>
    apiCall(`${API_BASE}/${id}`, {
      method: "DELETE",
    }),
};
