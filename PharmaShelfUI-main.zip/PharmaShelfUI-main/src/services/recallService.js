// ================================
// Recall Service  (RecallController)
// GET  /pharmaShelf/recalls
// GET  /pharmaShelf/recalls/:id
// GET  /pharmaShelf/recalls/period
// POST /pharmaShelf/recalls
// PUT  /pharmaShelf/recalls/:id
// DELETE /pharmaShelf/recalls/:id
// ================================

import { apiCall } from "./apiClient";
import { SERVICE_PREFIX, serviceUrl } from "./serviceEndpoints";

export const recallAPI = {
  getAll: async () => {
    try {
      console.log("Recall Service: Fetching all recalls...");
      const url = serviceUrl(SERVICE_PREFIX.recalls);
      console.log("Recall API URL:", url);
      const data = await apiCall(url, {
        method: "GET",
      });
      console.log("Recall API response:", data);
      return data;
    } catch (err) {
      console.error("Recall Service: Failed to fetch recalls:", err);
      return [];
    }
  },

  getById: (id) =>
    apiCall(serviceUrl(SERVICE_PREFIX.recalls, `/${id}`), {
      method: "GET",
    }),

  getByPeriod: (startDate, endDate) =>
    apiCall(
      serviceUrl(
        SERVICE_PREFIX.recalls,
        `/period?startDate=${encodeURIComponent(startDate)}&endDate=${encodeURIComponent(endDate)}`
      ),
      {
        method: "GET",
      }
    ).catch(() => []),

  create: (data) =>
    apiCall(serviceUrl(SERVICE_PREFIX.recalls), {
      method: "POST",
      body: JSON.stringify(data),
    }),

  update: (id, data) =>
    apiCall(serviceUrl(SERVICE_PREFIX.recalls, `/${id}`), {
      method: "PUT",
      body: JSON.stringify(data),
    }),

  delete: (id) =>
    apiCall(serviceUrl(SERVICE_PREFIX.recalls, `/${id}`), {
      method: "DELETE",
    }),
};

// Alias export for component compatibility
export const recallService = recallAPI;
