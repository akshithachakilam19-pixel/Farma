// ================================
// API Barrel
// Single import point for all components.
// HTTP logic lives in apiClient.js
// Endpoint definitions live in individual service files.
// ================================

export { authAPI }          from "./authService";
export { usersAPI }         from "./usersService";
export { productsAPI }      from "./productsService";
export { batchesAPI }       from "./batchesService";
export { dispensingAPI }    from "./dispensingService";
export { alertRulesAPI }    from "./alertRulesService";
export { notificationsAPI } from "./notificationsService";
export { notificationService } from "./notificationService";
export { auditAPI }         from "./auditService";
export { kpiAPI }           from "./kpiService";
export { reportsAPI }       from "./reportsService";
export { supplierAPI }      from "./supplierAPI";
export { purchaseOrderAPI } from "./purchaseOrderApi";
export { goodsReceiptAPI }  from "./goodsReceiptAPI";
export { expiryService }    from "./expiryService";

import { apiCall } from "./apiClient";
import { SERVICE_PREFIX, serviceUrl } from "./serviceEndpoints";

// ================================
// CONSUMPTION LOG API
// ================================
export const consumptionLogAPI = {
  // READ ONLY APIs
  getAll: () => apiCall(serviceUrl(SERVICE_PREFIX.consumptionLogs)),
  getById: (id) => apiCall(serviceUrl(SERVICE_PREFIX.consumptionLogs, `/${id}`)),
  getDetails: (id) => apiCall(serviceUrl(SERVICE_PREFIX.consumptionLogs, `/${id}/details`)),
  getByProduct: (productId) => apiCall(serviceUrl(SERVICE_PREFIX.consumptionLogs, `/product/${productId}`)),
  getByPeriod: (from, to) => apiCall(serviceUrl(SERVICE_PREFIX.consumptionLogs, `/period?from=${from}&to=${to}`)),
  getConsumptionKpi: (period) => apiCall(serviceUrl(SERVICE_PREFIX.consumptionLogs, `/internal/kpi/consumption-accuracy?period=${encodeURIComponent(period)}`)),
  // Internal: Generate consumption logs for a period
  generateForPeriod: (period) => apiCall(serviceUrl(SERVICE_PREFIX.consumptionLogs, `/internal/generate?period=${encodeURIComponent(period)}`), { method: "POST" }),
};

// ================================
// RETURNS API
// ================================
export const returnAPI = {
  getAll: () => apiCall(serviceUrl(SERVICE_PREFIX.returns)),
  getById: (id) => apiCall(serviceUrl(SERVICE_PREFIX.returns, `/${id}`)),
  getByBatch: (batchId) => apiCall(serviceUrl(SERVICE_PREFIX.returns, `/batch/${batchId}`)),
  getDispenseBatches: (dispenseId) => apiCall(serviceUrl(SERVICE_PREFIX.returns, `/dispense/${dispenseId}/batches`)),
  create: (data) => apiCall(serviceUrl(SERVICE_PREFIX.returns), { method: "POST", body: JSON.stringify(data) }),
  delete: (id) => apiCall(serviceUrl(SERVICE_PREFIX.returns, `/${id}`), { method: "DELETE" }),
};

// ================================
// STOCK COUNT API
// ================================
export const stockCountAPI = {
  getScheduled: () => apiCall(serviceUrl(SERVICE_PREFIX.stockCount, "/scheduled")),
  getCompleted: () => apiCall(serviceUrl(SERVICE_PREFIX.stockCount, "/completed")),
  startCount: (countId) => apiCall(serviceUrl(SERVICE_PREFIX.stockCount, `/${countId}/start`), { method: "POST" }),
  submitCount: (countId, data) => apiCall(serviceUrl(SERVICE_PREFIX.stockCount, `/${countId}/submit`), { method: "POST", body: JSON.stringify(data) }),
};
