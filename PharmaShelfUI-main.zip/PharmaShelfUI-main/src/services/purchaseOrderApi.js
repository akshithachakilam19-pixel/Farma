import { apiCall, API_BASE_URL } from './apiClient';
const MODULE43_URL = API_BASE_URL;

export const purchaseOrderAPI = {
  getAll: () =>
    apiCall('/pharmaShelf/purchaseOrders/fetchAllPurchaseOrders', {}, MODULE43_URL),
  getById: (poId) =>
    apiCall(`/pharmaShelf/purchaseOrders/fetchPurchaseOrderById/${poId}`, {}, MODULE43_URL),
  getBySupplier: (supplierId) =>
    apiCall(`/pharmaShelf/purchaseOrders/fetchSupplierById/supplier/${supplierId}`, {}, MODULE43_URL),
  getByStatus: (status) =>
    apiCall(`/pharmaShelf/purchaseOrders/fetchPurchaseOrdersByStatus/status/${status}`, {}, MODULE43_URL),
  create: (data) =>
    apiCall('/pharmaShelf/purchaseOrders/createPurchaseOrder', {
      method: 'POST',
      body: JSON.stringify(data),
    }, MODULE43_URL),
  update: (poId, data) =>
    apiCall(`/pharmaShelf/purchaseOrders/updatePurchaseOrder/${poId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }, MODULE43_URL),
  delete: (poId) =>
    apiCall(`/pharmaShelf/purchaseOrders/deletePurchaseOrder/${poId}`, {
      method: 'DELETE',
    }, MODULE43_URL),
};