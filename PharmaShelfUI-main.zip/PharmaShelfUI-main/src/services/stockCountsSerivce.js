const BASE_URL = "/pharmaShelf/stockcounts";
 
// Fallback static data used when backend is unavailable
const fallbackScheduled = [
  {
    id: 1,
    countId: "SC-2024-042",
    locationId: "Main Pharmacy",
    productId: "PRD-001",
    batchId: 215,
    countedQuantity: 45,
    countedBy: "Sarah Johnson",
    countedAt: "2026-03-30",
    status: "Pending",
  },
  {
    id: 2,
    countId: "SC-2024-043",
    locationId: "Ward-A Pharmacy",
    productId: "PRD-002",
    batchId: 103,
    countedQuantity: 12,
    countedBy: "Mike Chen",
    countedAt: "2026-03-29",
    status: "Progress",
  },
];
 
const fallbackCompleted = [
  {
    id: 3,
    countId: "SC-2024-039",
    locationId: "Emergency Department",
    countedAt: "2026-03-22",
    countedBy: "Mike Chen",
    countedQuantity: 24,
    accuracy: 91.7,
    status: "Pending Approval",
  },
];
 
function normalizeStockCount(item) {
  const countId = item?.countId ?? item?.id ?? null;
  const locationId = item?.locationId ?? item?.location ?? null;
  const productId = item?.productId ?? item?.type ?? null;
  const batchId = item?.batchId ?? null;
  const countedBy = item?.countedBy ?? item?.assignedTo ?? null;
  const countedQuantity = item?.countedQuantity ?? item?.products ?? 0;
  const countedAt = item?.countedAt ?? item?.scheduledDate ?? item?.completedDate ?? null;
  const status = item?.status ?? "Pending";
 
  return {
    ...item,
    id: item?.id ?? countId ?? Date.now(),
    countId,
    locationId,
    location: typeof locationId === "number" ? `Location ${locationId}` : locationId,
    productId,
    type: typeof productId === "number" ? `Product ${productId}` : productId,
    batchId,
    countedBy,
    assignedTo: typeof countedBy === "number" ? `User ${countedBy}` : countedBy,
    countedQuantity: Number(countedQuantity) || 0,
    countedAt,
    scheduledDate: countedAt,
    status,
  };
}
 
// GET /pharmaShelf/stockcounts — fetch all stock counts from backend
export async function fetchAllStockCounts() {
  try {
    const res = await fetch(BASE_URL);
    if (!res.ok) throw new Error("Failed to fetch");
    const data = await res.json();
    return Array.isArray(data) ? data.map(normalizeStockCount) : [];
  } catch (err) {
    console.warn("Backend unavailable, using fallback data:", err.message);
    return [...fallbackScheduled, ...fallbackCompleted];
  }
}
 
// POST /pharmaShelf/stockcounts/insert — create a new stock count
export async function createStockCount(dto) {
  const payloads = [
    dto,
    {
      ...dto,
      countedAt: String(dto?.countedAt ?? "").replace("T", " "),
    },
    {
      ...dto,
      countedAt: String(dto?.countedAt ?? "").replace(" ", "T"),
      locationId: Number(dto?.locationId) || 101,
      productId: Number(dto?.productId) || 202,
      batchId: Number(dto?.batchId) || 303,
      countedBy: Number(dto?.countedBy) || 4001,
      countedQuantity: Number(dto?.countedQuantity) || 1,
    },
  ];
 
  const endpoints = [`${BASE_URL}/insert`, BASE_URL];
  let lastError = null;
 
  for (const endpoint of endpoints) {
    for (const payload of payloads) {
      try {
        const res = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
 
        if (!res.ok) {
          const errorText = await res.text();
          lastError = new Error(errorText || `Failed to create stock count (HTTP ${res.status})`);
          continue;
        }
 
        try {
          const data = await res.json();
          return normalizeStockCount(data);
        } catch (parseErr) {
          console.warn("Create response parse warning (data may still be saved):", parseErr.message);
          return normalizeStockCount(payload);
        }
      } catch (err) {
        lastError = err;
      }
    }
  }
 
  throw lastError || new Error("Failed to create stock count");
}
 
// PUT /pharmaShelf/stockcounts/{id} — update a stock count
export async function updateStockCount(id, dto) {
  const res = await fetch(`${BASE_URL}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dto),
  });
  if (!res.ok) throw new Error("Failed to update stock count");
  return normalizeStockCount(await res.json());
}
 
// DELETE /pharmaShelf/stockcounts/{id} — delete a stock count
export async function deleteStockCount(id) {
  const encodedId = encodeURIComponent(id);
  const attempts = [
    { url: `${BASE_URL}/${encodedId}`, method: "DELETE" },
    { url: `${BASE_URL}/delete/${encodedId}`, method: "DELETE" },
    { url: `${BASE_URL}/delete?id=${encodedId}`, method: "DELETE" },
    { url: `${BASE_URL}/${encodedId}`, method: "POST" },
  ];
 
  let lastError = null;
 
  for (const attempt of attempts) {
    try {
      const res = await fetch(attempt.url, { method: attempt.method });
      if (res.ok) return;
      const errorText = await res.text();
      lastError = new Error(errorText || `Failed to delete stock count (HTTP ${res.status})`);
    } catch (err) {
      lastError = err;
    }
  }
 
  throw lastError || new Error("Failed to delete stock count");
}
 
// GET /pharmaShelf/stockcounts/{id} — get by id
export async function fetchStockCountById(id) {
  const res = await fetch(`${BASE_URL}/${id}`);
  if (!res.ok) throw new Error("Failed to fetch stock count");
  return normalizeStockCount(await res.json());
}
 
export function getFallbackScheduled() {
  return fallbackScheduled;
}
 
export function getFallbackCompleted() {
  return fallbackCompleted;
}
 