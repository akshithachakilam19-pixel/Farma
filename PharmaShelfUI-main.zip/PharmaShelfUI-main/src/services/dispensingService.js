// ================================
// Dispensing Service  (DispensingController)
// GET  /pharmaShelf/dispenses
// GET  /pharmaShelf/dispenses/:id
// GET  /pharmaShelf/dispenses/details/:id
// POST /pharmaShelf/dispenses
// PUT  /pharmaShelf/dispenses/:id
// POST /pharmaShelf/dispenses/:id/cancel
// ================================

import { apiCall } from "./apiClient";
import { SERVICE_PREFIX, serviceUrl } from "./serviceEndpoints";

export const dispensingAPI = {
  // ==================== NURSE: REQUEST DISPENSING ====================
  requestDispense: (data) =>
    apiCall(serviceUrl(SERVICE_PREFIX.dispenses, "/request"), {
      method: "POST",
      body: JSON.stringify(data),
    }),

  // ==================== PHARMACIST: APPROVE/REJECT ====================
  approveDispense: (dispenseId) =>
    apiCall(serviceUrl(SERVICE_PREFIX.dispenses, `/${dispenseId}/approve`), {
      method: "PUT",
    }),

  rejectDispense: (dispenseId, reason) =>
    apiCall(
      serviceUrl(
        SERVICE_PREFIX.dispenses,
        `/${dispenseId}/reject?reason=${encodeURIComponent(reason || "")}`
      ),
      { method: "PUT" }
    ),

  dispenseApproved: (dispenseId, pharmacistId) =>
    apiCall(
      serviceUrl(
        SERVICE_PREFIX.dispenses,
        `/${dispenseId}/dispense?pharmacist=${encodeURIComponent(pharmacistId || "")}`
      ),
      { method: "PUT" }
    ),

  // ==================== PHARMACIST: STATUS FILTERS ====================
  getRequestedDispenses: () =>
    apiCall(serviceUrl(SERVICE_PREFIX.dispenses, "/requested")),

  getApprovedDispenses: () =>
    apiCall(serviceUrl(SERVICE_PREFIX.dispenses, "/approved")),

  getRejectedDispenses: () =>
    apiCall(serviceUrl(SERVICE_PREFIX.dispenses, "/rejected")),

  getDispensedDispenses: () =>
    apiCall(serviceUrl(SERVICE_PREFIX.dispenses, "/dispensed")),

  // ==================== NURSE: VIEW BY PATIENT/WARD + STATUS ====================
  getDispensesByPatientIdAndStatus: (patientId, status) =>
    apiCall(
      serviceUrl(
        SERVICE_PREFIX.dispenses,
        `/patient/${encodeURIComponent(patientId)}/status/${encodeURIComponent(status)}`
      )
    ),

  getDispensesByWardIdAndStatus: (wardId, status) =>
    apiCall(
      serviceUrl(
        SERVICE_PREFIX.dispenses,
        `/ward/${encodeURIComponent(wardId)}/status/${encodeURIComponent(status)}`
      )
    ),

  // ==================== LEGACY METHODS (BACKWARD COMPATIBILITY) ====================
  getAll: () => apiCall(serviceUrl(SERVICE_PREFIX.dispenses)),

  getById: (id) => apiCall(serviceUrl(SERVICE_PREFIX.dispenses, `/${id}`)),

  getDetails: (id) => apiCall(serviceUrl(SERVICE_PREFIX.dispenses, `/details/${id}`)),

  getByStatus: (status) => apiCall(serviceUrl(SERVICE_PREFIX.dispenses, `/status/${status}`)),

  create: (data) =>
    apiCall(serviceUrl(SERVICE_PREFIX.dispenses), {
      method: "POST",
      body: JSON.stringify(data),
    }),

  update: (id, data) =>
    apiCall(serviceUrl(SERVICE_PREFIX.dispenses, `/${id}`), {
      method: "PUT",
      body: JSON.stringify(data),
    }),

  cancel: (id, reason) =>
    apiCall(serviceUrl(SERVICE_PREFIX.dispenses, `/${id}/cancel?reason=${reason || ""}`), {
      method: "POST",
    }),

  confirm: (id) =>
    apiCall(serviceUrl(SERVICE_PREFIX.dispenses, `/${id}/confirm`), {
      method: "POST",
    }),
};

// Alias export for component compatibility
export const dispensingService = dispensingAPI;
