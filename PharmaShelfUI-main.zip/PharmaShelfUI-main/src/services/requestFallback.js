// ================================
// Request Fallback Service
// Tries multiple endpoints in sequence until one succeeds
// ================================

import { apiCall } from './apiClient';

/**
 * Try multiple API endpoints in sequence until one succeeds
 * @param {string[]} endpoints - Array of endpoint URLs to try
 * @param {object} options - Fetch options (method, body, headers, etc.)
 * @param {string} serviceName - Name of the service for logging
 * @returns {Promise} - Response from the first successful endpoint
 */
export async function callWithFallbacks(endpoints, options = {}, serviceName = 'unknown') {
  if (!Array.isArray(endpoints) || endpoints.length === 0) {
    throw new Error('No endpoints provided to callWithFallbacks');
  }

  const validEndpoints = endpoints.filter(ep => ep && typeof ep === 'string');
  
  if (validEndpoints.length === 0) {
    throw new Error('No valid endpoints provided to callWithFallbacks');
  }

  let lastError = null;

  for (let i = 0; i < validEndpoints.length; i++) {
    const endpoint = validEndpoints[i];
    try {
      console.log(`[${serviceName}] Attempting endpoint (${i + 1}/${validEndpoints.length}): ${endpoint}`);
      const result = await apiCall(endpoint, options);
      console.log(`[${serviceName}] ✓ Success with endpoint: ${endpoint}`);
      return result;
    } catch (error) {
      lastError = error;
      console.warn(`[${serviceName}] ✗ Failed endpoint: ${endpoint} - ${error?.message || error}`);
      
      // If this is the last endpoint, throw the error
      if (i === validEndpoints.length - 1) {
        throw new Error(`All fallback endpoints failed for ${serviceName}. Last error: ${lastError?.message || lastError}`);
      }
      
      // Otherwise, continue to the next endpoint
    }
  }

  // This should never be reached, but just in case
  throw lastError || new Error(`Request failed for ${serviceName}`);
}

export default { callWithFallbacks };
