import { apiCall, callWithFallbacks } from "./apiClient";
 
const REPORT_BASES = [
  "/pharmaShelf/reports",
];
 
const KPI_BASES = [
  "/pharmaShelf/KPI",
];
 
export const reportsAPI = {
  // Report Management screen endpoints
  getAllReports: () =>
    callWithFallbacks([
      "/pharmaShelf/reports/all",
    ], {}, "reportsService.getAllReports"),
 
  getReportById: (id) =>
    callWithFallbacks([
      `/pharmaShelf/reports/get/${id}`,
    ], {}, "reportsService.getReportById"),
 
  createReport: (data) =>
    callWithFallbacks([
      "/pharmaShelf/reports/insert",
    ], {
      method: "POST",
      body: JSON.stringify(data),
    }, "reportsService.createReport"),
  updateReport: (idOrData, updates) => {
    const payload =
      typeof idOrData === "object" && idOrData !== null
        ? idOrData
        : {
            id: idOrData,
            reportId: idOrData,
            ...(updates || {}),
          };
 
    const reportId = payload.id ?? payload.reportId;
 
    return callWithFallbacks([
      ...REPORT_BASES.map((base) => `${base}/update`),
      ...REPORT_BASES.map((base) => (reportId ? `${base}/update/${reportId}` : null)),
      ...REPORT_BASES.map((base) => (reportId ? `${base}/${reportId}` : null)),
    ].filter(Boolean), {
      method: "PUT",
      body: JSON.stringify(payload),
    }, "reportsService.updateReport");
  },
 
  deleteReport: (id) =>
    callWithFallbacks([
      `/pharmaShelf/reports/del/${id}`,
    ], {
      method: "DELETE",
    }, "reportsService.deleteReport"),
 
  // KPI + analytics endpoints
  addKPI: (data) =>
    callWithFallbacks(
      [
        KPI_BASES[0],
        `${KPI_BASES[1]}/insert`,
        `${KPI_BASES[2]}/insert`,
      ],
      {
        method: "POST",
        body: JSON.stringify(data),
      },
      "reportsService.addKPI"
    ),
  getAllKPIs: () =>
    callWithFallbacks(
      [
        KPI_BASES[0],
        `${KPI_BASES[1]}/all`,
        `${KPI_BASES[2]}/all`,
      ],
      {},
      "reportsService.getAllKPIs"
    ),
  getKPIById: (id) =>
    callWithFallbacks(
      [
        `${KPI_BASES[0]}/${id}`,
        `${KPI_BASES[1]}/get/${id}`,
        `${KPI_BASES[2]}/get/${id}`,
      ],
      {},
      "reportsService.getKPIById"
    ),
  updateKPI: (id, data) =>
    callWithFallbacks(
      [
        `${KPI_BASES[0]}/${id}`,
        `${KPI_BASES[0]}/update`,
        `${KPI_BASES[1]}/update`,
        `${KPI_BASES[2]}/update`,
      ],
      {
        method: "PUT",
        body: JSON.stringify(data),
      },
      "reportsService.updateKPI"
    ),
  deleteKPI: (id) =>
    callWithFallbacks(
      [
        `${KPI_BASES[0]}/${id}`,
        `${KPI_BASES[1]}/del/${id}`,
        `${KPI_BASES[2]}/del/${id}`,
      ],
      {
        method: "DELETE",
      },
      "reportsService.deleteKPI"
    ),
  getKPIs: (period) => apiCall(`/api/reports/kpis?period=${period}`),
  getStockTurnover: (period) => apiCall(`/api/reports/stock-turnover?period=${period}`),
  getExpiryWastage: (period) => apiCall(`/api/reports/expiry-wastage?period=${period}`),
  getDispensingTrends: (period) => apiCall(`/api/reports/dispensing-trends?period=${period}`),
  getInventoryHealth: () => apiCall("/api/reports/inventory-health"),
};