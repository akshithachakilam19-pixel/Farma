// ================================
// Auth Service  (AuthController)
// POST /pharmaShelf/auth/login
// POST /pharmaShelf/auth/signup
// ================================

import { apiCall, decodeToken } from "./apiClient";
import { SERVICE_PREFIX, serviceUrl } from "./serviceEndpoints";

export const authAPI = {
  login: async (email, password) => {
    const response = await apiCall(serviceUrl(SERVICE_PREFIX.auth, "/login"), {
      method: "POST",
      body: JSON.stringify({ email, password }),
      skipAuthRedirect: true,
    });

    // Response should always have token property from apiClient normalization
    // But handle legacy responses just in case
    let token = null;
    
    if (response?.token) {
      token = response.token;
    } else if (response?.accessToken) {
      token = response.accessToken;
    } else if (response?.data?.token) {
      token = response.data.token;
    } else if (typeof response === "string") {
      token = response;
    }

    // Store token and decode user info
    if (token) {
      localStorage.setItem("authToken", token);
      
      // Decode token to extract user info
      const decoded = decodeToken(token);
      if (decoded) {
        const userInfo = {
          username: decoded.sub || decoded.username,
          userId: decoded.userId,
          role: decoded.role,
          email: email,
        };
        localStorage.setItem("userInfo", JSON.stringify(userInfo));
        console.log("✅ User authenticated:", userInfo);
        return { token, ...userInfo };
      }
      
      return { token, ...response };
    }

    return response;
  },

  signup: async (userData) => {
    const response = await apiCall(serviceUrl(SERVICE_PREFIX.auth, "/signup"), {
      method: "POST",
      body: JSON.stringify(userData),
      skipAuthRedirect: true,
    });

    // If signup returns a token, store it
    let token = null;
    if (response?.token) {
      token = response.token;
    } else if (response?.accessToken) {
      token = response.accessToken;
    }

    if (token) {
      localStorage.setItem("authToken", token);
      const decoded = decodeToken(token);
      if (decoded) {
        const userInfo = {
          username: decoded.sub || decoded.username,
          userId: decoded.userId,
          role: decoded.role,
          email: userData.email,
        };
        localStorage.setItem("userInfo", JSON.stringify(userInfo));
      }
    }

    return response;
  },

  logout: () => {
    localStorage.removeItem("authToken");
    localStorage.removeItem("userInfo");
    return Promise.resolve();
  },

  getCurrentUser: () => {
    const userInfo = localStorage.getItem("userInfo");
    return userInfo ? JSON.parse(userInfo) : null;
  },

  getToken: () => {
    return localStorage.getItem("authToken");
  },

  isAuthenticated: () => {
    const token = localStorage.getItem("authToken");
    if (!token) return false;

    try {
      const parts = token.split(".");
      if (parts.length !== 3) return false;
      const payload = JSON.parse(atob(parts[1]));
      return payload.exp * 1000 > Date.now();
    } catch {
      return false;
    }
  },

  hasRole: (role) => {
    const userInfo = localStorage.getItem("userInfo");
    if (!userInfo) return false;
    const user = JSON.parse(userInfo);
    return user.role === role || (Array.isArray(user.roles) && user.roles.includes(role));
  },

  hasAnyRole: (roles) => {
    const userInfo = localStorage.getItem("userInfo");
    if (!userInfo) return false;
    const user = JSON.parse(userInfo);
    return roles.includes(user.role) || (Array.isArray(user.roles) && roles.some(r => user.roles.includes(r)));
  },
};
