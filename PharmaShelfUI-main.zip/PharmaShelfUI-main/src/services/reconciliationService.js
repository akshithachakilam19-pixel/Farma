const BASE_URL = "/pharmaShelf/reconciliations";
 
const fallbackVariances = [
  {
    id: 1,
    reconId: 1,
    countId: 1201,
    product: "Count ID 1201",
    batch: "REC-0001",
    location: "User 101",
    expected: 250,
    counted: 245,
    variance: -5,
    adjustedBy: 101,
    adjustedAt: "2026-04-20T10:30:00",
    reason: "Variance: -5",
    status: "Pending",
  },
  {
    id: 2,
    reconId: 2,
    countId: 1202,
    product: "Count ID 1202",
    batch: "REC-0002",
    location: "User 102",
    expected: 1200,
    counted: 1205,
    variance: 5,
    adjustedBy: 102,
    adjustedAt: "2026-04-19T16:45:00",
    reason: "Variance: +5",
    status: "Completed",
  },
  {
    id: 3,
    reconId: 3,
    countId: 1203,
    product: "Count ID 1203",
    batch: "REC-0003",
    location: "User 103",
    expected: 320,
    counted: 318,
    variance: -2,
    adjustedBy: 103,
    adjustedAt: "2026-04-18T14:00:00",
    reason: "Variance: -2",
    status: "Completed",
  },
];
 
const formatVariance = (value) => {
  if (value == null || Number.isNaN(Number(value))) return "0";
  const n = Number(value);
  return n > 0 ? `+${n}` : `${n}`;
};
 
function normalizeReconciliation(item) {
  const reconId = item?.reconId ?? item?.id ?? null;
  const countId = item?.countId ?? null;
  const expected = item?.expectedQuantity ?? item?.expected ?? 0;
  const counted = item?.countedQuantity ?? item?.counted ?? 0;
  const variance = item?.variance ?? Number(counted) - Number(expected);
  const adjustedBy = item?.adjustedBy ?? null;
  const adjustedAt = item?.adjustedAt ?? null;
 
  return {
    id: reconId ?? Date.now(),
    reconId,
    countId,
    product: countId != null ? `Count ID ${countId}` : "Count ID —",
    batch: reconId != null ? `REC-${String(reconId).padStart(4, "0")}` : "REC-—",
    location: adjustedBy != null ? `User ${adjustedBy}` : "User —",
    expected: Number(expected) || 0,
    counted: Number(counted) || 0,
    variance: Number(variance) || 0,
    adjustedBy,
    adjustedAt,
    reason: `Variance: ${formatVariance(variance)}`,
    status: item?.status ?? "Pending",
  };
}
 
export async function fetchAllReconciliations() {
  try {
    const res = await fetch(BASE_URL);
    if (!res.ok) throw new Error("Failed to fetch reconciliations");
    const data = await res.json();
    return Array.isArray(data) ? data.map(normalizeReconciliation) : [];
  } catch (err) {
    console.warn("Backend unavailable, using fallback reconciliation data:", err.message);
    return fallbackVariances;
  }
}
 
export async function createReconciliation(dto) {
  const res = await fetch(`${BASE_URL}/insert`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dto),
  });
  if (!res.ok) throw new Error("Failed to create reconciliation");
  return normalizeReconciliation(await res.json());
}
 
export async function updateReconciliation(id, dto) {
  const res = await fetch(`${BASE_URL}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dto),
  });
  if (!res.ok) throw new Error("Failed to update reconciliation");
  return normalizeReconciliation(await res.json());
}
 
export async function deleteReconciliation(id) {
  const res = await fetch(`${BASE_URL}/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error("Failed to delete reconciliation");
}
 
export async function fetchReconciliationById(id) {
  const res = await fetch(`${BASE_URL}/${id}`);
  if (!res.ok) throw new Error("Failed to fetch reconciliation");
  return normalizeReconciliation(await res.json());
}
 