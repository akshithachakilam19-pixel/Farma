// ================================
// Return Service  (ReturnController)
// GET  /pharmaShelf/returns
// GET  /pharmaShelf/returns/:id
// POST /pharmaShelf/returns
// PUT  /pharmaShelf/returns/:id
// DELETE /pharmaShelf/returns/:id
// ================================

import { apiCall } from "./apiClient";
import { SERVICE_PREFIX, serviceUrl } from "./serviceEndpoints";

export const returnAPI = {
  getAll: () =>
    apiCall(serviceUrl(SERVICE_PREFIX.returns), {
      method: "GET",
    }).catch(() => []),

  getById: (id) =>
    apiCall(serviceUrl(SERVICE_PREFIX.returns, `/${id}`), {
      method: "GET",
    }),

  create: (data) =>
    apiCall(serviceUrl(SERVICE_PREFIX.returns), {
      method: "POST",
      body: JSON.stringify(data),
    }),

  update: (id, data) =>
    apiCall(serviceUrl(SERVICE_PREFIX.returns, `/${id}`), {
      method: "PUT",
      body: JSON.stringify(data),
    }),

  delete: (id) =>
    apiCall(serviceUrl(SERVICE_PREFIX.returns, `/${id}`), {
      method: "DELETE",
    }),
};
// Alias export for component compatibility
export const returnService = returnAPI;