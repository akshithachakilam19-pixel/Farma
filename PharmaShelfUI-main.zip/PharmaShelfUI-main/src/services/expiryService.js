import { apiCall } from "./apiClient";
import { batchesAPI } from "./batchesService";
import { SERVICE_PREFIX, serviceUrl } from "./serviceEndpoints";
 
export const expiryService = {
  getBatches: () => batchesAPI.getAll(),
  getAlerts: () =>
    apiCall(serviceUrl(SERVICE_PREFIX.expiry, "/all"), {
      method: "GET"
    }).catch(() => []),
  createAlert: (data) =>
    apiCall(serviceUrl(SERVICE_PREFIX.expiry, "/insert"), {
      method: "POST",
      body: JSON.stringify(data),
    }),
  createAlerts: (data) =>
    apiCall(serviceUrl(SERVICE_PREFIX.expiry, "/insert"), {
      method: "POST",
      body: JSON.stringify(data),
    }),
  updateAlert: (data) =>
    apiCall(serviceUrl(SERVICE_PREFIX.expiry, "/update"), {
      method: "PUT",
      body: JSON.stringify(data),
    }),
  archiveBatch: (batchId) =>
    apiCall(serviceUrl(SERVICE_PREFIX.batches, `/${batchId}`), {
      method: "PUT",
      body: JSON.stringify({ status: "ARCHIVED" }),
    }),
};