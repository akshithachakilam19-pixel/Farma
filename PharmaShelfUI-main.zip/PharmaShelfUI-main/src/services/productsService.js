// ================================
// Products Service  (ProductsController)
// GET    /pharmaShelf/products/fetchAllProducts
// GET    /pharmaShelf/products/fetchByProductId/{id}
// POST   /pharmaShelf/products/insertProduct
// PUT    /pharmaShelf/products/updateProduct/{id}
// DELETE /pharmaShelf/products/deleteProduct/{id}
// ================================

import { apiCall } from './apiClient';
 
// Products API (Matches Java ProductController)
export const productsAPI = {
  getAll: () => apiCall('/pharmaShelf/products/fetchAllProducts'),
  getById: (id) => apiCall(`/pharmaShelf/products/fetchByProductId/${id}`),
  create: (data) =>
    apiCall('/pharmaShelf/products/insertProduct', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  update: (id, data) =>
    apiCall(`/pharmaShelf/products/updateProduct/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  delete: (id) =>
    apiCall(`/pharmaShelf/products/deleteProduct/${id}`, { method: 'DELETE' }),
};

// Alias export for component compatibility
export const productsService = productsAPI;
