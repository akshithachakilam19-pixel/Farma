// ================================
// Batches Service  (BatchesController)
// GET    /pharmaShelf/batches/fetchAllBatches
// GET    /pharmaShelf/batches/fetchByBatchId/{id}
// GET    /pharmaShelf/batches/fetchByProductId/{productId}
// POST   /pharmaShelf/batches/insertBatch
// PUT    /pharmaShelf/batches/updateBatch/{id}
// DELETE /pharmaShelf/batches/DeleteBatch/{id}
// ================================

import { apiCall } from './apiClient';
 
// Batches API (Matches Java BatchController)
export const batchesAPI = {
  getAll: () => apiCall('/pharmaShelf/batches/fetchAllBatches'),
  getById: (id) => apiCall(`/pharmaShelf/batches/fetchByBatchId/${id}`),
  getByProduct: (productId) =>
    apiCall(`/pharmaShelf/batches/fetchByProductId/${productId}`),
  create: (data) =>
    apiCall('/pharmaShelf/batches/insertBatch', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  update: (id, data) =>
    apiCall(`/pharmaShelf/batches/updateBatch/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  delete: (id) =>
    apiCall(`/pharmaShelf/batches/DeleteBatch/${id}`, { method: 'DELETE' }),
};

// Alias export for component compatibility
export const batchesService = batchesAPI;

