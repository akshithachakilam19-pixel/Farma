import { callWithFallbacks } from "./requestFallback";
 
const KPI_BASES = ["/api/kpis", "/pharmaShelf/KPI", "/pharmaShelf/kpi"];
 
export const kpiService = {
  getAll: () =>
    callWithFallbacks(
      [
        `${KPI_BASES[0]}`,
        `${KPI_BASES[1]}/all`,
        `${KPI_BASES[2]}/all`,
      ],
      {},
      "kpiService.getAll"
    ),
 
  getById: (id) =>
    callWithFallbacks(
      [
        `${KPI_BASES[0]}/${id}`,
        `${KPI_BASES[1]}/get/${id}`,
        `${KPI_BASES[2]}/get/${id}`,
      ],
      {},
      "kpiService.getById"
    ),
 
  create: (dto) =>
    callWithFallbacks(
      [
        `${KPI_BASES[0]}`,
        `${KPI_BASES[1]}/insert`,
        `${KPI_BASES[2]}/insert`,
      ],
      {
        method: "POST",
        body: JSON.stringify(dto),
      },
      "kpiService.create"
    ),
 
  update: (dto) => {
    const id = dto?.id ?? dto?.kpiId ?? dto?.KPIId;
    return callWithFallbacks(
      [
        id ? `${KPI_BASES[0]}/${id}` : null,
        `${KPI_BASES[0]}/update`,
        `${KPI_BASES[1]}/update`,
        `${KPI_BASES[2]}/update`,
      ],
      {
        method: "PUT",
        body: JSON.stringify(dto),
      },
      "kpiService.update"
    );
  },
 
  delete: (id) =>
    callWithFallbacks(
      [
        `${KPI_BASES[0]}/${id}`,
        `${KPI_BASES[1]}/del/${id}`,
        `${KPI_BASES[2]}/del/${id}`,
      ],
      {
        method: "DELETE",
      },
      "kpiService.delete"
    ),
};

// Alias export for API barrel compatibility
export const kpiAPI = kpiService;
 
 