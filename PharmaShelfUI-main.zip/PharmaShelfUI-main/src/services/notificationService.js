import { apiCall } from "./apiClient";

const API_BASE = "/pharmaShelf/notifications";

/**
 * Extract userId from JWT token stored in localStorage
 */
function extractUserIdFromToken() {
  const token = localStorage.getItem("authToken");
  if (!token) return null;

  try {
    const payload = token.split(".")[1];
    const decoded = JSON.parse(atob(payload));
    return (
      decoded.userId ??
      decoded.userID ??
      decoded.userid ??
      decoded.UserID ??
      decoded.id ??
      null
    );
  } catch {
    return null;
  }
}

/**
 * Get current user ID
 */
function getCurrentUserId() {
  const currentUser = JSON.parse(localStorage.getItem("pharmaShelfUser") || "null");
  const tokenUserId = extractUserIdFromToken();
  
  return (
    currentUser?.userId ??
    currentUser?.userID ??
    currentUser?.userid ??
    currentUser?.UserID ??
    tokenUserId ??
    null
  );
}

export const notificationService = {
  /**
   * GET /pharmaShelf/notifications/fetchNotificationsByUserId/{userId}
   * Fetch all notifications for the current user
   */
  fetchForUser: async (userId = null) => {
    const uid = userId || getCurrentUserId();
    if (!uid) {
      throw new Error("User ID not available");
    }
    
    try {
      const response = await apiCall(`${API_BASE}/fetchNotificationsByUserId/${uid}`);
      // Response structure: { notifications: [...] }
      if (response && response.notifications) {
        return response.notifications;
      }
      return Array.isArray(response) ? response : [];
    } catch (error) {
      console.error("❌ Failed to fetch notifications:", error);
      throw error;
    }
  },

  /**
   * POST /pharmaShelf/notifications/createNotification
   * Create a new notification
   */
  create: async (notificationData) => {
    if (!notificationData) {
      throw new Error("Notification data is required");
    }

    try {
      return await apiCall(`${API_BASE}/createNotification`, {
        method: "POST",
        body: JSON.stringify(notificationData),
      });
    } catch (error) {
      console.error("❌ Failed to create notification:", error);
      throw error;
    }
  },

  /**
   * POST /pharmaShelf/notifications/processAlertEvent
   * Process an alert event (called by microservices)
   */
  processAlertEvent: async (alertEvent) => {
    if (!alertEvent) {
      throw new Error("Alert event data is required");
    }

    try {
      return await apiCall(`${API_BASE}/processAlertEvent`, {
        method: "POST",
        body: JSON.stringify(alertEvent),
      });
    } catch (error) {
      console.error("❌ Failed to process alert event:", error);
      throw error;
    }
  },

  /**
   * PUT /pharmaShelf/notifications/markAsRead/{notificationId}
   * Mark a notification as read
   */
  markAsRead: async (notificationId) => {
    if (!notificationId) {
      throw new Error("Notification ID is required");
    }

    try {
      return await apiCall(`${API_BASE}/markAsRead/${notificationId}`, {
        method: "PUT",
      });
    } catch (error) {
      console.error("❌ Failed to mark notification as read:", error);
      throw error;
    }
  },

  /**
   * Helper to get unread count
   */
  getUnreadCount: (notifications) => {
    if (!Array.isArray(notifications)) return 0;
    return notifications.filter(
      (n) => String(n.status || "").toUpperCase() === "UNREAD"
    ).length;
  },

  /**
   * Helper to get notification icon
   */
  getNotificationIcon: (category = "") => {
    const normalizedCategory = String(category).toUpperCase();
    
    const iconMap = {
      EXPIRY: "AlertTriangle",
      STOCK: "Package",
      RECALL: "XCircle",
      PO: "FileText",
      QUARANTINE: "Lock",
      DISPENSE: "PillBottle",
      RECALL_INITIATED: "AlertTriangle",
    };
    
    return iconMap[normalizedCategory] || "Bell";
  },

  /**
   * Helper to get relative time
   */
  getRelativeTime: (createdAt) => {
    if (!createdAt) return "Just now";

    const date = new Date(createdAt);
    if (Number.isNaN(date.getTime())) return "Just now";

    const diffMs = Date.now() - date.getTime();
    const diffMinutes = Math.floor(diffMs / (1000 * 60));

    if (diffMinutes < 1) return "Just now";
    if (diffMinutes < 60) {
      return `${diffMinutes} minute${diffMinutes === 1 ? "" : "s"} ago`;
    }

    const diffHours = Math.floor(diffMinutes / 60);
    if (diffHours < 24) {
      return `${diffHours} hour${diffHours === 1 ? "" : "s"} ago`;
    }

    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} day${diffDays === 1 ? "" : "s"} ago`;
  },
};
