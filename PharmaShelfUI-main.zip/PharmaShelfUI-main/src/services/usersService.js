// ================================
// Users Service  (UsersController)
// GET    /pharmaShelf/users/fetchAllUsers
// GET    /pharmaShelf/users/fetchUserById/:id
// POST   /pharmaShelf/users/registerUser
// PUT    /pharmaShelf/users/updateUserById/:id
// ================================

import { apiCall } from "./apiClient";
import { SERVICE_PREFIX, serviceUrl } from "./serviceEndpoints";

export const usersAPI = {
  // ADMIN ONLY
  getAll: () => apiCall(serviceUrl(SERVICE_PREFIX.users, "/fetchAllUsers")),

  // ADMIN ONLY
  getById: (id) => apiCall(serviceUrl(SERVICE_PREFIX.users, `/fetchUserById/${id}`)),

  // ADMIN ONLY
  create: (data) =>
    apiCall(serviceUrl(SERVICE_PREFIX.users, "/registerUser"), {
      method: "POST",
      body: JSON.stringify(data),
    }),

  // ADMIN ONLY
  update: (id, data) =>
    apiCall(serviceUrl(SERVICE_PREFIX.users, `/updateUserById/${id}`), {
      method: "PUT",
      body: JSON.stringify(data),
    }),
};
