// ================================
// API barrel file - re-exports all service modules.
// All existing component imports (e.g. import { authAPI } from "../../services/api")
// continue to work without any changes.
// ================================

export { authAPI }          from "./authService";
export { usersAPI }         from "./usersService";
export { auditAPI }         from "./auditService";
export { notificationsAPI } from "./notificationsService";
export { alertRulesAPI }    from "./alertRulesService";
export { productsAPI }      from "./productsService";
export { batchesAPI }       from "./batchesService";
export { dispensingAPI }    from "./dispensingService";
