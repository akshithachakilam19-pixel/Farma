// ================================
// Notifications Service  (NotificationsController)
// GET  /pharmaShelf/notifications/fetchNotificationsByUserId/:userId
// POST /pharmaShelf/notifications/createNotification
// ================================
 
import { apiCall } from "./apiClient";
 
export const notificationsAPI = {
  getByUserId: (userId) =>
    apiCall(`/pharmaShelf/notifications/fetchNotificationsByUserId/${userId}`),
 
  // ADMIN ONLY
  create: (data) =>
    apiCall("/pharmaShelf/notifications/createNotification", {
      method: "POST",
      body: JSON.stringify(data),
    }),
 
  markAsRead: (notificationId) =>
    apiCall(`/pharmaShelf/notifications/markAsRead/${notificationId}`, {
      method: "PUT",
    }),
};
