import { apiCall, API_BASE_URL } from './apiClient';
const MODULE43_URL = API_BASE_URL;

// Goods Receipt API (Matches Java GoodsReceiptController)
export const goodsReceiptAPI = {
  getAll: () =>
    apiCall('/pharmaShelf/goodsReceipts/fetchAllGoodsReceipts', {}, MODULE43_URL),
  getById: (grId) =>
    apiCall(`/pharmaShelf/goodsReceipts/fetchGoodsReceiptById/${grId}`, {}, MODULE43_URL),
  getByPoId: (poId) =>
    apiCall(`/pharmaShelf/goodsReceipts/fetchGoodsReceiptsByPoId/po/${poId}`, {}, MODULE43_URL),
  getBySupplierId: (supplierId) =>
    apiCall(`/pharmaShelf/goodsReceipts/fetchGoodsReceiptsBySupplierId/supplier/${supplierId}`, {}, MODULE43_URL),
  getByStatus: (status) =>
    apiCall(`/pharmaShelf/goodsReceipts/getGoodsReceiptsByStatus/status/${status}`, {}, MODULE43_URL),
  create: (data) =>
    apiCall('/pharmaShelf/goodsReceipts/createGoodsReceipt', {
      method: 'POST',
      body: JSON.stringify(data),
    }, MODULE43_URL),
  update: (grId, data) =>
    apiCall(`/pharmaShelf/goodsReceipts/updateGoodsReceipt/${grId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }, MODULE43_URL),
  delete: (grId) =>
    apiCall(`/pharmaShelf/goodsReceipts/deleteGoodsReceipt/${grId}`, {
      method: 'DELETE',
    }, MODULE43_URL),
};