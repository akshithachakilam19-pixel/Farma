const withLeadingSlash = (value, fallback) => {
  const raw = String(value || fallback || "").trim();
  if (!raw) return "";
  return raw.startsWith("/") ? raw.replace(/\/$/, "") : `/${raw.replace(/\/$/, "")}`;
};

const CORE_PREFIX = withLeadingSlash(import.meta.env.VITE_CORE_API_PREFIX, "/pharmaShelf");

export const SERVICE_PREFIX = {
  core: CORE_PREFIX,
  auth: withLeadingSlash(import.meta.env.VITE_AUTH_API_PREFIX, `${CORE_PREFIX}/auth`),
  users: withLeadingSlash(import.meta.env.VITE_USERS_API_PREFIX, `${CORE_PREFIX}/users`),
  products: withLeadingSlash(import.meta.env.VITE_PRODUCTS_API_PREFIX, `${CORE_PREFIX}/products`),
  batches: withLeadingSlash(import.meta.env.VITE_BATCHES_API_PREFIX, `${CORE_PREFIX}/batches`),
  dispenses: withLeadingSlash(import.meta.env.VITE_DISPENSES_API_PREFIX, `${CORE_PREFIX}/dispenses`),
  notifications: withLeadingSlash(import.meta.env.VITE_NOTIFICATIONS_API_PREFIX, `${CORE_PREFIX}/notifications`),
  returns: withLeadingSlash(import.meta.env.VITE_RETURNS_API_PREFIX, `${CORE_PREFIX}/returns`),
  consumptionLogs: withLeadingSlash(import.meta.env.VITE_CONSUMPTION_API_PREFIX, `${CORE_PREFIX}/consumption-logs`),
  expiry: withLeadingSlash(import.meta.env.VITE_EXPIRY_API_PREFIX, `${CORE_PREFIX}/expiry`),
  goodsReceipt: withLeadingSlash(import.meta.env.VITE_GOODS_RECEIPT_API_PREFIX, `${CORE_PREFIX}/goods-receipt`),
  stockCount: withLeadingSlash(import.meta.env.VITE_STOCK_COUNT_API_PREFIX, `${CORE_PREFIX}/stock-count`),
  kpi: withLeadingSlash(import.meta.env.VITE_KPI_API_PREFIX, `${CORE_PREFIX}/KPI`),
  reports: withLeadingSlash(import.meta.env.VITE_REPORTS_API_PREFIX, `${CORE_PREFIX}/reports`),
  alertRules: withLeadingSlash(import.meta.env.VITE_ALERT_RULES_API_PREFIX, `${CORE_PREFIX}/alert-rules`),
  audit: withLeadingSlash(import.meta.env.VITE_AUDIT_API_PREFIX, `${CORE_PREFIX}/audit`),
  recalls: withLeadingSlash(import.meta.env.VITE_RECALLS_API_PREFIX, `${CORE_PREFIX}/recalls`),
};

export const serviceUrl = (prefix, path = "") => {
  const normalizedPath = String(path || "").trim();
  if (!normalizedPath) return prefix;
  return `${prefix}${normalizedPath.startsWith("/") ? normalizedPath : `/${normalizedPath}`}`;
};
