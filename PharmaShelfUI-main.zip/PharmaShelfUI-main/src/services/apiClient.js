// ================================
// Base API Client
// Shared HTTP helper used by all service modules
// ================================

const configuredApiBase = (import.meta.env.VITE_API_BASE_URL || "").trim();

// In Vite dev, use relative paths so requests go through vite proxy and avoid CORS.
// In non-dev builds, use configured absolute base URL.
export const API_BASE_URL = import.meta.env.DEV ? "" : configuredApiBase;

/**
 * Get JWT token from localStorage
 */
export function getAuthToken() {
  return localStorage.getItem("authToken");
}

/**
 * Get user info from localStorage
 */
export function getUserInfo() {
  const userInfo = localStorage.getItem("userInfo");
  return userInfo ? JSON.parse(userInfo) : null;
}

/**
 * Check if token is expired
 */
export function isTokenExpired(token) {
  if (!token) return true;
  
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return true;
    
    const payload = JSON.parse(atob(parts[1]));
    return payload.exp * 1000 < Date.now();
  } catch {
    return true;
  }
}

/**
 * Decode JWT token to get user info
 */
export function decodeToken(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    
    return JSON.parse(atob(parts[1]));
  } catch {
    return null;
  }
}

export async function apiCall(endpoint, options = {}) {
  const { skipAuthRedirect = false, headers: customHeaders = {}, ...fetchOptions } = options;
  const url = `${API_BASE_URL}${endpoint}`;

  const headers = {
    "Content-Type": "application/json",
    ...customHeaders,
  };

  // Add JWT token if available and endpoint requires auth
  if (!skipAuthRedirect) {
    const token = getAuthToken();
    if (token && !isTokenExpired(token)) {
      headers["Authorization"] = `Bearer ${token}`;
      const decoded = decodeToken(token);
      console.log("🔐 Token details:", { role: decoded?.role, email: decoded?.sub, userId: decoded?.userId });
    } else {
      console.warn("⚠️ No valid token found for auth");
    }
  }

  console.log("📤 API Request:", { endpoint, url, hasAuth: !!headers.Authorization });

  const response = await fetch(url, {
    ...fetchOptions,
    headers,
  });

  if (!response.ok) {
    // Handle 401 Unauthorized
    if (response.status === 401) {
      localStorage.removeItem("authToken");
      localStorage.removeItem("userInfo");
      if (!skipAuthRedirect) {
        window.location.href = "/login";
      }
    }

    let errorText = "";
    try {
      const errBody = await response.text();
      try {
        const parsed = JSON.parse(errBody);
        errorText = parsed?.message || parsed?.error || errBody;
      } catch {
        errorText = errBody;
      }
    } catch {
      errorText = response.statusText;
    }
    
    const error = new Error(errorText || `Request failed (${response.status})`);
    error.status = response.status;
    error.endpoint = endpoint;
    
    console.error("❌ API Error:", {
      endpoint,
      status: response.status,
      message: errorText,
      error
    });

    throw error;
  }

  const contentType = response.headers.get("content-type");
  
  // Handle plain text responses (like JWT tokens from login)
  if (!contentType || !contentType.includes("application/json")) {
    const text = await response.text();
    console.log("📄 Plain text response:", { contentType, text, textLength: text?.length });
    
    // If it looks like a JWT token (3 dot-separated parts), return as object with token key
    if (text && text.includes(".") && (text.match(/\./g) || []).length === 2) {
      console.log("✅ Detected JWT token in response, wrapping as {token: ...}");
      return { token: text };
    }
    return text;
  }

  return response.json();
}

/**
 * Call an API with fallback endpoints
 * Tries each endpoint in order until one succeeds
 * @param {string[]} endpoints - Array of endpoints to try
 * @param {object} options - Fetch options (method, body, headers, etc.)
 * @param {string} context - Context for logging
 * @returns {Promise} Response from first successful endpoint
 */
export async function callWithFallbacks(endpoints, options = {}, context = "") {
  const cleanEndpoints = endpoints.filter(e => e !== null && e !== undefined && e !== "");
  
  if (cleanEndpoints.length === 0) {
    throw new Error("No valid endpoints provided for callWithFallbacks");
  }

  let lastError = null;

  for (let i = 0; i < cleanEndpoints.length; i++) {
    const endpoint = cleanEndpoints[i];
    try {
      console.log(`[${context}] Attempting endpoint (${i + 1}/${cleanEndpoints.length}): ${endpoint}`);
      return await apiCall(endpoint, options);
    } catch (error) {
      lastError = error;
      console.warn(`[${context}] Endpoint failed: ${endpoint}`, error.message);
      
      // If it's the last endpoint, throw the error
      if (i === cleanEndpoints.length - 1) {
        throw error;
      }
      // Otherwise, try the next endpoint
    }
  }

  throw lastError || new Error(`All fallback endpoints failed for ${context}`);
}

