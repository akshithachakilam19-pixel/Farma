// ================================
// Audit Log Service  (AuditLogController)
// GET  /pharmaShelf/audit
// ================================

import { apiCall } from "./apiClient";

export const auditAPI = {
  // ✅ READ ONLY - No manual entry creation
  // Audit logs are immutable and append-only
  // Entries are recorded automatically by the system only

  // Get all audit logs
  getAll: () => apiCall("/pharmaShelf/audit"),
};