// ================================
// Alert Rules Service  (AlertRulesController)
// GET  /pharmaShelf/alert-rules/fetchAllAlertRules
// GET  /pharmaShelf/alert-rules/fetchActiveAlertRules
// POST /pharmaShelf/alert-rules/createAlertRule
// ================================
 
import { apiCall } from "./apiClient";
 
export const alertRulesAPI = {
  // ADMIN ONLY
  getAll: () => apiCall("/pharmaShelf/alert-rules/fetchAllAlertRules"),
 
  // ADMIN ONLY
  getActive: () => apiCall("/pharmaShelf/alert-rules/fetchActiveAlertRules"),
 
  // ADMIN ONLY
  create: (data) =>
    apiCall("/pharmaShelf/alert-rules/createAlertRule", {
      method: "POST",
      body: JSON.stringify(data),
    }),
};