import React, { useEffect, useMemo, useRef, useState } from "react";
import { Users, ShoppingCart, Package, ArrowUp, ArrowDown } from "lucide-react";
import SupplierComponent from "./SupplierComponent";
import { supplierAPI, purchaseOrderAPI, goodsReceiptAPI, productsAPI, batchesAPI } from "../../services/api";
 
const PAGE_SIZE = 10;
 
export function GoodsReceipt() {
  const [activeTab, setActiveTab] = useState("suppliers");
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState(null);
 
  const [suppliers, setSuppliers] = useState([]);
  const [purchaseOrders, setPurchaseOrders] = useState([]);
  const [goodsReceipts, setGoodsReceipts] = useState([]);
  const [products, setProducts] = useState([]);
  const [batches, setBatches] = useState([]);
 
  const [toast, setToast] = useState(null);
  const toastTimer = useRef(null);
  function showToast(msg, type = "success") { if (toastTimer.current) clearTimeout(toastTimer.current); setToast({ message: msg, type }); toastTimer.current = setTimeout(() => setToast(null), 3000); }
 
  async function loadData() {
    setLoading(true); setLoadError(null);
    try {
      const [sl, pl, gl, pr, ba] = await Promise.all([
        supplierAPI.getAll().catch((e) => { console.error("Suppliers fetch failed:", e); return []; }),
        purchaseOrderAPI.getAll().catch((e) => { console.error("Purchase Orders fetch failed:", e); return []; }),
        goodsReceiptAPI.getAll().catch((e) => { console.error("Goods Receipts fetch failed:", e); return []; }),
        productsAPI.getAll().catch((e) => { console.error("Products fetch failed:", e); return []; }),
        batchesAPI.getAll().catch((e) => { console.error("Batches fetch failed:", e); return []; }),
      ]);
      setSuppliers(Array.isArray(sl) ? sl : []);
      setPurchaseOrders(Array.isArray(pl) ? pl : []);
      setGoodsReceipts(Array.isArray(gl) ? gl : []);
      setProducts(Array.isArray(pr) ? pr : []);
      setBatches(Array.isArray(ba) ? ba : []);
    } catch (e) { setLoadError(e?.message || String(e)); }
    finally { setLoading(false); }
  }
 
  useEffect(() => { loadData(); }, []);
 
  function getSupplierName(id) { return suppliers.find(s => Number(s.supplierId) === Number(id))?.name || `Supplier #${id}`; }
  function getSupplierIdFromGR(gr) { if (!gr) return null; if (gr.supplierId != null) return Number(gr.supplierId); const po = purchaseOrders.find(p => Number(p.poId) === Number(gr.poId)); return po?.supplierId ?? null; }
  function getSupplierNameFromGR(gr) { const id = getSupplierIdFromGR(gr); return id == null ? "—" : getSupplierName(id); }
 
  return (
    <div className="space-y-6 p-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Goods Receipt & Purchase Orders</h1>
      </div>
 
      {loadError && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
          <strong>Failed to load data:</strong> {loadError}
          <button onClick={loadData} className="ml-4 underline font-medium">Retry</button>
        </div>
      )}
 
      {/* Summary Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          {
            label: "Total Suppliers",
            value: suppliers.length,
            icon: Users,
            color: "bg-orange-500",
          },
          {
            label: "Purchase Orders",
            value: purchaseOrders.length,
            icon: ShoppingCart,
            color: "bg-indigo-500",
          },
          {
            label: "Goods Receipts",
            value: goodsReceipts.length,
            icon: Package,
            color: "bg-purple-500",
          },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="text-gray-600 text-sm font-medium">{label}</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">{value}</p>
              </div>
              <div className={`${color} p-3 rounded-lg`}>
                <Icon className="size-6 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>
 
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="border-b border-gray-200">
          <div className="flex">
            {[
              { key: 'suppliers', label: `Suppliers (${suppliers.length})` },
            ].map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex-1 px-6 py-2 text-sm font-semibold transition-colors whitespace-nowrap ${
                  activeTab === tab.key
                    ? 'text-[#3C8C85] border-b-2 border-[#3C8C85] bg-[#3C8C85]/10'
                    : 'text-gray-500 hover:text-[#3C8C85] hover:bg-[#3C8C85]/5'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
        <div className="p-6">
          {activeTab === 'suppliers' && (
            <SupplierComponent
              allSuppliers={suppliers}
              onDataChange={loadData}
              showToast={showToast}
            />
          )}
        </div>
      </div>

      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-4 right-4 z-50">
          <div className={`px-4 py-3 rounded-lg shadow-lg text-white ${toast.type === 'error' ? 'bg-red-600' : 'bg-green-600'}`}>
            {toast.message}
          </div>
        </div>
      )}
    </div>
  );
}