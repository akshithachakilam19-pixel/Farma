 
import React, { useState, useMemo, useRef, useEffect } from "react";
import { Download, CheckCircle2, XCircle, Plus, MoreVertical, Edit2, Trash2, X, Search } from "lucide-react";
import { batchesAPI } from "../../services/api";
 
const PAGE_SIZE = 10;
 
// Simple Excel export utility
const exportToExcel = (data, fileName) => {
  if (!data || data.length === 0) {
    alert("No data to export");
    return;
  }
  const headers = Object.keys(data[0]);
  let csv = headers.join(",") + "\n";
  data.forEach(row => {
    csv += headers.map(header => {
      let value = row[header];
      if (value === null || value === undefined) value = "";
      if (String(value).includes(",") || String(value).includes('"')) {
        value = '"' + String(value).replace(/"/g, '""') + '"';
      }
      return value;
    }).join(",") + "\n";
  });
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);
  link.setAttribute("href", url);
  link.setAttribute("download", fileName + ".csv");
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
 
export default function Batch({ allBatches, allProducts, showToast, onDataChange }) {
  const [currentPage, setCurrentPage] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [editingBatch, setEditingBatch] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const [openActionsMenu, setOpenActionsMenu] = useState(null);
  const actionsMenuRef = useRef(null);
  const actionsTriggerRef = useRef(null);
 
  // New filter states
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterExpiryDateFrom, setFilterExpiryDateFrom] = useState("");
  const [filterExpiryDateTo, setFilterExpiryDateTo] = useState("");
 
  const [form, setForm] = useState({
    productId: "",
    lotNumber: "",
    manufacturer: "",
    manufactureDate: "",
    expiryDate: "",
    quantityReceived: "",
    quantityAvailable: "",
    locationId: "1",
    status: "ACTIVE",
  });
 
  const [lotNumberError, setLotNumberError] = useState("");
  const [manufacturerError, setManufacturerError] = useState("");
 
  const lotNumberRegex = /^[a-zA-Z0-9\s-]*$/;
  const alphanumericSpaceRegex = /^[a-zA-Z0-9\s]*$/;
 
  const validateLotNumber = (value) => {
    if (!value.trim()) {
      setLotNumberError("Lot Number is required.");
      return false;
    }
    if (!lotNumberRegex.test(value)) {
      setLotNumberError("Cannot enter special characters");
      return false;
    }
    setLotNumberError("");
    return true;
  };
 
  const validateManufacturer = (value) => {
    if (value && !/^[a-zA-Z\s]*$/.test(value)) {
      setManufacturerError("Cannot enter numbers or special characters");
      return false;
    }
    setManufacturerError("");
    return true;
  };
 
  useEffect(() => {
    function handleClickOutside(e) {
      if (
        actionsMenuRef.current && !actionsMenuRef.current.contains(e.target) &&
        actionsTriggerRef.current !== e.target && !actionsTriggerRef.current?.contains(e.target)
      ) {
        setOpenActionsMenu(null);
      }
    }
    if (openActionsMenu?.id != null) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [openActionsMenu]);
 
  const getBatchId = (batch) => batch?.batchId ?? batch?.id;
 
  const defaultForm = {
    productId: "",
    lotNumber: "",
    manufacturer: "",
    manufactureDate: "",
    expiryDate: "",
    quantityReceived: "",
    quantityAvailable: "",
    locationId: "1",
    status: "ACTIVE",
  };
 
  const resetForm = () => {
    setLotNumberError("");
    setManufacturerError("");
    if (editingBatch) {
      setForm({
        productId: editingBatch.productId || "",
        lotNumber: editingBatch.lotNumber || "",
        manufacturer: editingBatch.manufacturer || "",
        manufactureDate: editingBatch.manufactureDate || "",
        expiryDate: editingBatch.expiryDate || "",
        quantityReceived: editingBatch.quantityReceived || "",
        quantityAvailable: editingBatch.quantityAvailable || "",
        locationId: editingBatch.locationId || "1",
        status: editingBatch.status || "ACTIVE",
      });
    } else {
      setForm(defaultForm);
    }
  };
 
  const getProductNameById = (productId) => {
    const product = (allProducts || []).find(p => Number(p.productId || p.id) === Number(productId));
    return product?.name || `Product #${productId}`;
  };
 
  const sortedBatches = useMemo(() => {
    let filtered = [...(allBatches || [])];
   
    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(b => {
        const productName = getProductNameById(b.productId).toLowerCase();
        const lotNumber = (b.lotNumber || "").toLowerCase();
        const manufacturer = (b.manufacturer || "").toLowerCase();
        return productName.includes(query) || lotNumber.includes(query) || manufacturer.includes(query);
      });
    }
   
    // Apply status filter
    if (filterStatus !== "all") {
      filtered = filtered.filter(b => String(b.status || "").toUpperCase() === filterStatus.toUpperCase());
    }
   
    // Apply expiry date filter
    if (filterExpiryDateFrom) {
      const fromDate = new Date(filterExpiryDateFrom);
      filtered = filtered.filter(b => b.expiryDate && new Date(b.expiryDate) >= fromDate);
    }
    if (filterExpiryDateTo) {
      const toDate = new Date(filterExpiryDateTo);
      filtered = filtered.filter(b => b.expiryDate && new Date(b.expiryDate) <= toDate);
    }
   
    // Sort by expiry date
    return filtered.sort((a, b) => {
      const dateA = new Date(a.expiryDate || "9999-12-31");
      const dateB = new Date(b.expiryDate || "9999-12-31");
      return dateA - dateB;
    });
  }, [allBatches, searchQuery, filterStatus, filterExpiryDateFrom, filterExpiryDateTo]);
 
  const totalPages = Math.max(1, Math.ceil(sortedBatches.length / PAGE_SIZE));
  const safePage = Math.min(Math.max(1, currentPage), totalPages);
  const start = (safePage - 1) * PAGE_SIZE;
  const paginatedBatches = sortedBatches.slice(start, start + PAGE_SIZE);
 
  function openAdd() {
    setEditingBatch(null);
    setForm({
      productId: "",
      lotNumber: "",
      manufacturer: "",
      manufactureDate: "",
      expiryDate: "",
      quantityReceived: "",
      quantityAvailable: "",
      locationId: "1",
      status: "ACTIVE",
    });
    setShowModal(true);
  }
 
  function openEdit(batch) {
    setEditingBatch(batch);
    setForm({
      productId: batch.productId || "",
      lotNumber: batch.lotNumber || "",
      manufacturer: batch.manufacturer || "",
      manufactureDate: batch.manufactureDate || "",
      expiryDate: batch.expiryDate || "",
      quantityReceived: batch.quantityReceived || "",
      quantityAvailable: batch.quantityAvailable || "",
      locationId: batch.locationId || "1",
      status: batch.status || "ACTIVE",
    });
    setShowModal(true);
  }
 
  async function handleSave() {
    const isLotValid = validateLotNumber(form.lotNumber);
    const isManufacturerValid = validateManufacturer(form.manufacturer);
    if (!form.productId) {
      showToast("Product is required.", "error");
      return;
    }
    if (!isLotValid) return;
    setSaving(true);
    try {
      const payload = {
        productId: Number(form.productId),
        lotNumber: form.lotNumber.trim(),
        manufacturer: form.manufacturer.trim(),
        manufactureDate: form.manufactureDate,
        expiryDate: form.expiryDate,
        quantityReceived: Number(form.quantityReceived) || 0,
        quantityAvailable: Number(form.quantityAvailable) || 0,
        locationId: Number(form.locationId) || 1,
        status: form.status,
      };
 
      if (editingBatch) {
        await batchesAPI.update(getBatchId(editingBatch), payload);
        showToast("Batch updated successfully!", "success");
      } else {
        await batchesAPI.create(payload);
        showToast("Batch added successfully!", "success");
      }
      setShowModal(false);
      onDataChange();
    } catch (e) {
      showToast(`Save failed: ${e.message}`, "error");
    } finally {
      setSaving(false);
    }
  }
 
  async function handleDelete(batch) {
    if (!window.confirm(`Delete batch "${batch.lotNumber}"?`)) return;
    setDeleting(getBatchId(batch));
    try {
      await batchesAPI.delete(getBatchId(batch));
      showToast("Batch deleted successfully!", "success");
      onDataChange();
    } catch (e) {
      showToast(`Delete failed: ${e.message}`, "error");
    } finally {
      setDeleting(null);
    }
  }
 
  function handleExport() {
    const exportData = sortedBatches.map(b => ({
      "Product": getProductNameById(b.productId) || "",
      "Batch Lot Number": b.lotNumber || "",
      "Manufacturer": b.manufacturer || "",
      "Manufacture Date": b.manufactureDate || "",
      "Expiry Date": b.expiryDate || "",
      "Quantity": b.quantityAvailable ?? b.quantityReceived ?? "",
      "Status": b.status || "",
    }));
    exportToExcel(exportData, "batches_" + new Date().toISOString().split('T')[0]);
    showToast("Batches exported successfully!", "success");
  }
 
  return (
    <div className="bg-white border rounded-xl overflow-hidden">
      <div className="p-2 border-b flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1.5">
        <div>
          <h2 className="text-sm font-semibold text-gray-900">Batch Inventory</h2>
          <p className="text-xs text-gray-500 mt-0.5">{sortedBatches.length} batches</p>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={openAdd}
            className="flex items-center justify-center w-8 h-8 bg-[#3C8C85] hover:bg-[#337872] text-white rounded-md text-xs font-medium"
            title="Add Batch"
            aria-label="Add Batch"
          >
            <Plus size={16} />
          </button>
          <button
            onClick={handleExport}
            className="px-3 py-1.5 bg-[#3C8C85] hover:bg-[#337872] text-white rounded-md text-xs font-medium"
          >
            Export
          </button>
        </div>
      </div>
 
      {/* Search & Filters */}
      <div className="p-3 bg-gray-50 border-b flex flex-wrap gap-2 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
          <input
            className="w-full pl-8 pr-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#3C8C85]/40"
            placeholder="Search batches..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>
        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="px-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#3C8C85]/40">
          <option value="all">All Status</option>
          <option value="ACTIVE">Active</option>
          <option value="INACTIVE">Inactive</option>
          <option value="EXPIRED">Expired</option>
          <option value="QUARANTINE">Quarantine</option>
        </select>
        <div className="flex items-center gap-1 text-xs text-gray-600">
          <span>Expiry:</span>
          <input type="date" value={filterExpiryDateFrom} onChange={e => setFilterExpiryDateFrom(e.target.value)} className="px-2 py-1.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#3C8C85]/40 text-sm" />
          <span className="text-gray-400">–</span>
          <input type="date" value={filterExpiryDateTo} onChange={e => setFilterExpiryDateTo(e.target.value)} className="px-2 py-1.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#3C8C85]/40 text-sm" />
        </div>
      </div>
 
      {paginatedBatches.length === 0 && (
        <div className="p-6 text-center text-sm text-gray-500">
          No batches found.
        </div>
      )}
 
      {paginatedBatches.length > 0 && (
        <div style={{ overflowX: 'auto', overflowY: 'visible' }}>
          <table className="w-full text-sm" style={{ minWidth: '900px' }}>
            <thead style={{ background: '#3C8C85' }} className="border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: '#fff' }}>Product</th>
                <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: '#fff' }}>Batch Lot Number</th>
                <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: '#fff' }}>Manufacturer</th>
                <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: '#fff' }}>Manufacture Date</th>
                <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: '#fff' }}>Expiry Date</th>
                <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: '#fff' }}>Quantity</th>
                <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: '#fff' }}>Status</th>
                <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: '#fff' }}>Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {paginatedBatches.map((batch) => {
                const batchId = getBatchId(batch);
                const isActive = String(batch.status || "").toUpperCase() === "ACTIVE";
                return (
                  <tr key={batchId} className="hover:bg-gray-50">
                    <td className="px-4 py-3 text-gray-900 font-medium">{getProductNameById(batch.productId)}</td>
                    <td className="px-4 py-3 text-gray-600">{batch.lotNumber || "-"}</td>
                    <td className="px-4 py-3 text-gray-600">{batch.manufacturer || "-"}</td>
                    <td className="px-4 py-3 text-gray-600">{batch.manufactureDate || "-"}</td>
                    <td className="px-4 py-3 text-gray-600">{batch.expiryDate || "-"}</td>
                    <td className="px-4 py-3 text-gray-600">{Number(batch.quantityAvailable ?? batch.quantityReceived ?? 0).toLocaleString()}</td>
                    <td className="px-4 py-3">
                      {isActive ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[#3C8C85]/10 text-[#3C8C85] border border-[#3C8C85]/30">
                          <CheckCircle2 className="size-3" /> Active
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-gray-100 text-gray-600 border border-gray-200">
                          <XCircle className="size-3" /> Inactive
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="relative inline-block">
                        <button
                          ref={actionsTriggerRef}
                          onClick={(e) => {
                            const rect = e.currentTarget.getBoundingClientRect();
                            const spaceBelow = window.innerHeight - rect.bottom;
                            const dir = spaceBelow < 90 ? 'up' : 'down';
                            setOpenActionsMenu(prev => prev?.id === batchId ? null : {
                              id: batchId, dir,
                              top: rect.bottom + 4,
                              bottom: window.innerHeight - rect.top + 4,
                              right: window.innerWidth - rect.right,
                            });
                          }}
                          className="p-1.5 rounded hover:bg-gray-100 text-gray-600 hover:text-gray-800"
                        >
                          <MoreVertical size={16} />
                        </button>
                        {openActionsMenu?.id === batchId && (
                          <div
                            ref={actionsMenuRef}
                            className="w-28 bg-white border border-gray-200 rounded-lg shadow-lg overflow-hidden"
                            style={{
                              position: 'fixed',
                              zIndex: 9999,
                              right: openActionsMenu.right,
                              ...(openActionsMenu.dir === 'up'
                                ? { bottom: openActionsMenu.bottom }
                                : { top: openActionsMenu.top }),
                            }}
                          >
                            <button
                              onClick={() => { openEdit(batch); setOpenActionsMenu(null); }}
                              className="w-full px-3 py-1.5 text-left text-xs font-normal text-gray-700 hover:bg-blue-50 flex items-center gap-1.5 whitespace-nowrap"
                            >
                              <Edit2 size={12} className="text-blue-600 shrink-0" /> Edit
                            </button>
                            <button
                              onClick={() => { handleDelete(batch); setOpenActionsMenu(null); }}
                              disabled={deleting === batchId}
                              className={`w-full px-3 py-1.5 text-left text-xs font-normal flex items-center gap-1.5 whitespace-nowrap ${deleting === batchId ? "text-gray-400 cursor-not-allowed" : "text-red-600 hover:bg-red-50"}`}
                            >
                              <Trash2 size={12} className="shrink-0" /> Delete
                            </button>
                          </div>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
 
      {/* Pagination */}
      <div className="px-4 py-3 border-t border-gray-200 flex items-center justify-end gap-3 bg-gray-50">
        <button
          onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
          disabled={safePage <= 1}
          className="px-3 py-1.5 rounded border border-gray-300 text-gray-700 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-gray-100 text-sm"
        >
          Prev
        </button>
        <span className="text-sm text-gray-700">Page {safePage} / {totalPages}</span>
        <button
          onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
          disabled={safePage >= totalPages}
          className="px-3 py-1.5 rounded border border-gray-300 text-gray-700 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-gray-100 text-sm"
        >
          Next
        </button>
      </div>
 
      {/* Add/Edit Batch Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between p-3 border-b flex-shrink-0">
              <h3 className="text-base font-semibold">{editingBatch ? 'Edit Batch' : 'Add Batch'}</h3>
              <button onClick={() => setShowModal(false)} className="p-1 hover:bg-gray-100 rounded"><X size={18} /></button>
            </div>
            <div className="p-3 space-y-2 overflow-y-auto flex-1" style={{scrollbarWidth: 'none', msOverflowStyle: 'none'}}>
              <div className="grid gap-3 md:grid-cols-2">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Product *</label>
                  <select
                    value={form.productId}
                    onChange={(e) => setForm(prev => ({ ...prev, productId: e.target.value }))}
                    className="w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none"
                  >
                    <option value="">Select Product</option>
                    {(allProducts || []).map(p => (
                      <option key={p.productId || p.id} value={p.productId || p.id}>
                        {p.name || `Product #${p.productId || p.id}`}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Lot Number *</label>
                  <input
                    type="text"
                    placeholder="e.g. LOT-2024-001"
                    value={form.lotNumber}
                    onChange={(e) => {
                      const value = e.target.value;
                      setForm(prev => ({ ...prev, lotNumber: value }));
                      validateLotNumber(value);
                    }}
                    className="w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none"
                  />
                  {lotNumberError && <p className="text-xs mt-1" style={{color:'#dc2626'}}>{lotNumberError}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Manufacturer</label>
                  <input
                    type="text"
                    placeholder="e.g. ABC Pharma"
                    value={form.manufacturer}
                    onChange={(e) => {
                      const value = e.target.value;
                      setForm(prev => ({ ...prev, manufacturer: value }));
                      validateManufacturer(value);
                    }}
                    className="w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none"
                  />
                  {manufacturerError && <p className="text-xs mt-1" style={{color:'#dc2626'}}>{manufacturerError}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Manufacture Date</label>
                  <input
                    type="date"
                    value={form.manufactureDate}
                    onChange={(e) => setForm(prev => ({ ...prev, manufactureDate: e.target.value }))}
                    className="w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Expiry Date</label>
                  <input
                    type="date"
                    value={form.expiryDate}
                    onChange={(e) => setForm(prev => ({ ...prev, expiryDate: e.target.value }))}
                    className="w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Quantity Received</label>
                  <input
                    type="number"
                    placeholder="0"
                    value={form.quantityReceived}
                    onChange={(e) => setForm(prev => ({ ...prev, quantityReceived: e.target.value }))}
                    className="w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Quantity Available</label>
                  <input
                    type="number"
                    placeholder="0"
                    value={form.quantityAvailable}
                    onChange={(e) => setForm(prev => ({ ...prev, quantityAvailable: e.target.value }))}
                    className="w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                  <select
                    value={form.status}
                    onChange={(e) => setForm(prev => ({ ...prev, status: e.target.value }))}
                    className="w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none"
                  >
                    <option value="ACTIVE">Active</option>
                    <option value="INACTIVE">Inactive</option>
                    <option value="EXPIRED">Expired</option>
                    <option value="QUARANTINE">Quarantine</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 p-3 border-t bg-gray-50 flex-shrink-0">
              <button
                onClick={resetForm}
                className="px-4 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-100"
              >
                Reset
              </button>
              <button onClick={handleSave} disabled={saving} className="px-4 py-2 text-sm bg-[#3C8C85] hover:bg-[#337872] text-white rounded-lg disabled:opacity-50">
                {saving ? 'Saving...' : (editingBatch ? 'Update' : 'Create')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}