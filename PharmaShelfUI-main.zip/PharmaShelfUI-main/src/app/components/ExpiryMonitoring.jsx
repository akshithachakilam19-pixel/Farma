import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  AlertTriangle,
  Clock,
  Package,
  Archive,
  Calendar,
  AlertCircle,
  Search,
  MoreVertical
} from "lucide-react";
import { toast } from "sonner";
import { productsAPI } from "../../services/productsService";
import { batchesAPI } from "../../services/batchesService";
import { expiryService } from "../../services/expiryService";
 
export function ExpiryMonitoring() {
  const navigate = useNavigate();
  const toArray = (value) => {
    if (Array.isArray(value)) return value;
    if (Array.isArray(value?.data)) return value.data;
    if (Array.isArray(value?.content)) return value.content;
    if (Array.isArray(value?.items)) return value.items;
    if (Array.isArray(value?.result)) return value.result;
    if (Array.isArray(value?.rows)) return value.rows;
    if (Array.isArray(value?.records)) return value.records;
    if (Array.isArray(value?.list)) return value.list;
    if (Array.isArray(value?.alerts)) return value.alerts;
    if (Array.isArray(value?.expiryAlerts)) return value.expiryAlerts;
    if (value && typeof value === "object") {
      const firstArrayValue = Object.values(value).find((entry) => Array.isArray(entry));
      if (Array.isArray(firstArrayValue)) return firstArrayValue;
    }
    return [];
  };
 
  const [filterStatus, setFilterStatus] = useState("all");
  const [activeCategory, setActiveCategory] = useState("all");
  const [expiryBatches, setExpiryBatches] = useState([]);
  const [expiredBatches, setExpiredBatches] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");
  const [isRunningCheck, setIsRunningCheck] = useState(false);
  const [lastCheckDate, setLastCheckDate] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [openActionFor, setOpenActionFor] = useState(null);
  const [selectedDetails, setSelectedDetails] = useState(null);
  const [isDetailsLoading, setIsDetailsLoading] = useState(false);
 
  const handleCardClick = (key) => {
    setActiveCategory(key);
    setFilterStatus(key === "expired" ? "all" : key);
  };
 
  const startOfToday = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return today;
  };
 
  const calculateDaysLeft = (expiryDate) => {
    if (!expiryDate) return Number.POSITIVE_INFINITY;
    const target = new Date(expiryDate);
    if (Number.isNaN(target.getTime())) return Number.POSITIVE_INFINITY;
 
    target.setHours(0, 0, 0, 0);
    const msDiff = target.getTime() - startOfToday().getTime();
    return Math.floor(msDiff / (1000 * 60 * 60 * 24));
  };
 
  const getStatusFromDaysLeft = (daysLeft) => {
    if (daysLeft < 0) return "Expired";
    if (daysLeft <= 14) return "Critical";
    if (daysLeft <= 30) return "Warning";
    if (daysLeft <= 60) return "Watch";
    return "Safe";
  };
 
  const formatDate = (value) => {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value || "-";
    return date.toLocaleDateString();
  };
 
  const normalizeId = (value) => String(value ?? "").trim().toLowerCase();
 
  const extractAlertBatchId = (alert) =>
    alert?.batchId ??
    alert?.batch_id ??
    alert?.BatchID ??
    alert?.batchID ??
    alert?.batch?.batchId ??
    alert?.batch?.id ??
    alert?.batch?.BatchID ??
    alert?.Batch?.BatchID ??
    alert?._batchId;
 
  const isBatchActive = (batch) => {
    const status = String(batch?.status ?? batch?.batchStatus ?? "ACTIVE").trim().toUpperCase();
    return status === "ACTIVE";
  };
 
  const getBatchId = (batch) => batch?.batchId ?? batch?.id ?? batch?.lotNumber;
 
  const getProductId = (batch) =>
    batch?.productId ?? batch?.product_id ?? batch?.idProduct ?? batch?.product?.productId ?? batch?.product?.id;
 
  const toNullableNumber = (value) => {
    if (value === null || value === undefined || value === "") return null;
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  };
 
  const buildAlertPayload = (batch) => {
    const expiryValue = batch.expiryDate ?? batch.expiry ?? batch.expiry_date;
    const daysLeft = calculateDaysLeft(expiryValue);
    const batchId = getBatchId(batch);
    const productId = getProductId(batch);
 
    return {
      // Primary keys expected by backend/table contract
      BatchID: toNullableNumber(batchId),
      ProductID: toNullableNumber(productId),
      DaysToExpiry: daysLeft,
      GeneratedAt: new Date().toISOString(),
      Status: getStatusFromDaysLeft(daysLeft),
      // Compatibility aliases in case backend DTO is camelCase
      batchId: toNullableNumber(batchId),
      productId: toNullableNumber(productId),
      daysToExpiry: daysLeft,
      generatedAt: new Date().toISOString(),
      status: getStatusFromDaysLeft(daysLeft),
    };
  };
 
  const getTodayDateOnly = () => {
    const today = new Date();
    return today.toISOString().split('T')[0]; // Returns YYYY-MM-DD
  };
 
  const runExpiryCheck = async () => {
    // Check auth before running check
    const authToken = localStorage.getItem("authToken");
    if (!authToken) {
      navigate("/login", { replace: true });
      return;
    }

    setIsRunningCheck(true);
    try {
      const [batchesData, existingAlertsData] = await Promise.all([
        batchesAPI.getAll().catch(err => {
          if (err?.status === 401 || err?.status === 403) {
            throw new Error("Session expired. Please log in again.");
          }
          throw err;
        }),
        expiryService.getAlerts().catch(err => {
          if (err?.status === 401 || err?.status === 403) {
            throw new Error("Session expired. Please log in again.");
          }
          throw err;
        }),
      ]);
 
      const batches = toArray(batchesData);
      const existingAlerts = toArray(existingAlertsData);
 
      // Get existing batch IDs that already have alerts to prevent duplicates
      const existingBatchIds = new Set(
        existingAlerts.map((alert) => normalizeId(extractAlertBatchId(alert))).filter(Boolean)
      );
 
      // Only active batches are eligible for expiry alerts
      const activeBatches = batches.filter(isBatchActive);
 
      // Ensure frontend dedupe before calling backend
      const seenBatchIds = new Set();
      const newAlertPayload = activeBatches
        .filter((batch) => {
          const batchId = normalizeId(getBatchId(batch));
          if (!batchId || existingBatchIds.has(batchId) || seenBatchIds.has(batchId)) {
            return false;
          }
 
          const expiryValue = batch.expiryDate ?? batch.expiry ?? batch.expiry_date;
          const daysLeft = calculateDaysLeft(expiryValue);
          const inAlertWindow = Number.isFinite(daysLeft) && daysLeft <= 60;
          const normalizedProductId = toNullableNumber(getProductId(batch));
          const normalizedBatchId = toNullableNumber(getBatchId(batch));
          const hasValidProduct = Number.isFinite(normalizedProductId) && normalizedProductId > 0;
          const hasValidBatch = Number.isFinite(normalizedBatchId) && normalizedBatchId > 0;
 
          if (inAlertWindow && hasValidProduct && hasValidBatch) {
            seenBatchIds.add(batchId);
            return true;
          }
 
          return false;
        })
        .map((batch) => {
          const payload = buildAlertPayload(batch);
          return {
            payload,
            batchKey: normalizeId(getBatchId(batch)),
          };
        });
 
      if (newAlertPayload.length > 0) {
        // Insert one-by-one with idempotency guard updates per successful insert
        let insertedCount = 0;
        for (const item of newAlertPayload) {
          if (existingBatchIds.has(item.batchKey)) continue;
          await expiryService.createAlert(item.payload);
          existingBatchIds.add(item.batchKey);
          insertedCount += 1;
        }
 
        if (insertedCount > 0) {
          toast.success(`Expiry check completed! Inserted ${insertedCount} new alert(s) for newly created batches.`);
        } else {
          toast.info("Expiry check completed. No new active batches found for insertion.");
        }
        setLastCheckDate(getTodayDateOnly());
       
        // Reload data to show new alerts
        await loadExpiryData();
      } else {
        toast.info("Expiry check completed. No new active batches found for insertion.");
        setLastCheckDate(getTodayDateOnly());
      }
    } catch (error) {
      const errorMsg = error?.message || "Failed to run expiry check";
      toast.error(errorMsg);
      console.error("Expiry check error:", error);
      
      // Handle auth errors
      if (errorMsg.includes("Session expired") || error?.status === 401 || error?.status === 403) {
        localStorage.clear();
        navigate("/login", { replace: true });
      }
    } finally {
      setIsRunningCheck(false);
    }
  };
 
  const loadExpiryData = async () => {
    setIsLoading(true);
    setErrorMessage("");
 
    try {
      // Check auth before fetching
      const authToken = localStorage.getItem("authToken");
      if (!authToken) {
        navigate("/login", { replace: true });
        return;
      }

      console.log("[ExpiryMonitoring] Starting data load...");
      const [productsData, batchesData] = await Promise.all([
        productsAPI.getAll().catch(err => {
          console.error("[ExpiryMonitoring] Products API error:", err);
          // Check if it's a 401/403 auth error
          if (err?.status === 401 || err?.status === 403) {
            throw new Error("Session expired. Please log in again.");
          }
          return [];
        }),
        batchesAPI.getAll().catch(err => {
          console.error("[ExpiryMonitoring] Batches API error:", err);
          // Check if it's a 401/403 auth error
          if (err?.status === 401 || err?.status === 403) {
            throw new Error("Session expired. Please log in again.");
          }
          return [];
        }),
      ]);
 
      console.log("[ExpiryMonitoring] Raw API responses:", { productsData, batchesData });
      const products = toArray(productsData);
      const batches = toArray(batchesData);
      console.log("[ExpiryMonitoring] Parsed data:", { products: products.length, batches: batches.length });
 
      const productMap = new Map(
        products.map((product) => [
          Number(product.productId ?? product.id),
          product,
        ])
      );
 
      // Map all ACTIVE batches and calculate their expiry status
      // Show all batches within 60-day expiry window, not just those with alerts
      const mappedBatches = batches
        .filter(isBatchActive)
        .map((batch) => {
          const productId = Number(batch.productId ?? batch.product_id ?? batch.idProduct);
          const product = productMap.get(productId);
          const expiryValue = batch.expiryDate ?? batch.expiry ?? batch.expiry_date;
          const daysLeft = calculateDaysLeft(expiryValue);
          const status = getStatusFromDaysLeft(daysLeft);
 
          return {
            id: batch.batchId ?? batch.id ?? batch.lotNumber,
            _batchId: batch.batchId ?? batch.id,
            _productId: productId,
            _generatedAt: new Date().toISOString(),
            product:
              product?.name ??
              product?.productName ??
              product?.genericName ??
              "Unknown Product",
            batch: batch.lotNumber ?? batch.batchNumber ?? batch.batchCode ?? "-",
            manufacturer: batch.manufacturer ?? "-",
            expiry: expiryValue ?? "-",
            daysLeft,
            quantity: Number(
              batch.quantityAvailable ?? batch.quantityReceived ?? batch.quantity ?? 0
            ),
            location:
              batch.locationName ??
              batch.location ??
              (batch.locationId ? `Location #${batch.locationId}` : "N/A"),
            status,
            sku: product?.sku ?? "-",
          };
        });
 
      // Filter by expiry window (<=60 days) and expired separately
      const activeAlerts = mappedBatches.filter((batch) => Number.isFinite(batch.daysLeft) && batch.daysLeft >= 0 && batch.daysLeft <= 60);
      const expired = mappedBatches.filter((batch) => Number.isFinite(batch.daysLeft) && batch.daysLeft < 0);
 
      console.log("[ExpiryMonitoring] Final data:", { mappedBatches: mappedBatches.length, activeAlerts: activeAlerts.length, expired: expired.length });
      setExpiryBatches(activeAlerts.sort((a, b) => a.daysLeft - b.daysLeft));
      setExpiredBatches(expired.sort((a, b) => a.daysLeft - b.daysLeft));
    } catch (error) {
      const errorMsg = error?.message || "Failed to load expiry data.";
      console.error("[ExpiryMonitoring] Error:", errorMsg);
      
      // Handle auth errors
      if (errorMsg.includes("Session expired") || error?.status === 401 || error?.status === 403) {
        localStorage.clear();
        navigate("/login", { replace: true });
        return;
      }
      
      setErrorMessage(errorMsg);
      setExpiryBatches([]);
    } finally {
      setIsLoading(false);
    }
  };
 
  useEffect(() => {
    loadExpiryData();
  }, []);

  // Auth check - redirect if not logged in
  useEffect(() => {
    const authToken = localStorage.getItem("authToken");
    const pharmaUser = localStorage.getItem("pharmaShelfUser");
    
    if (!authToken || !pharmaUser) {
      navigate("/login", { replace: true });
    }
  }, [navigate]);
 
  const summaryStats = useMemo(() => {
    console.log("[ExpiryMonitoring] expiryBatches for summary:", expiryBatches.map(b => ({ product: b.product, status: b.status, daysLeft: b.daysLeft })));
    const critical = expiryBatches.filter((item) => item.status === "Critical").length;
    const warning = expiryBatches.filter((item) => item.status === "Warning").length;
    const watch = expiryBatches.filter((item) => item.status === "Watch").length;
    console.log("[ExpiryMonitoring] Summary counts:", { critical, warning, watch, expired: expiredBatches.length });
 
    return [
      { key: "critical", label: "Critical (≤14 days)", value: critical, color: "bg-red-500", icon: AlertTriangle },
      { key: "warning", label: "Warning (15-30 days)", value: warning, color: "bg-orange-500", icon: Clock },
      { key: "watch", label: "Watch (31-60 days)", value: watch, color: "bg-yellow-500", icon: Package },
      { key: "expired", label: "Expired Batches", value: expiredBatches.length, color: "bg-gray-500", icon: Archive },
    ];
  }, [expiryBatches, expiredBatches.length]);
 
  const getStatusColor = (status) => {
    switch (status) {
      case "Critical": return "bg-red-100 text-red-700 border-red-300";
      case "Warning": return "bg-orange-100 text-orange-700 border-orange-300";
      case "Watch": return "bg-yellow-100 text-yellow-700 border-yellow-300";
      case "Expired": return "bg-gray-200 text-gray-800 border-gray-400";
      default: return "bg-gray-100 text-gray-700 border-gray-300";
    }
  };
 
  const filteredBatches = expiryBatches.filter((batch) => {
    if (activeCategory === "all") return true;
    if (activeCategory === "expired") return batch.status === "Expired";
 
    switch (activeCategory) {
      case "critical":
        return batch.status === "Critical";
      case "warning":
        return batch.status === "Warning";
      case "watch":
        return batch.status === "Watch" || batch.status === "Safe";  // Include Safe batches in Watch category
      default:
        return true;
    }
  });
  console.log("[ExpiryMonitoring] activeCategory:", activeCategory, "filteredBatches:", filteredBatches.length, "all expiryBatches:", expiryBatches.map(b => b.status));
 
  const searchedBatches = filteredBatches.filter((batch) => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return true;
 
    return [batch.manufacturer, batch.product, batch.batch, batch.status]
      .some((value) => String(value ?? "").toLowerCase().includes(query));
  });
 
  const totalAlertsCount = expiryBatches.length;
 
  const totalPages = Math.max(1, Math.ceil(searchedBatches.length / rowsPerPage));
  const paginatedBatches = searchedBatches.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );
 
  const activeSectionLabel = activeCategory === "expired" ? "Expired Batches" :
    activeCategory === "all" ? "Active Expiry Alerts" :
    activeCategory === "critical" ? "Critical Alerts (≤14 days)" :
    activeCategory === "warning" ? "Warning Alerts (15-30 days)" :
    "Watch Alerts (31-60 days)";
  const activeSectionCount = searchedBatches.length;
 
  const closeDetailsModal = () => setSelectedDetails(null);
 
  const toCsvValue = (value) => {
    const str = String(value ?? "");
    return `"${str.replace(/"/g, '""')}"`;
  };
 
  const downloadDetailsCsv = (details) => {
    const fields = Object.entries(details || {});
    const csv = ["Field,Value", ...fields.map(([k, v]) => `${toCsvValue(k)},${toCsvValue(v)}`)].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `expiry-alert-${details?.batch ?? "batch"}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };
 
  const fetchProductDetailsForBatch = async (batch) => {
    setIsDetailsLoading(true);
    try {
      const productsData = await productsAPI.getAll();
      const products = toArray(productsData);
      const product = products.find(
        (item) => Number(item.productId ?? item.id) === Number(batch._productId)
      );
 
      const details = {
        productName: product?.name ?? product?.productName ?? product?.genericName ?? batch.product,
        category: product?.category ?? "-",
        formulation: product?.formulation ?? "-",
        strength: product?.strength ?? "-",
        sku: product?.sku ?? batch.sku ?? "-",
        manufacturer: batch.manufacturer,
        batch: batch.batch,
        expiryDate: batch.expiry,
        daysToExpiry: batch.daysLeft,
        quantity: batch.quantity,
        status: batch.status,
      };
 
      setSelectedDetails(details);
    } catch (error) {
      toast.error(error.message || "Failed to fetch product details");
    } finally {
      setIsDetailsLoading(false);
      setOpenActionFor(null);
    }
  };
 
  const fetchAndDownloadDetailsForBatch = async (batch) => {
    setIsDetailsLoading(true);
    try {
      const productsData = await productsAPI.getAll();
      const products = toArray(productsData);
      const product = products.find(
        (item) => Number(item.productId ?? item.id) === Number(batch._productId)
      );
 
      const details = {
        productName: product?.name ?? product?.productName ?? product?.genericName ?? batch.product,
        category: product?.category ?? "-",
        formulation: product?.formulation ?? "-",
        strength: product?.strength ?? "-",
        sku: product?.sku ?? batch.sku ?? "-",
        manufacturer: batch.manufacturer,
        batch: batch.batch,
        expiryDate: batch.expiry,
        daysToExpiry: batch.daysLeft,
        quantity: batch.quantity,
        status: batch.status,
      };
 
      downloadDetailsCsv(details);
    } catch (error) {
      toast.error(error.message || "Failed to download CSV");
    } finally {
      setIsDetailsLoading(false);
      setOpenActionFor(null);
    }
  };
 
  useEffect(() => {
    setCurrentPage(1);
  }, [activeCategory, searchQuery, rowsPerPage]);
 
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Expiry Monitoring & Alerts</h1>
          <p className="text-gray-600 mt-1">Track medication expiry dates and manage quarantine workflows</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={runExpiryCheck}
            disabled={isRunningCheck}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              isRunningCheck
                ? "bg-gray-400 text-white cursor-not-allowed"
                : "bg-[#3C8C85] text-white hover:bg-[#2E6B5E] shadow-sm"
            }`}
          >
            {isRunningCheck ? "Running Check..." : "Run Expiry Check"}
          </button>
          {lastCheckDate && (
            <div className="flex items-center gap-2 px-3 py-2 bg-green-50 border border-green-200 rounded-lg text-sm text-green-700">
              <Clock className="size-4" />
              Last check: {new Date(lastCheckDate).toLocaleDateString()}
            </div>
          )}
        </div>
      </div>
 
      {errorMessage && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
          {errorMessage}
        </div>
      )}
 
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryStats.map(({ key, label, value, color, icon: Icon }) => (
          <div
            key={key}
            onClick={() => handleCardClick(key)}
            className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 cursor-pointer hover:shadow-md transition-shadow"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">{label}</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{value}</p>
              </div>
              <div className={`${color} p-3 rounded-lg`}>
                <Icon className="size-6 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>
 
      {/* Search and Controls */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 md:p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="relative w-full md:max-w-md">
            <Search className="size-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by manufacturer, product, batch, or status"
              className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#3C8C85]/30 focus:border-[#3C8C85]"
            />
          </div>
          <div className="flex items-center gap-3 text-sm text-gray-600">
            <span>Total alerts: <span className="font-semibold text-gray-900">{totalAlertsCount}</span></span>
            <span>•</span>
            <span>{activeSectionLabel}: <span className="font-semibold text-gray-900">{activeSectionCount}</span></span>
          </div>
        </div>
      </div>
 
      {/* Expiry Alerts Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-visible">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Manufacturer</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Expiry Date</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Quantity</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {isLoading ? (
                <tr>
                  <td colSpan={5} className="px-6 py-10 text-center text-sm text-gray-500">
                    Loading expiry batches...
                  </td>
                </tr>
              ) : paginatedBatches.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-10 text-center text-sm text-gray-500">
                    No expiry alerts found from your current filters.
                  </td>
                </tr>
              ) : (
                paginatedBatches.map((batch) => (
                  <tr key={batch.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-sm font-semibold text-gray-900">{batch.manufacturer}</p>
                        <p className="text-xs text-gray-500">{batch.product} • {batch.batch}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-sm text-gray-900">
                        <Calendar className="size-4 text-gray-400" />
                        {formatDate(batch.expiry)}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold text-gray-900">
                      {Number(batch.quantity || 0).toLocaleString()} <span className="text-xs text-gray-500">units</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold border ${getStatusColor(batch.status)}`}>
                        <AlertCircle className="size-3" />
                        {batch.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 relative">
                      <button
                        className="p-2 rounded-lg hover:bg-gray-100"
                        onClick={() => setOpenActionFor((prev) => (prev === batch.id ? null : batch.id))}
                        title="More actions"
                      >
                        <MoreVertical className="size-4 text-gray-700" />
                      </button>
                      {openActionFor === batch.id && (
                        <div className="absolute right-6 mt-2 z-20 w-44 bg-white border border-gray-200 rounded-lg shadow-lg py-1">
                          <button
                            className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-50"
                            onClick={() => fetchProductDetailsForBatch(batch)}
                          >
                            View Details
                          </button>
                          <button
                            className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-50"
                            onClick={() => fetchAndDownloadDetailsForBatch(batch)}
                          >
                            Download CSV
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
 
        <div className="px-6 py-4 border-t border-gray-200 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <span>Rows per page</span>
            <select
              value={rowsPerPage}
              onChange={(e) => setRowsPerPage(Number(e.target.value))}
              className="border border-gray-300 rounded-md px-2 py-1 text-sm"
            >
              <option value={5}>5</option>
              <option value={10}>10</option>
              <option value={20}>20</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="px-3 py-1.5 border border-gray-300 rounded-md text-sm disabled:opacity-50"
            >
              Previous
            </button>
            <span className="text-sm text-gray-600">Page {currentPage} of {totalPages}</span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="px-3 py-1.5 border border-gray-300 rounded-md text-sm disabled:opacity-50"
            >
              Next
            </button>
          </div>
        </div>
      </div>
 
      {selectedDetails && (
        <div className="fixed inset-0 bg-black/40 z-30 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl border border-gray-200 w-full max-w-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Product Details</h3>
              <button className="text-gray-500 hover:text-gray-700" onClick={closeDetailsModal}>✕</button>
            </div>
            {isDetailsLoading ? (
              <p className="text-sm text-gray-500">Loading details...</p>
            ) : (
              <div className="space-y-2 text-sm">
                {Object.entries(selectedDetails).map(([key, value]) => (
                  <div key={key} className="flex justify-between gap-4 border-b border-gray-100 pb-1">
                    <span className="text-gray-500 capitalize">{key}</span>
                    <span className="text-gray-900 font-medium text-right">{String(value ?? "-")}</span>
                  </div>
                ))}
              </div>
            )}
            <div className="mt-5 flex justify-end gap-2">
              <button
                className="px-3 py-2 text-sm rounded-md border border-gray-300 hover:bg-gray-50"
                onClick={() => downloadDetailsCsv(selectedDetails)}
              >
                Download CSV
              </button>
              <button
                className="px-3 py-2 text-sm rounded-md bg-[#3C8C85] text-white hover:bg-[#2E6B5E]"
                onClick={closeDetailsModal}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}