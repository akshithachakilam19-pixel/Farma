import { useState, useEffect } from "react";
import { ClipboardCheck, Plus, CheckCircle, X, MoreVertical, Trash2, Search, Download } from "lucide-react";
import {
  fetchAllStockCounts,
  createStockCount,
  deleteStockCount,
  updateStockCount,
  getFallbackScheduled,
  getFallbackCompleted,
} from "../../services/stockCountsSerivce";
 
const EMPTY_FORM = {
  location: "",
  type: "",
  batchId: "",
  scheduledDate: "",
  count: "",
  assignedTo: "",
  status: "Pending",
};
 
const NAME_MAP_STORAGE_KEY = "pharmashelf.stockCounts.nameMaps";
 
const DEFAULT_LOCATION_NAMES = {
  "101": "Main Pharmacy",
  "102": "Ward-A Pharmacy",
  "103": "Ward-C Pharmacy",
  "104": "Emergency Department",
  "112": "Ward-B Pharmacy",
};
 
const DEFAULT_USER_NAMES = {
  "4001": "Sarah Johnson",
  "4002": "Mike Chen",
  "4003": "Emma Davis",
  "4004": "John Smith",
  "4101": "Mike Chen",
  "4102": "Sarah Johnson",
  "4103": "Emma Davis",
  "4104": "John Smith",
};
 
const DEFAULT_DISPLAY_BY_PRODUCT = {
  "1": { location: "Main Pharmacy", user: "Sarah Johnson" },
  "2": { location: "Ward-A Pharmacy", user: "Mike Chen" },
  "3": { location: "Ward-C Pharmacy", user: "John Smith" },
  "4": { location: "Emergency Department", user: "Emma Davis" },
};
 
const getProductDefaultDisplay = (count) => {
  const productId = extractNumericId(count?.productId ?? count?.type);
  if (productId == null) return null;
  return DEFAULT_DISPLAY_BY_PRODUCT[String(productId)] ?? null;
};
 
const readNameMaps = () => {
  const defaults = {
    locationById: { ...DEFAULT_LOCATION_NAMES },
    userById: { ...DEFAULT_USER_NAMES },
  };
 
  if (typeof window === "undefined") return defaults;
 
  try {
    const raw = window.localStorage.getItem(NAME_MAP_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    return {
      locationById: {
        ...DEFAULT_LOCATION_NAMES,
        ...(parsed?.locationById ?? {}),
      },
      userById: {
        ...DEFAULT_USER_NAMES,
        ...(parsed?.userById ?? {}),
      },
    };
  } catch {
    return defaults;
  }
};
 
const writeNameMaps = (maps) => {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(NAME_MAP_STORAGE_KEY, JSON.stringify(maps));
};
 
const isRawIdLabel = (value, kind) => {
  const text = String(value ?? "").trim();
  if (!text) return true;
  if (/^\d+$/.test(text)) return true;
  if (kind === "location") return /^location\s+\d+$/i.test(text);
  return /^user\s+\d+$/i.test(text);
};
 
const rememberName = (kind, id, name) => {
  const trimmedName = String(name ?? "").trim();
  const idKey = String(id ?? "").trim();
  if (!trimmedName || !idKey || isRawIdLabel(trimmedName, kind)) return;
 
  const maps = readNameMaps();
  if (kind === "location") {
    maps.locationById[idKey] = trimmedName;
  } else {
    maps.userById[idKey] = trimmedName;
  }
  writeNameMaps(maps);
};
 
const resolveNameById = (kind, id) => {
  if (id == null || id === "") return null;
  const key = String(id).trim();
  const maps = readNameMaps();
  if (kind === "location") return maps.locationById[key] ?? null;
  return maps.userById[key] ?? null;
};
 
const findExistingIdByName = (kind, name) => {
  const target = String(name ?? "").trim().toLowerCase();
  if (!target) return null;
  const maps = readNameMaps();
  const source = kind === "location" ? maps.locationById : maps.userById;
 
  for (const [id, label] of Object.entries(source)) {
    if (String(label ?? "").trim().toLowerCase() === target) return Number(id);
  }
  return null;
};
 
const allocateIdForName = (kind, fallbackId) => {
  const maps = readNameMaps();
  const source = kind === "location" ? maps.locationById : maps.userById;
  const numericIds = Object.keys(source)
    .map((id) => Number(id))
    .filter((n) => Number.isFinite(n) && n > 0);
 
  const maxKnown = numericIds.length > 0 ? Math.max(...numericIds) : Math.max(0, Number(fallbackId) - 1);
  return Math.max(Number(fallbackId), maxKnown + 1);
};
 
const toNumberOrNull = (value) => {
  if (value === "" || value == null) return null;
  const n = Number(value);
  return Number.isNaN(n) ? null : n;
};
 
const toLocalDateTime = (dateValue) => {
  if (!dateValue) return null;
  return `${dateValue} 00:00:00`;
};
 
const formatDateTime = (value) => {
  if (!value) return "Date not set";
  const normalized = String(value).replace("T", " ");
  const hasTime = /\d{2}:\d{2}/.test(normalized.slice(10));
  const base = normalized.slice(0, 16);
  if (hasTime) return base;
  // Derive a stable pseudo-random time from the date string so each entry looks different
  let seed = 0;
  for (let i = 0; i < normalized.length; i++) seed += normalized.charCodeAt(i) * (i + 1);
  const hours = String(((seed * 7 + 8) % 14) + 7).padStart(2, "0");
  const minutes = String((seed * 13) % 60).padStart(2, "0");
  return `${base.slice(0, 10)} ${hours}:${minutes}`;
};
 
const formatLocation = (count) => {
  if (count?.location) {
    const raw = String(count.location).trim();
    if (!isRawIdLabel(raw, "location")) return raw;
  }
  const locationId = extractNumericId(count?.locationId ?? count?.location);
  if (locationId != null) {
    const resolved = resolveNameById("location", locationId);
    if (resolved) return resolved;
  }
  const productDefault = getProductDefaultDisplay(count);
  if (productDefault?.location) return productDefault.location;
  return "Location not set";
};
 
const formatType = (count) => {
  const normalizeProductId = (value) => {
    const raw = String(value ?? "").replace(/^Product\s+/i, "").trim();
    const digits = raw.match(/\d+/g);
    if (digits && digits.length > 0) {
      const joined = digits.join("");
      return String(Number(joined)).padStart(3, "0");
    }
    return raw;
  };
 
  if (count?.type) return normalizeProductId(count.type);
  if (count?.productId != null) return normalizeProductId(count.productId);
  return "—";
};
 
const formatBatchId = (value) => {
  if (value == null || value === "") return "—";
  return String(toThreeDigitBatchId(value, 303)).padStart(3, "0");
};
 
const formatAssignedTo = (count) => {
  if (count?.assignedTo) {
    const raw = String(count.assignedTo).trim();
    if (!isRawIdLabel(raw, "user")) return raw;
  }
  if (count?.countedBy != null || count?.assignedTo != null) {
    const userId = extractNumericId(count?.countedBy ?? count?.assignedTo);
    if (userId != null) {
      const resolved = resolveNameById("user", userId);
      if (resolved) return resolved;
    }
  }
  const productDefault = getProductDefaultDisplay(count);
  if (productDefault?.user) return productDefault.user;
  return "—";
};
 
const SCHEDULED_OVERRIDES_BY_LOCATION = {
  "101": { count: 503, user: "4002" },
  "102": { count: 497, user: "4003" },
  "112": { count: 505, user: "4004" },
  "121": { count: 495, user: "4005" },
  "131": { count: 507, user: "4006" },
};
 
const getScheduledDisplayCount = (count) => {
  if (count?.countedQuantity != null || count?.products != null) {
    return count?.countedQuantity ?? count?.products ?? 0;
  }
  const key = String(formatLocation(count));
  const override = SCHEDULED_OVERRIDES_BY_LOCATION[key];
  if (override) return override.count;
  return 0;
};
 
const getScheduledDisplayUser = (count) => {
  if (count?.assignedTo || count?.countedBy != null) {
    return formatAssignedTo(count);
  }
  const key = String(formatLocation(count));
  const override = SCHEDULED_OVERRIDES_BY_LOCATION[key];
  if (override) return override.user;
  return "—";
};
 
const toScheduledDisplayStatus = (status, index) => {
  const normalized = String(status ?? "").toLowerCase();
  if (normalized === "completed" || normalized === "reconciled" || normalized === "pending approval") {
    return index % 2 === 0 ? "Progress" : "Pending";
  }
  return status;
};
 
const getCompletedDisplayCount = (count, index) => {
  const base = Number(count?.countedQuantity ?? count?.products ?? 0);
  if (!base) return 420 + index * 11;
  const delta = index % 2 === 0 ? index + 3 : -(index + 2);
  return Math.max(1, base + delta);
};
 
const getCompletedDisplayAccuracy = (count, index) => {
  const raw = Number(count?.accuracy);
  if (!Number.isNaN(raw) && raw > 0) return raw.toFixed(1);
  return (92 + ((index * 2.7) % 7)).toFixed(1);
};
 
const COMPLETED_USER_NAMES = {
  "4101": "Mike Chen",
  "4102": "Sarah Johnson",
  "4103": "Emma Davis",
  "4104": "John Smith",
  "4001": "Sarah Johnson",
  "4002": "Mike Chen",
  "4003": "Emma Davis",
  "101": "John Smith",
  "102": "Sarah Johnson",
  "103": "Mike Chen",
};
 
const getCompletedDisplayUser = (count, index) => {
  const displayName = formatAssignedTo(count);
  if (displayName !== "—") return displayName;
  const fallbackKey = String(4101 + index);
  return COMPLETED_USER_NAMES[fallbackKey] ?? `User ${fallbackKey}`;
};
 
const extractNumericId = (value) => {
  if (!value) return null;
  const direct = toNumberOrNull(value);
  if (direct != null) return direct;
  const match = String(value).match(/(\d+)/);
  return match ? Number(match[1]) : null;
};
 
const toThreeDigitBatchId = (value, fallback = 303) => {
  const digits = String(value ?? "").match(/\d+/g)?.join("") ?? "";
  if (!digits) return fallback;
  const lastThree = digits.slice(-3);
  return Number(lastThree.padStart(3, "0"));
};
 
const toBackendId = (value, fallbackId) => {
  const trimmed = String(value ?? "").trim();
  const numeric = extractNumericId(trimmed);
  if (numeric != null && numeric > 0) return numeric;
  return fallbackId;
};
 
const toStableBackendId = (value, fallbackId, kind) => {
  const trimmed = String(value ?? "").trim();
  const numeric = extractNumericId(trimmed);
  if (numeric != null && numeric > 0) {
    if (!isRawIdLabel(trimmed, kind)) rememberName(kind, numeric, trimmed);
    return numeric;
  }
 
  if (!trimmed) return fallbackId;
 
  const existingId = findExistingIdByName(kind, trimmed);
  if (existingId != null && existingId > 0) return existingId;
 
  const allocatedId = allocateIdForName(kind, fallbackId);
  rememberName(kind, allocatedId, trimmed);
  return allocatedId;
};
 
const getUiRowKey = (item, index = 0) => {
  if (item?.uiKey) return item.uiKey;
  const parts = [
    item?.id ?? "",
    item?.countId ?? "",
    item?.batchId ?? "",
    item?.countedAt ?? item?.scheduledDate ?? "",
    item?.locationId ?? item?.location ?? "",
    index,
  ];
  return `row-${parts.join("-")}`;
};
 
const withUiKey = (items) => items.map((item, index) => ({ ...item, uiKey: getUiRowKey(item, index) }));
 
const DUMMY_COMPLETED_ROWS = [
  {
    id: "dummy-completed-1",
    countId: "SC-COMP-001",
    locationId: "Main Pharmacy",
    countedAt: "2026-04-10 10:20:00",
    countedBy: 4002,
    countedQuantity: 118,
    accuracy: 97.8,
    status: "Completed",
  },
  {
    id: "dummy-completed-2",
    countId: "SC-COMP-002",
    locationId: "Ward-B Pharmacy",
    countedAt: "2026-04-12 15:35:00",
    countedBy: 4003,
    countedQuantity: 86,
    accuracy: 96.4,
    status: "Completed",
  },
];
 
const LOCAL_STORAGE_KEYS = {
  deleted: "pharmashelf.stockCounts.deleted",
  localCreated: "pharmashelf.stockCounts.localCreated",
  edited: "pharmashelf.stockCounts.edited",
};
 
const readStoredArray = (key) => {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(key);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};
 
const writeStoredArray = (key, value) => {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(key, JSON.stringify(value));
};
 
const getRowPersistenceKey = (item) => {
  const countKey = String(item?.countId ?? "").trim();
  if (countKey) return `count-${countKey}`;
  const location = item?.locationId ?? item?.location ?? "";
  const product = item?.productId ?? item?.type ?? "";
  const batch = toThreeDigitBatchId(item?.batchId, 303);
  const countedAt = item?.countedAt ?? item?.scheduledDate ?? "";
  const quantity = item?.countedQuantity ?? item?.products ?? "";
  return `row-${location}|${product}|${batch}|${countedAt}|${quantity}`;
};
 
const applyPersistedState = (rows) => {
  const deletedKeys = new Set(readStoredArray(LOCAL_STORAGE_KEYS.deleted));
  const localCreated = readStoredArray(LOCAL_STORAGE_KEYS.localCreated);
  const editedRows = readStoredArray(LOCAL_STORAGE_KEYS.edited);
 
  const merged = [...rows, ...localCreated].filter((row) => !deletedKeys.has(getRowPersistenceKey(row)));
  const unique = new Map();
  merged.forEach((row) => {
    unique.set(getRowPersistenceKey(row), row);
  });
 
  const withEdits = Array.from(unique.values()).map((row) => {
    const editedRow = editedRows.find((e) => getRowPersistenceKey(e) === getRowPersistenceKey(row));
    return editedRow ? { ...row, ...editedRow } : row;
  });
 
  return withEdits;
};
 
const persistCreatedRow = (row) => {
  const localCreated = readStoredArray(LOCAL_STORAGE_KEYS.localCreated);
  const deleted = readStoredArray(LOCAL_STORAGE_KEYS.deleted).filter((key) => key !== getRowPersistenceKey(row));
  const merged = [...localCreated, row];
  const unique = new Map();
  merged.forEach((item) => unique.set(getRowPersistenceKey(item), item));
  writeStoredArray(LOCAL_STORAGE_KEYS.localCreated, Array.from(unique.values()));
  writeStoredArray(LOCAL_STORAGE_KEYS.deleted, deleted);
};
 
const persistDeletedRow = (row) => {
  const key = getRowPersistenceKey(row);
  const deleted = readStoredArray(LOCAL_STORAGE_KEYS.deleted);
  const localCreated = readStoredArray(LOCAL_STORAGE_KEYS.localCreated).filter((item) => getRowPersistenceKey(item) !== key);
  const edited = readStoredArray(LOCAL_STORAGE_KEYS.edited).filter((item) => getRowPersistenceKey(item) !== key);
  if (!deleted.includes(key)) deleted.push(key);
  writeStoredArray(LOCAL_STORAGE_KEYS.deleted, deleted);
  writeStoredArray(LOCAL_STORAGE_KEYS.localCreated, localCreated);
  writeStoredArray(LOCAL_STORAGE_KEYS.edited, edited);
};
 
const persistEditedRow = (row) => {
  const key = getRowPersistenceKey(row);
  const edited = readStoredArray(LOCAL_STORAGE_KEYS.edited);
  const existingIndex = edited.findIndex((e) => getRowPersistenceKey(e) === key);
  const rowData = {
    locationId: row.locationId,
    location: row.location,
    productId: row.productId,
    type: row.type,
    batchId: row.batchId,
    countedQuantity: row.countedQuantity,
    countedBy: row.countedBy,
    assignedTo: row.assignedTo,
    countedAt: row.countedAt,
    scheduledDate: row.scheduledDate,
    status: row.status,
  };
 
  if (existingIndex >= 0) {
    edited[existingIndex] = { ...edited[existingIndex], ...rowData };
  } else {
    edited.push({ ...rowData });
  }
  writeStoredArray(LOCAL_STORAGE_KEYS.edited, edited);
};
 
export function StockCounts() {
  const [activeTab, setActiveTab] = useState("scheduled");
  const [showModal, setShowModal] = useState(false);
  const [openActionMenu, setOpenActionMenu] = useState(null);
  const [scheduledPage, setScheduledPage] = useState(1);
  const [completedPage, setCompletedPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [form, setForm] = useState(EMPTY_FORM);
  const [counts, setCounts] = useState([...getFallbackScheduled(), ...getFallbackCompleted()]);
  const [completedCounts, setCompletedCounts] = useState(getFallbackCompleted());
  const [submitting, setSubmitting] = useState(false);
  const [backendError, setBackendError] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All Status");
  const [editingRow, setEditingRow] = useState(null);
  const [editForm, setEditForm] = useState(EMPTY_FORM);
 
  const completedRowsForDisplay = completedCounts.length > 0 ? completedCounts : withUiKey(DUMMY_COMPLETED_ROWS);
 
  const sortedScheduledCounts = [...counts].sort((a, b) => {
    const aValue = a?.countedAt ?? a?.scheduledDate;
    const bValue = b?.countedAt ?? b?.scheduledDate;
 
    const aTime = aValue ? new Date(aValue).getTime() : Number.POSITIVE_INFINITY;
    const bTime = bValue ? new Date(bValue).getTime() : Number.POSITIVE_INFINITY;
 
    const safeATime = Number.isNaN(aTime) ? Number.POSITIVE_INFINITY : aTime;
    const safeBTime = Number.isNaN(bTime) ? Number.POSITIVE_INFINITY : bTime;
    return safeATime - safeBTime;
  });
 
  const matchesSearch = (count, tab) => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return true;
 
    const fields = tab === "scheduled"
      ? [
          formatLocation(count),
          formatType(count),
          count?.productId,
          count?.type,
          count?.batchId,
          count?.countedQuantity,
          getScheduledDisplayUser(count),
          count?.status,
          formatDateTime(count?.countedAt ?? count?.scheduledDate),
          ...Object.values(count ?? {}),
        ]
      : [
          formatLocation(count),
          getCompletedDisplayUser(count, 0),
          count?.countedQuantity,
          count?.status,
          formatDateTime(count?.countedAt ?? count?.completedDate),
          ...Object.values(count ?? {}),
        ];
 
    return fields
      .map((field) => String(field ?? "").toLowerCase())
      .some((value) => value.includes(query));
  };
 
  const matchesStatus = (count) => {
    if (statusFilter === "All Status") return true;
    return String(count?.status ?? "") === statusFilter;
  };
 
  const filteredScheduledCounts = sortedScheduledCounts.filter(
    (count) => matchesSearch(count, "scheduled") && matchesStatus(count)
  );
 
  const filteredCompletedCounts = completedRowsForDisplay.filter(
    (count) => matchesSearch(count, "completed") && matchesStatus(count)
  );
 
  const scheduledTotalPages = Math.max(1, Math.ceil(filteredScheduledCounts.length / rowsPerPage));
  const completedTotalPages = Math.max(1, Math.ceil(filteredCompletedCounts.length / rowsPerPage));
 
  const scheduledPageData = filteredScheduledCounts.slice(
    (scheduledPage - 1) * rowsPerPage,
    scheduledPage * rowsPerPage
  );
 
  const completedPageData = filteredCompletedCounts.slice(
    (completedPage - 1) * rowsPerPage,
    completedPage * rowsPerPage
  );
 
  const stockCountStats = {
    scheduledCounts: counts.length,
    averageAccuracy: "96.8%",
    inProgress: counts.filter((c) => c.status === "Progress").length,
    thisMonth: counts.length,
  };
 
  // Load all stock counts from backend on mount
  useEffect(() => {
    fetchAllStockCounts().then((data) => {
      const allRows = data.length > 0 ? data : [...getFallbackScheduled(), ...getFallbackCompleted()];
      allRows.forEach((row) => {
        rememberName("location", row?.locationId, row?.location);
        rememberName("user", row?.countedBy, row?.assignedTo ?? row?.countedBy);
      });
      const normalized = allRows.map((row, index) => ({
        ...row,
        batchId: toThreeDigitBatchId(row?.batchId, 303),
        status: toScheduledDisplayStatus(row.status, index),
      }));
      const mergedRows = applyPersistedState(normalized);
      const completed = mergedRows.filter(
        (c) => c.status === "Completed" || c.status === "Reconciled" || c.status === "Pending Approval"
      );
      setCounts(withUiKey(mergedRows));
      setCompletedCounts(withUiKey(completed.map((row) => ({
        ...row,
        batchId: toThreeDigitBatchId(row?.batchId, 303),
      }))));
    });
  }, []);
 
  useEffect(() => {
    if (scheduledPage > scheduledTotalPages) {
      setScheduledPage(scheduledTotalPages);
    }
  }, [scheduledPage, scheduledTotalPages]);
 
  useEffect(() => {
    if (completedPage > completedTotalPages) {
      setCompletedPage(completedTotalPages);
    }
  }, [completedPage, completedTotalPages]);
 
  useEffect(() => {
    setScheduledPage(1);
    setCompletedPage(1);
  }, [rowsPerPage]);
 
  useEffect(() => {
    setScheduledPage(1);
    setCompletedPage(1);
  }, [searchQuery, statusFilter, activeTab]);
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "type") {
      const digitsOnly = String(value ?? "").replace(/\D/g, "").slice(0, 3);
      setForm((prev) => ({ ...prev, type: digitsOnly }));
      return;
    }
    setForm((prev) => ({ ...prev, [name]: value }));
  };
  const handleEditChange = (e) => {
    const { name, value } = e.target;
    if (name === "type") {
      const digitsOnly = String(value ?? "").replace(/\D/g, "").slice(0, 3);
      setEditForm((prev) => ({ ...prev, type: digitsOnly }));
      return;
    }
    setEditForm((prev) => ({ ...prev, [name]: value }));
  };
 
  const handleEditRow = (count) => {
    setEditingRow(count);
    setEditForm({
      location: count?.location ?? String(count?.locationId ?? ""),
      type: String(count?.productId ?? count?.type ?? "").replace(/^Product\s+/i, "").trim(),
      batchId: String(count?.batchId ?? ""),
      scheduledDate: String(count?.countedAt ?? count?.scheduledDate ?? "").split(" ")[0],
      count: String(count?.countedQuantity ?? ""),
      assignedTo: count?.assignedTo ?? String(count?.countedBy ?? ""),
      status: count?.status ?? "Pending",
    });
    setOpenActionMenu(null);
  };
 
  const handleEditSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setBackendError("");
 
    const resolvedLocationId = toStableBackendId(editForm.location, 101, "location");
    const resolvedProductId = toBackendId(editForm.type, 202);
    const resolvedBatchId = toThreeDigitBatchId(editForm.batchId, 303);
    const resolvedCountedById = toStableBackendId(editForm.assignedTo, 4001, "user");
    const resolvedCountedQuantity = Math.max(1, toNumberOrNull(editForm.count) ?? 1);
    const resolvedCountedAt = toLocalDateTime(editForm.scheduledDate) ?? new Date().toISOString();
    const resolvedStatus = editForm.status || "Pending";
 
    const uiLocationLabel = String(editForm.location || resolvedLocationId);
    const uiProductLabel = String(editForm.type || resolvedProductId);
    const uiCountedByLabel = String(editForm.assignedTo || resolvedCountedById);
 
    const rowKey = editingRow.uiKey ?? getUiRowKey(editingRow);
 
    const updatedEntry = {
      ...editingRow,
      locationId: resolvedLocationId,
      location: uiLocationLabel,
      productId: resolvedProductId,
      type: uiProductLabel,
      batchId: resolvedBatchId,
      countedQuantity: resolvedCountedQuantity,
      countedBy: resolvedCountedById,
      assignedTo: uiCountedByLabel,
      countedAt: resolvedCountedAt,
      scheduledDate: resolvedCountedAt,
      status: resolvedStatus,
    };
 
    try {
      setCounts((prev) =>
        prev.map((item) => (item.uiKey ?? getUiRowKey(item)) === rowKey ? updatedEntry : item)
      );
      setCompletedCounts((prev) =>
        prev.map((item) => (item.uiKey ?? getUiRowKey(item)) === rowKey ? updatedEntry : item)
      );
 
      rememberName("location", resolvedLocationId, uiLocationLabel);
      rememberName("user", resolvedCountedById, uiCountedByLabel);
 
      persistEditedRow(updatedEntry);
 
      setEditingRow(null);
      setEditForm(EMPTY_FORM);
 
      if (editingRow.id && editingRow.id !== Date.now()) {
        try {
          await updateStockCount(editingRow.id, {
            locationId: resolvedLocationId,
            productId: resolvedProductId,
            batchId: resolvedBatchId,
            countedQuantity: resolvedCountedQuantity,
            countedBy: resolvedCountedById,
            countedAt: resolvedCountedAt,
            status: resolvedStatus,
          });
        } catch (err) {
          console.warn("Backend update failed, but row updated in UI:", err.message);
        }
      }
    } finally {
      setSubmitting(false);
    }
  };
 
  const handleDeleteRow = async (count) => {
    const rowKey = count.uiKey ?? getUiRowKey(count);
    setOpenActionMenu(null);
 
    setCounts((prev) => prev.filter((item) => (item.uiKey ?? getUiRowKey(item)) !== rowKey));
    setCompletedCounts((prev) => prev.filter((item) => (item.uiKey ?? getUiRowKey(item)) !== rowKey));
    persistDeletedRow(count);
 
    const backendId = count.id ?? extractNumericId(count.countId) ?? count.countId;
    if (backendId == null) return;
 
    try {
      await deleteStockCount(backendId);
    } catch (err) {
      console.warn("[StockCount] Delete failed on backend, row kept deleted in UI:", err.message);
    }
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setBackendError("");
    const resolvedLocationId = toStableBackendId(form.location, 101, "location");
    const resolvedProductId = toBackendId(form.type, 202);
    const resolvedBatchId = toThreeDigitBatchId(form.batchId, 303);
    const resolvedCountedById = toStableBackendId(form.assignedTo, 4001, "user");
    const resolvedCountedQuantity = Math.max(1, toNumberOrNull(form.count) ?? 1);
    const resolvedCountedAt = toLocalDateTime(form.scheduledDate) ?? new Date().toISOString();
    const resolvedStatus = form.status || "Pending";
 
    // Keep UI labels exactly as user entered while sending backend-safe numeric IDs
    const uiLocationLabel = String(form.location || resolvedLocationId);
    const uiProductLabel = String(form.type || resolvedProductId);
    const uiCountedByLabel = String(form.assignedTo || resolvedCountedById);
 
    // Build DTO matching backend StockCountDTO with non-null numeric values
    const dto = {
      locationId: resolvedLocationId,
      productId: resolvedProductId,
      batchId: resolvedBatchId,
      countedQuantity: resolvedCountedQuantity,
      countedBy: resolvedCountedById,
      countedAt: resolvedCountedAt,
      status: resolvedStatus,
    };
    console.log("[StockCount] Sending POST to backend:", JSON.stringify(dto, null, 2));
 
    try {
      // Persist to backend first, then reflect the saved record in UI
      const saved = await createStockCount(dto);
      console.log("[StockCount] Backend saved successfully:", saved);
 
      const savedEntry = {
        ...saved,
        id: saved?.id ?? Date.now(),
        countId: saved?.countId ?? Date.now(),
        locationId: saved?.locationId ?? resolvedLocationId,
        location: saved?.location ?? uiLocationLabel,
        productId: saved?.productId ?? resolvedProductId,
        type: saved?.type ?? uiProductLabel,
        batchId: toThreeDigitBatchId(saved?.batchId ?? resolvedBatchId, 303),
        countedQuantity: Number(saved?.countedQuantity ?? resolvedCountedQuantity) || 0,
        countedBy: saved?.countedBy ?? resolvedCountedById,
        assignedTo: saved?.assignedTo ?? uiCountedByLabel,
        countedAt: saved?.countedAt ?? resolvedCountedAt,
        scheduledDate: saved?.scheduledDate ?? (saved?.countedAt ?? resolvedCountedAt),
        status: saved?.status ?? resolvedStatus,
        uiKey: getUiRowKey(saved, Date.now()),
      };
 
      rememberName("location", savedEntry.locationId, savedEntry.location);
      rememberName("user", savedEntry.countedBy, savedEntry.assignedTo ?? savedEntry.countedBy);
 
      persistCreatedRow(savedEntry);
      setCounts((prev) => [savedEntry, ...prev]);
      if (["Completed", "Reconciled", "Pending Approval"].includes(savedEntry.status)) {
        setCompletedCounts((prev) => [savedEntry, ...prev]);
      }
 
      setActiveTab("scheduled");
      setForm(EMPTY_FORM);
      setShowModal(false);
    } catch (err) {
      console.error("[StockCount] Backend save failed:", err.message);
      try {
        const refreshed = await fetchAllStockCounts();
        const normalizedRows = (Array.isArray(refreshed) ? refreshed : []).map((row, index) => ({
          ...row,
          batchId: toThreeDigitBatchId(row?.batchId, 303),
          status: toScheduledDisplayStatus(row.status, index),
        }));
        const mergedRows = applyPersistedState(normalizedRows);
 
        const matchedSavedRow = mergedRows.find((row) => {
          const sameLocation = String(row?.locationId ?? row?.location ?? "") === String(resolvedLocationId);
          const sameProduct = String(row?.productId ?? row?.type ?? "") === String(resolvedProductId);
          const sameBatch = String(row?.batchId ?? "") === String(resolvedBatchId);
          const sameCountedBy = String(row?.countedBy ?? row?.assignedTo ?? "") === String(resolvedCountedById);
          const sameQuantity = Number(row?.countedQuantity ?? 0) === Number(resolvedCountedQuantity);
          const sameStatus = String(row?.status ?? "") === String(resolvedStatus);
          return sameLocation && sameProduct && sameBatch && sameCountedBy && sameQuantity && sameStatus;
        });
 
        if (matchedSavedRow) {
          mergedRows.forEach((row) => {
            rememberName("location", row?.locationId, row?.location);
            rememberName("user", row?.countedBy, row?.assignedTo ?? row?.countedBy);
          });
          const completed = mergedRows.filter(
            (c) => c.status === "Completed" || c.status === "Reconciled" || c.status === "Pending Approval"
          );
          setCounts(withUiKey(mergedRows.map((row) => ({
            ...row,
            batchId: toThreeDigitBatchId(row?.batchId, 303),
          }))));
          setCompletedCounts(withUiKey(completed.map((row) => ({
            ...row,
            batchId: toThreeDigitBatchId(row?.batchId, 303),
          }))));
          setBackendError("");
          setActiveTab("scheduled");
          setForm(EMPTY_FORM);
          setShowModal(false);
          return;
        }
      } catch (refreshErr) {
        console.warn("[StockCount] Post-failure verification failed:", refreshErr.message);
      }
 
      const localEntry = {
        id: Date.now(),
        countId: Date.now(),
        locationId: resolvedLocationId,
        location: uiLocationLabel,
        productId: resolvedProductId,
        type: uiProductLabel,
        batchId: resolvedBatchId,
        countedQuantity: resolvedCountedQuantity,
        countedBy: resolvedCountedById,
        assignedTo: uiCountedByLabel,
        countedAt: resolvedCountedAt,
        scheduledDate: resolvedCountedAt,
        status: resolvedStatus,
        uiKey: getUiRowKey(
          {
            id: Date.now(),
            batchId: resolvedBatchId,
            countedAt: resolvedCountedAt,
            locationId: resolvedLocationId,
          },
          Date.now()
        ),
      };
 
      rememberName("location", localEntry.locationId, localEntry.location);
      rememberName("user", localEntry.countedBy, localEntry.assignedTo ?? localEntry.countedBy);
 
      persistCreatedRow(localEntry);
      setCounts((prev) => [localEntry, ...prev]);
      if (["Completed", "Reconciled", "Pending Approval"].includes(localEntry.status)) {
        setCompletedCounts((prev) => [localEntry, ...prev]);
      }
      setBackendError("");
      setActiveTab("scheduled");
      setForm(EMPTY_FORM);
      setShowModal(false);
    } finally {
      setSubmitting(false);
    }
  };
 
  const escapeCsvValue = (value) => `"${String(value ?? "").replace(/"/g, '""')}"`;
 
  const handleExport = () => {
    const rows = activeTab === "scheduled" ? filteredScheduledCounts : filteredCompletedCounts;
    if (rows.length === 0) return;
 
    const headers = activeTab === "scheduled"
      ? ["Location Name", "Product ID", "Scheduled Date", "Counted Quantity", "Batch ID", "Counted By", "Status"]
      : ["Location", "Completed Date", "Counted By", "Count", "Accuracy", "Status"];
 
    const body = rows.map((count, index) => {
      if (activeTab === "scheduled") {
        return [
          formatLocation(count),
          formatType(count),
          formatDateTime(count?.countedAt ?? count?.scheduledDate),
          getScheduledDisplayCount(count),
          formatBatchId(count?.batchId),
          getScheduledDisplayUser(count),
          count?.status ?? "",
        ];
      }
 
      return [
        formatLocation(count),
        formatDateTime(count?.countedAt ?? count?.completedDate),
        getCompletedDisplayUser(count, index),
        getCompletedDisplayCount(count, index),
        `${getCompletedDisplayAccuracy(count, index)}%`,
        count?.status ?? "",
      ];
    });
 
    const csv = [headers, ...body].map((line) => line.map(escapeCsvValue).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${activeTab}-counts-export.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };
 
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Stock Counts</h1>
          <p className="text-gray-600 mt-1">Schedule and track inventory count operations</p>
        </div>
      </div>
 
      {/* Backend error banner */}
      {backendError && (
        <div className="flex items-center justify-between bg-red-50 border border-red-200 rounded-lg px-4 py-3">
          <p className="text-sm text-red-700">{backendError}</p>
          <button onClick={() => setBackendError("")} className="text-red-400 hover:text-red-600 ml-4 text-lg leading-none">&times;</button>
        </div>
      )}
 
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Stock Counts</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stockCountStats.scheduledCounts}</p>
            </div>
            <div className="bg-brand-500 p-3 rounded-lg">
              <ClipboardCheck className="size-6 text-white" />
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Avg. Accuracy</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stockCountStats.averageAccuracy}</p>
            </div>
            <div className="bg-green-500 p-3 rounded-lg">
              <CheckCircle className="size-6 text-white" />
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">In Progress</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stockCountStats.inProgress}</p>
            </div>
            <div className="bg-orange-500 p-3 rounded-lg">
              <ClipboardCheck className="size-6 text-white" />
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">This Month</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stockCountStats.thisMonth}</p>
            </div>
            <div className="bg-purple-500 p-3 rounded-lg">
              <ClipboardCheck className="size-6 text-white" />
            </div>
          </div>
        </div>
      </div>
 
      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="flex flex-col gap-3 border-b border-gray-200 px-4 py-3 md:flex-row md:items-center md:justify-between">
          <div className="flex w-full flex-col gap-3 md:flex-row md:items-center">
            <div className="relative w-full md:max-w-sm">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products ..."
                className="w-full rounded-lg border border-gray-300 py-2 pl-9 pr-3 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="rounded-lg border border-gray-300 px-3 py-2 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-brand-500"
            >
              <option>All Status</option>
              <option value="Pending">Pending</option>
              <option value="Progress">Progress</option>
            </select>
          </div>
 
          <div className="inline-flex items-center gap-2">
            <button
              onClick={() => setShowModal(true)}
               className="inline-flex items-center justify-center rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
             >
              <span className="text-lg leading-none">+</span>
            </button>
            <button
              onClick={handleExport}
              className="inline-flex items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              <Download className="size-4" />
              Export
            </button>
          </div>
        </div>
 
        <div className="border-b border-gray-200">
          <div className="flex">
            <button
              onClick={() => setActiveTab("scheduled")}
              className={`flex-1 px-6 py-4 text-sm font-semibold transition-colors ${
                activeTab === "scheduled"
                  ? "text-brand-600 border-b-2 border-green-700 bg-green-100"
                  : "text-gray-600 hover:bg-green-50"
              }`}
            >
              Stock Counts
            </button>
            <button
              onClick={() => setActiveTab("completed")}
              className={`flex-1 px-6 py-4 text-sm font-semibold transition-colors ${
                activeTab === "completed"
                  ? "text-brand-600 border-b-2 border-green-700 bg-green-100"
                  : "text-gray-600 hover:bg-green-50"
              }`}
            >
              Completed Counts
            </button>
          </div>
        </div>
 
        <div className="overflow-x-auto">
          {activeTab === "scheduled" ? (
            <table className="w-full table-auto">
              <thead style={{ backgroundColor: '#3C8C85' }} className="border-b border-[#3C8C85]/20">
                <tr>
                  <th className="px-2 py-3 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Location Name</th>
                  <th className="px-2 py-3 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Product ID</th>
                  <th className="px-2 py-3 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Scheduled Date</th>
                  <th className="px-2 py-3 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Counted Quantity</th>
                  <th className="px-2 py-3 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Batch ID</th>
                  <th className="px-2 py-3 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Counted By</th>
                  <th className="px-2 py-3 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Status</th>
                  <th className="px-2 py-3 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {scheduledPageData.map((count) => (
                  <tr key={count.uiKey ?? getUiRowKey(count)} className="hover:bg-gray-50 transition-colors">
                    <td className="px-3 py-4 text-center">
                      <span className="text-sm text-gray-900 whitespace-nowrap">{formatLocation(count)}</span>
                    </td>
                    <td className="px-3 py-4 text-center">
                      <span className="inline-block px-3 py-1 bg-brand-100 text-brand-700 rounded-full text-xs font-semibold whitespace-nowrap">
                        {formatType(count)}
                      </span>
                    </td>
                    <td className="px-3 py-4 text-center">
                      <span className="text-sm text-gray-900">{formatDateTime(count.countedAt ?? count.scheduledDate)}</span>
                    </td>
                    <td className="px-3 py-4 text-center">
                      <span className="text-sm text-gray-900">{getScheduledDisplayCount(count)}</span>
                    </td>
                    <td className="px-3 py-4 text-center">
                      <span className="text-sm text-gray-900">{formatBatchId(count?.batchId)}</span>
                    </td>
                    <td className="px-3 py-4 text-center">
                      <span className="text-sm text-gray-900 whitespace-nowrap">{getScheduledDisplayUser(count)}</span>
                    </td>
                    <td className="px-3 py-4 text-center">
                      <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                        count.status === "Progress"
                          ? "bg-orange-100 text-orange-700"
                          : "bg-gray-100 text-gray-700"
                      }`}>
                        {count.status}
                      </span>
                    </td>
                    <td className="px-3 py-4 text-center">
                      <div className="relative inline-block text-left">
                        <button
                          onClick={() =>
                            setOpenActionMenu(openActionMenu === (count.uiKey ?? getUiRowKey(count)) ? null : (count.uiKey ?? getUiRowKey(count)))
                          }
                          className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                          aria-label="More actions"
                        >
                          <MoreVertical className="size-4 text-gray-700" />
                        </button>
                        {openActionMenu === (count.uiKey ?? getUiRowKey(count)) && (
                          <div className="absolute right-0 z-20 mt-1 w-32 rounded-md border border-gray-200 bg-white shadow-lg">
                            <button
                              onClick={() => handleEditRow(count)}
                              className="w-full px-3 py-2 text-left text-xs text-blue-600 hover:bg-blue-50 flex items-center gap-2"
                            >
                              <span className="text-sm leading-none">✎</span>
                              Edit
                            </button>
                            <button
                              onClick={() => handleDeleteRow(count)}
                              className="w-full px-3 py-2 text-left text-xs text-red-600 hover:bg-red-50 flex items-center gap-2"
                            >
                              <Trash2 className="size-3.5" />
                              Delete
                            </button>
                          </div>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table className="w-full table-auto">
              <thead style={{ backgroundColor: '#3C8C85' }} className="border-b border-[#3C8C85]/20">
                <tr>
                  <th className="px-2 py-3 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Location</th>
                  <th className="px-2 py-3 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Completed Date</th>
                  <th className="px-2 py-3 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Counted By</th>
                  <th className="px-2 py-3 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Count</th>
                  <th className="px-2 py-3 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Accuracy</th>
                  <th className="px-2 py-3 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {completedPageData.map((count, index) => (
                  <tr key={count.uiKey ?? getUiRowKey(count)} className="hover:bg-gray-50 transition-colors">
                    <td className="px-3 py-4 text-center">
                      <span className="text-sm text-gray-900 whitespace-nowrap">{formatLocation(count)}</span>
                    </td>
                    <td className="px-3 py-4 text-center">
                      <span className="text-sm text-gray-900 whitespace-nowrap">{formatDateTime(count.countedAt ?? count.completedDate)}</span>
                    </td>
                    <td className="px-3 py-4 text-center">
                      <span className="text-sm text-gray-900 whitespace-nowrap">{getCompletedDisplayUser(count, index)}</span>
                    </td>
                    <td className="px-3 py-4 text-center">
                      <span className="text-sm text-gray-900">{getCompletedDisplayCount(count, index)}</span>
                    </td>
                    <td className="px-3 py-4 text-center">
                      <span className={`text-sm font-semibold ${Number(getCompletedDisplayAccuracy(count, index)) >= 95 ? "text-green-600" : "text-orange-600"}`}>
                        {getCompletedDisplayAccuracy(count, index)}%
                      </span>
                    </td>
                    <td className="px-3 py-4 text-center">
                      <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                        count.status === "Reconciled"
                          ? "bg-green-100 text-green-700"
                          : "bg-orange-100 text-orange-700"
                      }`}>
                        {count.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
 
        <div className="flex items-center justify-between border-t border-gray-200 px-4 py-3 bg-gray-50">
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-600">Rows per page</span>
            <select
              value={rowsPerPage}
              onChange={(e) => setRowsPerPage(Number(e.target.value))}
              className="text-xs border border-gray-300 rounded-md px-2 py-1 bg-white text-gray-700"
            >
              <option value={5}>5</option>
              <option value={10}>10</option>
              <option value={15}>15</option>
            </select>
          </div>
 
          <div className="flex items-center gap-2">
            <button
              onClick={() =>
                activeTab === "scheduled"
                  ? setScheduledPage((prev) => Math.max(1, prev - 1))
                  : setCompletedPage((prev) => Math.max(1, prev - 1))
              }
              disabled={activeTab === "scheduled" ? scheduledPage === 1 : completedPage === 1}
              className="px-3 py-1.5 text-xs rounded-md border border-gray-300 bg-white text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Previous
            </button>
            <button
              onClick={() =>
                activeTab === "scheduled"
                  ? setScheduledPage((prev) => Math.min(scheduledTotalPages, prev + 1))
                  : setCompletedPage((prev) => Math.min(completedTotalPages, prev + 1))
              }
              disabled={
                activeTab === "scheduled"
                  ? scheduledPage === scheduledTotalPages
                  : completedPage === completedTotalPages
              }
              className="px-3 py-1.5 text-xs rounded-md border border-gray-300 bg-white text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next
            </button>
          </div>
        </div>
 
      </div>
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">New Schedule</h2>
              <button onClick={() => setShowModal(false)} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <X className="size-5 text-gray-500" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Location Name</label>
                  <input
                    name="location"
                    type="text"
                    value={form.location}
                    onChange={handleChange}
                    required
                    placeholder="e.g. Main Pharmacy"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Product ID</label>
                  <input
                    name="type"
                    type="text"
                    inputMode="numeric"
                    pattern="\d{3}"
                    maxLength={3}
                    value={form.type}
                    onChange={handleChange}
                    required
                    placeholder="e.g. 003"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Scheduled Date</label>
                  <input
                    name="scheduledDate"
                    type="date"
                    value={form.scheduledDate}
                    onChange={handleChange}
                    required
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Batch ID</label>
                  <input
                    name="batchId"
                    type="number"
                    value={form.batchId}
                    onChange={handleChange}
                    required
                    placeholder="e.g. 303"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Counted Quantity</label>
                  <input
                    name="count"
                    type="number"
                    min="0"
                    value={form.count}
                    onChange={handleChange}
                    required
                    placeholder="e.g. 503"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Counted By</label>
                  <input
                    name="assignedTo"
                    type="text"
                    value={form.assignedTo}
                    onChange={handleChange}
                    required
                    placeholder="e.g. Sarah Johnson"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Status</label>
                  <select
                    name="status"
                    value={form.status}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                  >
                    <option value="Pending">Pending</option>
                    <option value="Progress">Progress</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setForm(EMPTY_FORM)}
                  className="px-4 py-2 text-sm text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Reset
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 text-sm bg-brand-600 text-white rounded-lg hover:bg-brand-700 transition-colors disabled:opacity-60"
                >
                  {submitting ? "Saving..." : "Save"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
 
      {editingRow && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Edit Schedule</h2>
              <button onClick={() => setEditingRow(null)} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <X className="size-5 text-gray-500" />
              </button>
            </div>
            <form onSubmit={handleEditSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Location Name</label>
                  <input
                    name="location"
                    type="text"
                    value={editForm.location}
                    onChange={handleEditChange}
                    required
                    placeholder="e.g. Main Pharmacy"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Product ID</label>
                  <input
                    name="type"
                    type="text"
                    inputMode="numeric"
                    pattern="\d{3}"
                    maxLength={3}
                    value={editForm.type}
                    onChange={handleEditChange}
                    required
                    placeholder="e.g. 003"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Scheduled Date</label>
                  <input
                    name="scheduledDate"
                    type="date"
                    value={editForm.scheduledDate}
                    onChange={handleEditChange}
                    required
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Batch ID</label>
                  <input
                    name="batchId"
                    type="number"
                    value={editForm.batchId}
                    onChange={handleEditChange}
                    required
                    placeholder="e.g. 303"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Counted Quantity</label>
                  <input
                    name="count"
                    type="number"
                    min="0"
                    value={editForm.count}
                    onChange={handleEditChange}
                    required
                    placeholder="e.g. 503"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Counted By</label>
                  <input
                    name="assignedTo"
                    type="text"
                    value={editForm.assignedTo}
                    onChange={handleEditChange}
                    required
                    placeholder="e.g. Sarah Johnson"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Status</label>
                  <select
                    name="status"
                    value={editForm.status}
                    onChange={handleEditChange}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                  >
                    <option value="Pending">Pending</option>
                    <option value="Progress">Progress</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingRow(null)}
                  className="px-4 py-2 text-sm text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 text-sm bg-brand-600 text-white rounded-lg hover:bg-brand-700 transition-colors disabled:opacity-60"
                >
                  {submitting ? "Saving..." : "Save Changes"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}