import { useState, useMemo, useEffect } from "react";
import { X, Plus, Search, CheckCircle2, XCircle, Trash2, MoreVertical } from "lucide-react";
import { returnAPI, productsAPI, batchesAPI } from "../../services/api";

const PAGE_SIZE = 7;

export function StaffReturns() {
  const currentUser = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem("pharmaShelfUser") || "{}");
    } catch {
      return {};
    }
  }, []);

  const currentUserName = currentUser?.name || currentUser?.email || "Staff";

  const userRoleString = String(currentUser?.role || "").toUpperCase();
  const isPharmacistUser = userRoleString.includes("PHARM");
  const isClinicianUser = userRoleString.includes("CLINICIAN");
  const isNurseUser = userRoleString.includes("NURSE");

  console.log("🔍 Role Detection (StaffReturns):", {
    rawRole: currentUser?.role,
    userRoleString,
    isPharmacistUser,
    isClinicianUser,
    isNurseUser,
  });

  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [toast, setToast] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  const [returnsList, setReturnsList] = useState([]);
  const [activeMenuId, setActiveMenuId] = useState(null);
  const [productMap, setProductMap] = useState({});
  const [batchProductMap, setBatchProductMap] = useState({});

  // Form state
  const [newReturn, setNewReturn] = useState({
    dispenseId: "",
    batchId: "",
    quantity: "",
    reason: "",
  });
  const [formErrors, setFormErrors] = useState({});
  const [batchesByDispense, setBatchesByDispense] = useState({});
  const [loadingBatches, setLoadingBatches] = useState(false);

  // Load all data
  const loadAllData = async () => {
    try {
      setLoading(true);
      setError("");

      // Fetch returns, products, and batches in parallel
      const [returnsData, productsData, batchesData] = await Promise.all([
        returnAPI.getAll().catch(() => []),
        productsAPI.getAll().catch(() => []),
        batchesAPI.getAll().catch(() => []),
      ]);
      
      console.log("🔍 Returns API Response (raw):", returnsData);
      console.log("🔍 Products API Response:", productsData);
      console.log("🔍 Batches API Response:", batchesData);

      // Extract data from wrapped responses - handle multiple formats
      let returnsArray = [];
      if (Array.isArray(returnsData)) {
        returnsArray = returnsData;
      } else if (returnsData?.data && Array.isArray(returnsData.data)) {
        returnsArray = returnsData.data;
      } else if (returnsData?.returns && Array.isArray(returnsData.returns)) {
        returnsArray = returnsData.returns;
      } else if (returnsData && typeof returnsData === "object") {
        for (const key in returnsData) {
          if (Array.isArray(returnsData[key])) {
            returnsArray = returnsData[key];
            break;
          }
        }
      }

      // Extract products
      const productsArray = Array.isArray(productsData) ? productsData : (productsData?.data || []);
      const batchesArray = Array.isArray(batchesData) ? batchesData : (batchesData?.data || []);

      // Create product map for quick lookup
      const pMap = {};
      productsArray.forEach(product => {
        const prodId = product.productId || product.id;
        pMap[prodId] = product.name || product.productName || `Product ${prodId}`;
      });
      setProductMap(pMap);

      // Create batch to product map
      const bMap = {};
      batchesArray.forEach(batch => {
        const batchId = batch.batchId || batch.id;
        const productId = batch.productId || batch.product_id;
        if (productId) {
          bMap[batchId] = productId;
        }
      });
      setBatchProductMap(bMap);

      console.log("📋 Extracted Returns Array:", returnsArray);
      console.log("📋 Product Map:", pMap);

      // Normalize returns with product names
      const normalized = returnsArray.map((row, idx) => {
        const batchId = row?.batchID ?? row?.batchId ?? row?.batch_id ?? "N/A";
        const productId = bMap[batchId];
        const productName = productId ? pMap[productId] : "Unknown Product";

        const normalized = {
          id: row?.returnId ?? row?.id ?? row?.return_id ?? `RET-${Date.now()}-${idx}`,
          dispenseId: row?.dispenseID ?? row?.dispenseId ?? row?.dispense_id ?? "N/A",
          batchId: batchId,
          productName: productName,
          quantity: Number(row?.quantity ?? 0),
          reason: row?.reason ?? row?.returnReason ?? row?.return_reason ?? "N/A",
          returnedBy: row?.returnedBy ?? row?.returned_by ?? row?.createdBy ?? currentUserName,
          returnedDate: row?.returnedDate ?? row?.returned_date ?? row?.createdAt ?? new Date().toISOString(),
          status: String(row?.status || "ACTIVE").toUpperCase(),
        };
        console.log(`  → Normalized to:`, normalized);
        return normalized;
      });

      console.log("✅ Total normalized returns:", normalized.length);
      console.log("✅ Normalized data:", normalized);
      setReturnsList(normalized);
    } catch (err) {
      console.error("Failed to fetch data:", err);
      setError(err?.message || "Failed to load data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  const filteredReturns = useMemo(() => {
    console.log("🔄 Filtering returns. Total:", returnsList.length, "ActiveTab:", activeTab, "SearchQuery:", searchQuery);
    
    const filtered = returnsList.filter((ret) => {
      // For "all" tab, include everything; otherwise filter by status
      const matchesTab = activeTab === "all" || ret.status === activeTab.toUpperCase();
      const matchesSearch =
        String(ret.productName).toLowerCase().includes(searchQuery.toLowerCase()) ||
        String(ret.reason).toLowerCase().includes(searchQuery.toLowerCase());
      
      if (!matchesTab) {
        console.log("❌ Status mismatch:", ret.status, "vs", activeTab.toUpperCase());
      }
      return matchesTab && matchesSearch;
    });
    
    console.log("✅ Filtered returns:", filtered.length);
    return filtered;
  }, [returnsList, activeTab, searchQuery]);

  const totalPages = Math.max(1, Math.ceil(filteredReturns.length / PAGE_SIZE));
  const safePage = Math.min(Math.max(1, currentPage), totalPages);
  const start = (safePage - 1) * PAGE_SIZE;
  const paginatedReturns = filteredReturns.slice(start, start + PAGE_SIZE);

  const stats = {
    all: returnsList.length,
    active: returnsList.filter((r) => r.status === "ACTIVE").length,
    processed: returnsList.filter((r) => r.status === "PROCESSED").length,
    rejected: returnsList.filter((r) => r.status === "REJECTED").length,
  };

  const showToast = (message, type = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  function openAdd() {
    setNewReturn({
      dispenseId: "",
      batchId: "",
      quantity: "",
      reason: "",
    });
    setBatchesByDispense({});
    setFormErrors({});
    setShowModal(true);
  }

  // Fetch batches when dispenseId is entered
  const handleDispenseIdChange = async (value) => {
    setNewReturn({ ...newReturn, dispenseId: value, batchId: "" });
    if (formErrors.dispenseId) setFormErrors({ ...formErrors, dispenseId: "" });

    if (!value.trim()) {
      setBatchesByDispense([]);
      return;
    }

    try {
      setLoadingBatches(true);
      // Try to fetch batches for this dispense ID
      try {
        const response = await returnAPI.getDispenseBatches(value);
        console.log("📦 Fetched batches for dispense:", value, response);
        
        // Handle different response formats
        let batches = [];
        if (Array.isArray(response)) {
          batches = response;
        } else if (response?.data && Array.isArray(response.data)) {
          batches = response.data;
        } else if (response?.batches && Array.isArray(response.batches)) {
          batches = response.batches;
        }

        if (batches.length > 0) {
          setBatchesByDispense(batches);
        } else {
          setBatchesByDispense([]);
        }
      } catch (apiErr) {
        console.warn("Batch fetch not available, allowing manual entry:", apiErr);
        // If API doesn't work, allow manual entry
        setBatchesByDispense([{ batchId: "manual", label: "Manual Entry" }]);
      }
    } catch (err) {
      console.error("Failed to fetch batches:", err);
      setBatchesByDispense([{ batchId: "manual", label: "Manual Entry" }]);
    } finally {
      setLoadingBatches(false);
    }
  };

  const validateForm = () => {
    const errors = {};
    if (!newReturn.dispenseId.trim()) errors.dispenseId = "Dispense ID is required";
    if (!newReturn.batchId.trim()) errors.batchId = "Batch ID is required";
    if (!newReturn.quantity || Number(newReturn.quantity) <= 0)
      errors.quantity = "Quantity must be greater than 0";
    if (!newReturn.reason.trim()) errors.reason = "Return reason is required";
    return errors;
  };

  async function handleSave() {
    const errors = validateForm();
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    try {
      setSubmitting(true);
      const payload = {
        dispenseId: newReturn.dispenseId,
        batchId: newReturn.batchId,
        quantity: Number(newReturn.quantity),
        reason: newReturn.reason,
        returnedBy: currentUserName,
        status: "ACTIVE",
      };

      console.log("📤 Submitting return:", payload);
      await returnAPI.create(payload);
      showToast("Return created successfully!", "success");
      setShowModal(false);
      loadAllData();
    } catch (err) {
      console.error("Failed to create return:", err);
      showToast(err?.message || "Failed to create return", "error");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(returnId) {
    if (!window.confirm("Delete this return?")) return;
    try {
      await returnAPI.delete(returnId);
      showToast("Return deleted successfully!", "success");
      loadAllData();
    } catch (err) {
      showToast(err?.message || "Failed to delete return", "error");
    }
  }

  const getStatusBadgeColor = (status) => {
    switch (status) {
      case "ACTIVE":
        return "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-blue-100 text-blue-800 border border-blue-300";
      case "PROCESSED":
        return "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-green-100 text-green-800 border border-green-300";
      case "REJECTED":
        return "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-red-100 text-red-800 border border-red-300";
      default:
        return "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-gray-100 text-gray-800 border border-gray-300";
    }
  };

  // Render returns management UI
  if (isNurseUser || isClinicianUser || isPharmacistUser) {
    return (
      <div className="space-y-4 p-4">
        {toast && (
          <div className="fixed top-4 right-4 z-50">
            <div
              className={`min-w-[280px] max-w-[420px] rounded-xl border px-4 py-3 shadow-lg backdrop-blur-sm ${
                toast.type === "success"
                  ? "bg-green-50 border-green-200 text-green-800"
                  : "bg-red-50 border-red-200 text-red-800"
              }`}
            >
              <div className="flex items-start gap-2">
                {toast.type === "success" ? (
                  <CheckCircle2 className="size-5 mt-0.5 text-green-600" />
                ) : (
                  <XCircle className="size-5 mt-0.5 text-red-600" />
                )}
                <p className="text-sm font-medium">{toast.message}</p>
              </div>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold text-gray-900">Returns Management</h1>
            <p className="text-gray-500 text-xs mt-0.5">Manage medication returns and stock returns</p>
          </div>
        </div>

        {/* Tab Navigation & Controls */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="p-4 border-b flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <h2 className="text-base font-semibold text-gray-900">Returns List</h2>
            <button
              onClick={openAdd}
              className="flex items-center justify-center w-8 h-8 bg-[#3C8C85] hover:bg-[#337872] text-white rounded-md text-xs font-medium"
              title="Add Return"
            >
              <Plus size={16} />
            </button>
          </div>

          {/* Tabs */}
          <div className="border-b border-gray-200">
            <div className="flex">
              {[
                { key: "all", label: `All (${stats.all})` },
                { key: "active", label: `Active (${stats.active})` },
                { key: "processed", label: `Processed (${stats.processed})` },
                { key: "rejected", label: `Rejected (${stats.rejected})` },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => {
                    setActiveTab(tab.key);
                    setSearchQuery("");
                    setCurrentPage(1);
                  }}
                  className={`flex-1 px-6 py-2 text-sm font-semibold transition-colors whitespace-nowrap ${
                    activeTab === tab.key
                      ? "text-[#3C8C85] border-b-2 border-[#3C8C85] bg-[#3C8C85]/10"
                      : "text-gray-500 hover:text-[#3C8C85] hover:bg-[#3C8C85]/5"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Search */}
          <div className="p-4 bg-gray-50 border-b flex flex-wrap gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
              <input
                className="w-full pl-8 pr-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#3C8C85]/40"
                placeholder="Search by Product Name or reason..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
              />
            </div>
          </div>

          {/* Loading State */}
          {loading && (
            <div className="p-6 text-center text-sm text-gray-500">
              Loading returns...
            </div>
          )}

          {/* Error State - More Prominent */}
          {error && !loading && (
            <div className="p-4 bg-red-50 border-l-4 border-red-500 text-red-700">
              <p className="font-semibold">Error Loading Returns</p>
              <p className="text-sm mt-1">{error}</p>
              {error.includes("403") && (
                <p className="text-sm mt-2 font-semibold">
                  💡 This is a permission error. Your role might not have access to the returns API. 
                  Please ask your administrator to grant CLINICIAN role access to returns.
                </p>
              )}
            </div>
          )}

          {/* Empty State */}
          {!loading && paginatedReturns.length === 0 && (
            <div className="p-6 text-center text-sm text-gray-500">
              {searchQuery ? "No returns found matching your search." : "No returns found in this category."}
            </div>
          )}

          {/* Returns Table */}
          {!loading && paginatedReturns.length > 0 && (
            <>
              {console.log("🎯 Rendering table with", paginatedReturns.length, "rows")}
              <div className="overflow-x-auto overflow-y-visible">
                <table className="w-full text-sm">
                  <thead style={{ background: "#3C8C85" }} className="border-b border-gray-200">
                    <tr>
                      <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: "#fff" }}>Product Name</th>
                      <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: "#fff" }}>Quantity</th>
                      <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: "#fff" }}>Reason</th>
                      <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: "#fff" }}>Returned By</th>
                      <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: "#fff" }}>Date</th>
                      <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: "#fff" }}>Status</th>
                      <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: "#fff" }}>Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {paginatedReturns.map((ret) => (
                      <tr key={ret.id} className="hover:bg-gray-50">
                        <td className="px-4 py-3 text-center text-gray-600">{ret.productName}</td>
                        <td className="px-4 py-3 text-center text-gray-600">{ret.quantity}</td>
                        <td className="px-4 py-3 text-center text-gray-600 text-xs">{ret.reason}</td>
                        <td className="px-4 py-3 text-center text-gray-600">{ret.returnedBy}</td>
                        <td className="px-4 py-3 text-center text-gray-600 text-xs">
                          {new Date(ret.returnedDate).toLocaleDateString()}
                        </td>
                        <td className="px-4 py-3 text-center">
                          <span className={getStatusBadgeColor(ret.status)}>
                          {ret.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center relative">
                        <button
                          onClick={() => setActiveMenuId(activeMenuId === ret.id ? null : ret.id)}
                          className="p-1.5 rounded hover:bg-gray-200 text-gray-600 hover:text-gray-900"
                          title="Actions"
                        >
                          <MoreVertical size={16} />
                        </button>
                        {activeMenuId === ret.id && (
                          <div className="absolute right-0 top-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-10 min-w-[140px]">
                            <button
                              onClick={() => {
                                handleDelete(ret.id);
                                setActiveMenuId(null);
                              }}
                              className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 first:rounded-t-lg last:rounded-b-lg flex items-center gap-2"
                            >
                              <Trash2 size={14} />
                              Delete
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              </div>
            </>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="p-4 border-t flex items-center justify-between">
              <span className="text-sm text-gray-600">
                Showing {start + 1}-{Math.min(start + PAGE_SIZE, filteredReturns.length)} of {filteredReturns.length}
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={safePage <= 1}
                  className="px-3 py-1.5 rounded border border-gray-300 text-gray-700 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-gray-100 text-sm"
                >
                  Previous
                </button>
                <span className="text-sm text-gray-700">Page {safePage} / {totalPages}</span>
                <button
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  disabled={safePage >= totalPages}
                  className="px-3 py-1.5 rounded border border-gray-300 text-gray-700 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-gray-100 text-sm"
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Add/Edit Modal */}
        {showModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col">
              <div className="flex items-center justify-between p-3 border-b flex-shrink-0">
                <h3 className="text-base font-semibold">Create New Return</h3>
                <button onClick={() => setShowModal(false)} className="p-1 hover:bg-gray-100 rounded">
                  <X size={18} />
                </button>
              </div>
              <div className="p-3 space-y-2 overflow-y-auto flex-1">
                <div className="grid gap-3 md:grid-cols-2">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Dispense ID *</label>
                    <input
                      type="text"
                      placeholder="e.g., DISP-001"
                      value={newReturn.dispenseId}
                      onChange={(e) => handleDispenseIdChange(e.target.value)}
                      className={`w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none ${
                        formErrors.dispenseId ? "border-red-500" : ""
                      }`}
                    />
                    {formErrors.dispenseId && (
                      <p style={{ color: "#dc2626" }} className="text-xs mt-1">
                        {formErrors.dispenseId}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Batch ID *</label>
                    {loadingBatches && (
                      <p className="text-xs text-gray-500 mb-1">Loading batches...</p>
                    )}
                    {newReturn.dispenseId && !loadingBatches && batchesByDispense.length === 0 && (
                      <p className="text-xs text-gray-600 mb-1">Enter Batch ID manually</p>
                    )}
                    {batchesByDispense.length > 0 && !loadingBatches ? (
                      <select
                        value={newReturn.batchId}
                        onChange={(e) => {
                          setNewReturn({ ...newReturn, batchId: e.target.value });
                          if (formErrors.batchId) setFormErrors({ ...formErrors, batchId: "" });
                        }}
                        className={`w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none ${
                          formErrors.batchId ? "border-red-500" : ""
                        }`}
                      >
                        <option value="">Select a batch...</option>
                        {batchesByDispense.map((batch, idx) => (
                          <option key={idx} value={batch?.batchId || batch?.batch_id || batch}>
                            {batch?.batchId || batch?.batch_id || batch?.label || batch}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <input
                        type="text"
                        placeholder="e.g., BATCH-2024-001"
                        value={newReturn.batchId}
                        onChange={(e) => {
                          setNewReturn({ ...newReturn, batchId: e.target.value });
                          if (formErrors.batchId) setFormErrors({ ...formErrors, batchId: "" });
                        }}
                        disabled={loadingBatches}
                        className={`w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none disabled:bg-gray-100 disabled:cursor-not-allowed ${
                          formErrors.batchId ? "border-red-500" : ""
                        }`}
                      />
                    )}
                    {formErrors.batchId && (
                      <p style={{ color: "#dc2626" }} className="text-xs mt-1">
                        {formErrors.batchId}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Quantity *</label>
                    <input
                      type="number"
                      placeholder="e.g., 10"
                      min="1"
                      value={newReturn.quantity}
                      onChange={(e) => {
                        setNewReturn({ ...newReturn, quantity: e.target.value });
                        if (formErrors.quantity) setFormErrors({ ...formErrors, quantity: "" });
                      }}
                      className={`w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none ${
                        formErrors.quantity ? "border-red-500" : ""
                      }`}
                    />
                    {formErrors.quantity && (
                      <p style={{ color: "#dc2626" }} className="text-xs mt-1">
                        {formErrors.quantity}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Return Reason *</label>
                    <textarea
                      placeholder="e.g., Damaged package, Expired, Wrong item"
                      value={newReturn.reason}
                      onChange={(e) => {
                        setNewReturn({ ...newReturn, reason: e.target.value });
                        if (formErrors.reason) setFormErrors({ ...formErrors, reason: "" });
                      }}
                      className={`w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none ${
                        formErrors.reason ? "border-red-500" : ""
                      }`}
                      rows="2"
                    />
                    {formErrors.reason && (
                      <p style={{ color: "#dc2626" }} className="text-xs mt-1">
                        {formErrors.reason}
                      </p>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-end gap-2 p-3 border-t bg-gray-50 flex-shrink-0">
                <button
                  onClick={handleSave}
                  disabled={submitting}
                  className="px-4 py-2 text-sm bg-[#3C8C85] hover:bg-[#337872] text-white rounded-lg disabled:opacity-50"
                >
                  {submitting ? "Creating..." : "Save"}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Fallback for unknown role
  return (
    <div className="p-8 text-center">
      <h1 className="text-2xl font-bold text-gray-900">Access Denied</h1>
      <p className="text-gray-600 mt-2">Your role does not have access to this page.</p>
    </div>
  );
}

export default StaffReturns;
