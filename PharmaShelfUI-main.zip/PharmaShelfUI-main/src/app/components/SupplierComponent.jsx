import React, { useState, useRef, useMemo } from "react";
import { Search, Plus, MoreVertical, Edit2, Trash2, X, Eye, Download } from "lucide-react";
import { supplierAPI } from "../../services/api";
 
const PAGE_SIZE = 10;
 
export default function SupplierComponent({ allSuppliers, onDataChange, showToast }) {
  const [supplierSearch, setSupplierSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState(null);
  const [viewingSupplier, setViewingSupplier] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const [openActionsMenu, setOpenActionsMenu] = useState(null);
  const actionsMenuRef = useRef(null);
 
  const [form, setForm] = useState({ name: '', contactInfo: '', taxId: '', status: 'ACTIVE' });
 
  const [nameError, setNameError] = useState("");
  const [contactInfoError, setContactInfoError] = useState("");
  const [taxIdError, setTaxIdError] = useState("");
 
  const alphaSpaceRegex = /^[a-zA-Z0-9\s\-/]*$/;
 
  const validateName = (value) => {
    if (!value.trim()) { setNameError("Name is required."); return false; }
    if (!alphaSpaceRegex.test(value)) { setNameError("Cannot enter special characters"); return false; }
    setNameError(""); return true;
  };
  const validateContactInfo = (value) => {
    if (!value.trim()) { setContactInfoError("Contact Info is required."); return false; }
    if (value.includes("@") && !value.includes(".com")) {
      setContactInfoError("Invalid email address"); return false;
    }
    setContactInfoError(""); return true;
  };
  const validateTaxId = (value) => {
    if (value && !/^[a-zA-Z0-9]*$/.test(value)) { setTaxIdError("Cannot enter special characters"); return false; }
    setTaxIdError(""); return true;
  };
 
  const exportToExcel = (data, fileName) => {
    if (!data || data.length === 0) {
      showToast("No data to export", "error");
      return;
    }
    const headers = Object.keys(data[0]);
    let csv = headers.join(",") + "\n";
    data.forEach(row => {
      csv += headers.map(header => {
        let value = row[header];
        if (value === null || value === undefined) value = "";
        if (String(value).includes(",") || String(value).includes('"')) {
          value = '"' + String(value).replace(/"/g, '""') + '"';
        }
        return value;
      }).join(",") + "\n";
    });
    const link = document.createElement("a");
    link.setAttribute("href", "data:text/csv;charset=utf-8," + encodeURIComponent(csv));
    link.setAttribute("download", fileName + ".csv");
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
 
  const filteredSuppliers = useMemo(() =>
    (allSuppliers || []).filter(s => !supplierSearch || (s.name || '').toLowerCase().includes(supplierSearch.toLowerCase())),
    [allSuppliers, supplierSearch]
  );
 
  const totalPages = Math.max(1, Math.ceil(filteredSuppliers.length / PAGE_SIZE));
  const safePage = Math.min(Math.max(1, currentPage), totalPages);
  const start = (safePage - 1) * PAGE_SIZE;
  const paginatedSuppliers = filteredSuppliers.slice(start, start + PAGE_SIZE);
 
  function openAdd() {
    setEditingSupplier(null);
    setForm({ name: '', contactInfo: '', taxId: '', status: 'ACTIVE' });
    setShowModal(true);
  }
 
  function openEdit(s) {
    setEditingSupplier(s);
    setForm({ name: s.name || '', contactInfo: s.contactInfo || '', taxId: s.taxId || '', status: s.status || 'ACTIVE' });
    setShowModal(true);
  }
 
  function handleExport() {
    const exportData = filteredSuppliers.map(s => ({
      "Supplier Name": s.name || "",
      "Contact Info": s.contactInfo || "",
      "Tax ID": s.taxId || "",
      "Status": s.status || "",
    }));
    exportToExcel(exportData, "suppliers_" + new Date().toISOString().split('T')[0]);
    showToast("Suppliers exported successfully!", "success");
  }
 
  async function handleSave() {
    const isNameValid = validateName(form.name);
    const isContactValid = validateContactInfo(form.contactInfo);
    if (!isNameValid || !isContactValid) return;
    setSaving(true);
    try {
      const payload = { name: form.name.trim(), contactInfo: form.contactInfo.trim(), taxId: form.taxId.trim(), status: form.status };
      if (editingSupplier) {
        await supplierAPI.update(editingSupplier.supplierId, payload);
        showToast("Supplier updated successfully!", "success");
      } else {
        await supplierAPI.create(payload);
        showToast("Supplier added successfully!", "success");
      }
      setShowModal(false);
      onDataChange();
    } catch (e) {
      showToast(`Save failed: ${e.message}`, "error");
    } finally {
      setSaving(false);
    }
  }
 
  async function handleDelete(s) {
    if (!window.confirm(`Delete supplier "${s.name}"?`)) return;
    setDeleting(s.supplierId);
    try {
      await supplierAPI.delete(s.supplierId);
      showToast("Supplier deleted successfully!", "success");
      onDataChange();
    } catch (e) {
      showToast(`Delete failed: ${e.message}`, "error");
    } finally {
      setDeleting(null);
    }
  }
  return (
    <div className="bg-white border rounded-xl overflow-hidden">
      <div className="p-4 border-b flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <h2 className="font-semibold text-gray-900">Supplier Records</h2>
        <div className="flex items-center gap-2">
          <div className="relative w-64">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
            <input
              className="w-full pl-8 pr-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-400"
              placeholder="Search suppliers..."
              value={supplierSearch}
              onChange={e => setSupplierSearch(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={openAdd}
              className="flex items-center justify-center w-8 h-8 bg-[#3C8C85] hover:bg-[#337872] text-white rounded-md text-xs font-medium"
              title="Add Supplier"
              aria-label="Add Supplier"
            >
              <Plus size={16} />
            </button>
            <button
              onClick={handleExport}
              className="px-3 py-1.5 bg-[#3C8C85] hover:bg-[#337872] text-white rounded-md text-xs font-medium"
            >
              Export
            </button>
          </div>
        </div>
      </div>
     
      {paginatedSuppliers.length === 0 && (
        <p className="p-8 text-sm text-center text-gray-400">
          No suppliers found. <button onClick={openAdd} className="text-blue-600 underline">Add one now</button>
        </p>
      )}
     
      {paginatedSuppliers.length > 0 && (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead style={{ background: '#3C8C85' }} className="text-xs tracking-wider">
              <tr>
                <th className="px-4 py-3 text-center font-semibold" style={{ color: '#fff' }}>Name</th>
                <th className="px-4 py-3 text-center font-semibold" style={{ color: '#fff' }}>Contact Info</th>
                <th className="px-4 py-3 text-center font-semibold" style={{ color: '#fff' }}>Tax ID</th>
                <th className="px-4 py-3 text-center font-semibold" style={{ color: '#fff' }}>Status</th>
                <th className="px-4 py-3 text-center font-semibold" style={{ color: '#fff' }}>Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {paginatedSuppliers.map(s => (
                <tr key={s.supplierId} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 text-center font-medium text-gray-900">{s.name}</td>
                  <td className="px-4 py-3 text-center text-gray-600">{s.contactInfo}</td>
                  <td className="px-4 py-3 text-center text-gray-600 font-mono text-xs">{s.taxId}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${s.status === "ACTIVE" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"}`}>{s.status}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="relative inline-block">
                      <button
                        onClick={() => setOpenActionsMenu(prev => prev === `sup-${s.supplierId}` ? null : `sup-${s.supplierId}`)}
                        className="p-1.5 rounded hover:bg-gray-100 text-gray-600 hover:text-gray-800"
                      >
                        <MoreVertical size={16} />
                      </button>
                      {openActionsMenu === `sup-${s.supplierId}` && (
                        <div ref={actionsMenuRef} className="absolute right-0 bottom-full mb-1 z-20 min-w-[120px] bg-white border border-gray-200 rounded-lg shadow-lg overflow-hidden">
                          <button
                            onClick={() => { openEdit(s); setOpenActionsMenu(null); }}
                            className="w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-blue-50 inline-flex items-center gap-2"
                          >
                            <Edit2 size={13} className="text-blue-600" /> Edit
                          </button>
                          <button
                            onClick={() => { handleDelete(s); setOpenActionsMenu(null); }}
                            disabled={deleting === s.supplierId}
                            className={`w-full px-3 py-2 text-left text-sm inline-flex items-center gap-2 ${deleting === s.supplierId ? "text-gray-400 cursor-not-allowed" : "text-red-600 hover:bg-red-50"}`}
                          >
                            <Trash2 size={13} /> Delete
                          </button>
                        </div>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
 
      <div className="px-4 py-3 border-t border-gray-200 flex items-center justify-end gap-3 bg-gray-50">
        <button
          onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
          disabled={safePage <= 1}
          className="px-3 py-1.5 rounded border border-gray-300 text-gray-700 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-gray-100 text-sm"
        >
          Prev
        </button>
        <span className="text-sm text-gray-700">Page {safePage} / {totalPages}</span>
        <button
          onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
          disabled={safePage >= totalPages}
          className="px-3 py-1.5 rounded border border-gray-300 text-gray-700 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-gray-100 text-sm"
        >
          Next
        </button>
      </div>
 
      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="text-lg font-semibold">{editingSupplier ? 'Edit Supplier' : 'Add Supplier'}</h3>
              <button onClick={() => setShowModal(false)} className="p-1 hover:bg-gray-100 rounded"><X size={20} /></button>
            </div>
            <div className="p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name *</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={e => { const v = e.target.value; setForm(prev => ({ ...prev, name: v })); validateName(v); }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-400 focus:outline-none"
                  placeholder="Supplier name"
                />
                {nameError && <p className="text-xs mt-1" style={{color:'#dc2626'}}>{nameError}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Contact Info *</label>
                <input
                  type="text"
                  value={form.contactInfo}
                  onChange={e => { const v = e.target.value; setForm(prev => ({ ...prev, contactInfo: v })); validateContactInfo(v); }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-400 focus:outline-none"
                  placeholder="Phone or email"
                />
                {contactInfoError && <p className="text-xs mt-1" style={{color:'#dc2626'}}>{contactInfoError}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tax ID *</label>
                <input
                  type="text"
                  value={form.taxId}
                  onChange={e => { const v = e.target.value; setForm(prev => ({ ...prev, taxId: v })); validateTaxId(v); }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-400 focus:outline-none"
                  placeholder="Tax identification number"
                />
                {taxIdError && <p className="text-xs mt-1" style={{color:'#dc2626'}}>{taxIdError}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <select
                  value={form.status}
                  onChange={e => setForm(prev => ({ ...prev, status: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-400 focus:outline-none"
                >
                  <option value="ACTIVE">Active</option>
                  <option value="INACTIVE">Inactive</option>
                </select>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 p-4 border-t bg-gray-50">
              <button onClick={() => { setForm({ name: '', contactInfo: '', taxId: '', status: 'ACTIVE' }); setNameError(''); setContactInfoError(''); setTaxIdError(''); }} className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100">Reset</button>
              <button onClick={handleSave} disabled={saving} className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg disabled:opacity-50">
                {saving ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}
 
      {/* View Modal */}
      {viewingSupplier && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="text-lg font-semibold">View Supplier</h3>
              <button onClick={() => setViewingSupplier(null)} className="p-1 hover:bg-gray-100 rounded"><X size={20} /></button>
            </div>
            <div className="p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Supplier ID</label>
                <div className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-700">{viewingSupplier.supplierId}</div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <div className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-700">{viewingSupplier.name}</div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Contact Info</label>
                <div className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-700">{viewingSupplier.contactInfo || '—'}</div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tax ID</label>
                <div className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-700">{viewingSupplier.taxId || '—'}</div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <div className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${viewingSupplier.status === 'ACTIVE' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>
                    {viewingSupplier.status}
                  </span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 p-4 border-t bg-gray-50">
              <button
                onClick={() => {
                  openEdit(viewingSupplier);
                  setViewingSupplier(null);
                }}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
              >
                <Edit2 size={16} /> Edit
              </button>
              <button
                onClick={() => {
                  const dataStr = JSON.stringify(viewingSupplier, null, 2);
                  const dataBlob = new Blob([dataStr], { type: 'application/json' });
                  const url = URL.createObjectURL(dataBlob);
                  const link = document.createElement('a');
                  link.href = url;
                  link.download = `supplier-${viewingSupplier.supplierId}.json`;
                  link.click();
                  URL.revokeObjectURL(url);
                }}
                className="flex items-center gap-2 px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg"
              >
                <Download size={16} /> Download
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}