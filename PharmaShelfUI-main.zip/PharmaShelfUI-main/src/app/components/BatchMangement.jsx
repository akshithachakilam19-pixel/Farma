import { useCallback, useEffect, useMemo, useState, useRef } from "react";
import {
  RefreshCw, AlertCircle, Timer, CheckCircle2,
  ShieldAlert, Package, Camera, MoreVertical,
} from "lucide-react";
import { toast } from "sonner";
import { batchesService } from "../../services/batchesService";
import { quarantineService } from "../../services/quarantineService";
import { recallService } from "../../services/recallService";
 
// ── helpers ──────────────────────────────────────────────────────────────────
const toArray = (v) => {
  if (!v) return [];
  if (Array.isArray(v)) return v;
  if (Array.isArray(v?.data)) return v.data;
  if (Array.isArray(v?.content)) return v.content;
  if (v && typeof v === "object") { const a = Object.values(v).find(Array.isArray); if (a) return a; }
  return [];
};
const norm = (b) => ({
  ...b,
  batchId: b.batchId || b.BatchID || b.id || "-",
  expiryDate: b.expiryDate || b.expiry || null,
  quantity: b.quantityAvailable ?? b.quantity ?? 0,
  status: String(b.status || "ACTIVE").toUpperCase(),
});
const fmtDate = (v) => {
  if (!v) return "-";
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? v : d.toLocaleDateString("en-IN", { year: "numeric", month: "short", day: "2-digit" });
};
const fmtDateTime = (v) => {
  if (!v) return "-";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return v;
  return d.toLocaleDateString("en-IN", { year: "numeric", month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" });
};
const daysTo = (exp) => {
  if (!exp) return null;
  const t = new Date(); t.setHours(0,0,0,0);
  const e = new Date(exp); e.setHours(0,0,0,0);
  return Math.ceil((e - t) / 864e5);
};
const user = () => {
  try { const u = JSON.parse(localStorage.getItem("pharmaShelfUser")||"{}"); return u?.name||u?.username||u?.email||"Pharmacist"; } catch { return "Pharmacist"; }
};
 
// ── component ────────────────────────────────────────────────────────────────
export function BatchManagement() {
  const [batches, setBatches]       = useState([]);
  const [quarantines, setQ]         = useState([]);
  const [recalls, setR]             = useState([]);
  const [loading, setLoading]       = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [pid, setPid]               = useState(null);
  const [tab, setTab]               = useState("expired");
 
  // modals
  const [qModal, setQModal] = useState({ open: false, batch: null });
  const [qReason, setQReason] = useState("");
  const [evModal, setEvModal] = useState({ open: false, recall: null });
  const [evFile, setEvFile] = useState(null);
  const [evPreview, setEvPreview] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [imageViewer, setImageViewer] = useState({ open: false, src: null });
  const [openActionsMenu, setOpenActionsMenu] = useState(null);
  const actionsMenuRef = useRef(null);
 
  const load = useCallback(async (silent) => {
    silent ? setRefreshing(true) : setLoading(true);
    try {
      const [b, q, r] = await Promise.all([
        batchesService.getAll().catch(() => []),
        quarantineService.getAll().catch(() => []),
        recallService.getAll().catch(() => []),
      ]);
      setBatches(toArray(b).map(norm));
      setQ(toArray(q));
      setR(toArray(r));
    } catch (e) { toast.error(e?.message || "Load failed"); }
    finally { setLoading(false); setRefreshing(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  // Auto-refresh recalls every 30 seconds to pick up new recalls from RecallManagement
  useEffect(() => {
    const interval = setInterval(() => {
      load(true); // silent refresh
    }, 30000); // 30 seconds
    return () => clearInterval(interval);
  }, [load]);
 
  const { expired, near } = useMemo(() => {
    const ex = [], nr = [];
    // Show all batches regardless of status (expired/near expiry items might be in any state)
    batches.forEach(b => {
      const d = daysTo(b.expiryDate);
      if (d !== null) { if (d <= 0) ex.push({ ...b, days: d }); else if (d <= 30) nr.push({ ...b, days: d }); }
    });
    ex.sort((a,b) => a.days - b.days);
    nr.sort((a,b) => a.days - b.days);
    return { expired: ex, near: nr };
  }, [batches]);
 
  const activeRecalls = recalls.filter(r => {
    const s = String(r.status||r.Status||"").toUpperCase();
    return s === "ISSUED" || s === "IN_PROGRESS" || s === "ACTIVE" || s === "OPEN";
  });
 
  const activeQuarantines = quarantines.filter(q => {
    const s = String(q.status || q.Status || "").toUpperCase();
    return s === "QUARANTINED";
  });
 
  // quarantine
 const confirmQ = async () => {
  const b = qModal.batch;
  if (!b) return;

  if (!qReason || qReason.trim().length < 3) {
    toast.error("Enter reason (min 3 chars)");
    return;
  }

  const batchId = b.batchId || b.id;
  if (!batchId || batchId === "-") {
    toast.error("Invalid batch ID");
    return;
  }

  setPid(batchId);

  try {
    await quarantineService.quarantineBatch(
      batchId,
      qReason.trim()
    );

    toast.success(`Batch ${batchId} sent to quarantine — pending review`);
    setQReason("");
    setQModal({ open: false, batch: null });
    await load(true);

  } catch (e) {
    toast.error(e?.message || "Failed to quarantine batch");
  } finally {
    setPid(null);
  }
};

 
  // evidence upload with validation and preview
  const handleEvFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // File size check first (before type check for better UX) - 3MB limit
    if (file.size > 3 * 1024 * 1024) {
      const sizeMB = (file.size / (1024 * 1024)).toFixed(2);
      toast.error(`File size (${sizeMB}MB) exceeds 3MB limit. Please compress and try again.`);
      return;
    }
    
    // JPG validation
    if (!file.type.match(/image\/(jpeg|jpg)/)) {
      toast.error("Only JPG/JPEG files are allowed");
      return;
    }
    
    setEvFile(file);
    
    // Generate preview
    const reader = new FileReader();
    reader.onload = (e) => setEvPreview(e.target.result);
    reader.readAsDataURL(file);
    
    toast.success(`File selected: ${file.name}`);
  };
  
  const submitEv = async () => {
    const rc = evModal.recall; if (!rc || !evFile) { toast.error("Select a JPG image (max 3MB)"); return; }
    setUploading(true);
    try {
      const uri = evPreview || await new Promise((ok,fail) => { const r = new FileReader(); r.onload=()=>ok(r.result); r.onerror=fail; r.readAsDataURL(evFile); });
      await recallService.update(rc.recallId||rc.id, {
        ...rc,
        EvidenceURI: uri,
        evidenceURI: uri,
        Status: "EVIDENCE_UPLOADED",
        status: "EVIDENCE_UPLOADED",
      });
      const sizeMB = (evFile.size / (1024 * 1024)).toFixed(2);
      toast.success(`✓ Evidence uploaded successfully (${sizeMB}MB) — Compliance notified`); 
      setEvModal({ open:false, recall:null }); 
      setEvPreview(null); 
      setEvFile(null); 
      await load(true);
    } catch (e) { toast.error(e?.message||"Upload failed"); } finally { setUploading(false); }
  };
 
  // ── render ─────────────────────────────────────────────────────────────────
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Inventory Safety Actions</h1>
          <p className="text-gray-600 mt-1">Pharmacist — Expiry alerts, quarantine and recall evidence</p>
        </div>
        <button onClick={() => load(true)} disabled={refreshing}
          className="flex items-center gap-2 px-4 py-2 bg-[#3C8C85] text-white rounded-lg hover:bg-[#2E6F6A] transition-colors">
          <RefreshCw className={`size-4 ${refreshing ? "animate-spin" : ""}`} /> Refresh
        </button>
      </div>
 
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {[
          { label: "Expired Batches", value: expired.length, icon: AlertCircle, bg: "bg-red-500" },
          { label: "In Quarantine",   value: activeQuarantines.length, icon: Package, bg: "bg-[#3C8C85]" },
        ].map(c => (
          <div key={c.label} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">{c.label}</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">{c.value}</p>
              </div>
              <div className={`${c.bg} p-3 rounded-lg`}><c.icon className="size-6 text-white" /></div>
            </div>
          </div>
        ))}
      </div>
 
      {/* Tabs — full width like StockCounts */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="border-b border-gray-200">
          <div className="flex">
            {[
              { key: "expired",       label: "Expired Batches" },
              { key: "quarantine",    label: "Quarantine Management" },
            ].map(t => (
              <button key={t.key} onClick={() => setTab(t.key)}
                className={`flex-1 px-6 py-4 text-sm font-semibold transition-colors ${
                  tab === t.key ? "text-[#3C8C85] border-b-2 border-[#3C8C85] bg-[#f0fffe]" : "text-gray-600 hover:bg-gray-50"
                }`}>
                {t.label}
              </button>
            ))}
          </div>
        </div>
 
        <div className="overflow-x-auto">
          {/* ── TAB 1: Expired ── */}
          {tab === "expired" && (
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Batch ID</th>

                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Expiry Date</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Days Overdue</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Qty</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {loading ? (
                  <tr><td colSpan={6} className="px-6 py-12 text-center text-gray-500"><RefreshCw className="size-5 animate-spin inline mr-2" />Loading...</td></tr>
                ) : expired.length === 0 ? (
                  <tr><td colSpan={6} className="px-6 py-12 text-center"><CheckCircle2 className="size-10 text-[#3C8C85] mx-auto mb-2" /><p className="text-[#3C8C85] font-semibold">No expired batches!</p></td></tr>
                ) : expired.map(b => (
                  <tr key={b.batchId} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 font-mono text-sm text-gray-900">{b.batchId}</td>

                    <td className="px-6 py-4 text-sm text-gray-900">{fmtDate(b.expiryDate)}</td>
                    <td className="px-6 py-4"><span className="inline-block px-3 py-1 bg-red-100 text-red-700 rounded-full text-xs font-semibold">{Math.abs(b.days)} days</span></td>
                    <td className="px-6 py-4 text-sm text-gray-900">{b.quantity}</td>
                    <td className="px-6 py-4">
                      <button
                        onClick={(event) => {
                          const batchId = b.batchId || b.id;
                          const rect = event.currentTarget.getBoundingClientRect();
                          setOpenActionsMenu(prev => prev?.id === batchId ? null : {
                            id: batchId,
                            top: rect.bottom + 4,
                            right: window.innerWidth - rect.right,
                          });
                        }}
                        className="p-1.5 rounded hover:bg-gray-100 text-gray-600 hover:text-gray-800 transition-colors"
                      >
                        <MoreVertical size={16} />
                      </button>
                      {openActionsMenu?.id === (b.batchId || b.id) && (
                        <div
                          ref={actionsMenuRef}
                          className="w-40 bg-white border border-gray-200 rounded-lg shadow-lg overflow-hidden"
                          style={{
                            position: 'fixed',
                            zIndex: 9999,
                            right: openActionsMenu.right,
                            top: openActionsMenu.top,
                          }}
                        >
                          <button
                            onClick={() => {
                              setQModal({ open:true, batch:b });
                              setQReason("Expired batch moved to quarantine");
                              setOpenActionsMenu(null);
                            }}
                            disabled={pid === b.batchId}
                            className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-[#f0fffe] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 font-medium whitespace-nowrap"
                          >
                            {pid === b.batchId ? "Processing..." : "Move to Quarantine"}
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
 
          {/* ── TAB 2: Quarantine Management ── */}
          {tab === "quarantine" && (
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Batch ID</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Reason</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Quarantined By</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Quarantined At</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {loading ? (
                  <tr><td colSpan={6} className="px-6 py-12 text-center text-gray-500"><RefreshCw className="size-5 animate-spin inline mr-2" />Loading...</td></tr>
                ) : activeQuarantines.length === 0 ? (
                  <tr><td colSpan={6} className="px-6 py-12 text-center"><CheckCircle2 className="size-10 text-[#3C8C85] mx-auto mb-2" /><p className="text-[#3C8C85] font-semibold">No quarantined batches!</p></td></tr>
                ) : activeQuarantines.map(q => (
                  <tr key={q.quarantineId || q.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 font-mono text-sm text-gray-900">{q.batchId || q.BatchID || "-"}</td>
                    <td className="px-6 py-4 text-sm text-gray-700">{q.reason || q.Reason || "-"}</td>
                    <td className="px-6 py-4 text-sm text-gray-700">{q.quarantinedBy || q.QuarantinedBy || "-"}</td>
                    <td className="px-6 py-4 text-sm text-gray-700">{fmtDateTime(q.quarantinedAt || q.QuarantinedAt)}</td>
                    <td className="px-6 py-4">
                      <span className="inline-block px-3 py-1 bg-orange-100 text-orange-700 rounded-full text-xs font-semibold">
                        {q.status || q.Status || "QUARANTINED"}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button
                        onClick={async () => {
                          const qId = q.quarantineId || q.id;
                          if (!qId) {
                            toast.error("Quarantine ID not found");
                            return;
                          }
                          try {
                            setPid(qId);
                            await quarantineService.releaseToStock(qId);
                            toast.success(`Batch ${q.batchId} released to stock successfully`);
                            await load(true);
                          } catch (e) {
                            toast.error(e?.message || "Failed to release quarantine");
                          } finally {
                            setPid(null);
                          }
                        }}
                        disabled={pid === (q.quarantineId || q.id)}
                        className="px-3 py-1.5 bg-green-600 text-white rounded text-xs hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-medium"
                      >
                        {pid === (q.quarantineId || q.id) ? "Releasing..." : "Release"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
 
        </div>
      </div>
 
      {/* ── Quarantine Reason Modal ── */}
      {qModal.open && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full">
            <div className="px-6 py-4 border-b bg-[#3C8C85] text-white rounded-t-xl flex items-center justify-between">
              <h3 className="font-semibold text-lg">Move to Quarantine</h3>
              <button onClick={() => setQModal({ open:false, batch:null })} className="text-white/80 hover:text-white text-xl">&times;</button>
            </div>
            <div className="p-6 space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-500">Batch ID</p>
                <p className="font-mono font-bold text-gray-900">{qModal.batch?.batchId}</p>
              </div>
             
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Reason for Quarantine *</label>
                <textarea value={qReason} onChange={e => setQReason(e.target.value)} rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:border-[#3C8C85]"
                  placeholder="Enter reason (min 3 chars)..." />
              </div>
              <div className="flex gap-3 pt-2">
                <button onClick={() => setQModal({ open:false, batch:null })} className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">Cancel</button>
                <button onClick={confirmQ} disabled={!!pid} className="flex-1 px-4 py-2 bg-[#3C8C85] text-white rounded-lg hover:bg-[#2E6F6A] disabled:opacity-50">
                  {pid ? "Processing..." : "Confirm Quarantine"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
 
      {/* ── Evidence Upload Modal ── */}
      {evModal.open && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full my-4 max-h-[90vh] overflow-y-auto flex flex-col">
            <div className="px-6 py-4 border-b bg-[#3C8C85] text-white rounded-t-xl flex items-center justify-between flex-shrink-0">
              <h3 className="font-semibold text-lg flex items-center gap-2"><Camera className="size-5" /> Upload Recall Evidence</h3>
              <button onClick={() => setEvModal({ open:false, recall:null })} className="text-white/80 hover:text-white text-xl">&times;</button>
            </div>
            <div className="p-6 space-y-4 overflow-y-auto flex-1" style={{scrollbarWidth: 'none', msOverflowStyle: 'none'}}>
              <div className="bg-gray-50 p-4 rounded-lg flex-shrink-0">
                <p className="text-sm text-gray-500">Recall for batch</p>
                <p className="font-mono font-bold text-gray-900">{evModal.recall?.batchId||evModal.recall?.BatchID}</p>
              </div>
              <div className="flex-shrink-0">
                <label className="block text-sm font-medium text-gray-700 mb-2">Evidence Photo (JPG only, max 3MB)</label>
                <p className="text-xs text-gray-500 mb-3">Tip: Compress your JPG to ~2-3MB for best results</p>
                <input type="file" accept=".jpg,.jpeg,image/jpeg" onChange={handleEvFileChange} className="w-full text-sm" />
              </div>
              {evPreview && (
                <div className="border-2 border-[#3C8C85] rounded-lg overflow-hidden">
                  <img src={evPreview} alt="Preview" className="w-full h-auto max-h-48 object-cover" />
                  <p className="text-xs text-gray-500 p-2 bg-gray-50 text-center">{evFile?.name}</p>
                </div>
              )}
            </div>
            <div className="flex gap-3 pt-2 p-6 border-t bg-gray-50 flex-shrink-0">
              <button onClick={() => { setEvModal({ open:false, recall:null }); setEvPreview(null); }} className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">Cancel</button>
              <button onClick={submitEv} disabled={uploading || !evFile} className="flex-1 px-4 py-2 bg-[#3C8C85] text-white rounded-lg hover:bg-[#2E6F6A] disabled:opacity-50">
                {uploading ? "Uploading..." : "Upload"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Image Viewer Modal */}
      {imageViewer.open && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full">
            <div className="px-6 py-4 border-b bg-[#3C8C85] text-white rounded-t-xl flex items-center justify-between">
              <h3 className="font-semibold text-lg">Evidence Photo</h3>
              <button onClick={() => setImageViewer({ open: false, src: null })} className="text-white/80 hover:text-white text-xl">&times;</button>
            </div>
            <div className="p-6">
              <img src={imageViewer.src} alt="Evidence" className="w-full h-auto max-h-96 object-contain rounded-lg" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}