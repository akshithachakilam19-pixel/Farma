import { useEffect, useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { consumptionLogAPI } from "../../services/api";

export function ConsumptionLog() {
  const navigate = useNavigate();
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Fetch consumption logs on component mount
  useEffect(() => {
    fetchLogs();
  }, []);

  const fetchLogs = async () => {
    try {
      setLoading(true);
      setError("");
      const response = await consumptionLogAPI.getAll();
      const data = Array.isArray(response) ? response : response?.data || [];
      setLogs(data);
    } catch (err) {
      console.error("Failed to fetch consumption logs:", err);
      setError(err?.message || "Failed to load consumption logs");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Consumption Logs</CardTitle>
          <CardDescription>
            Auto-generated consumption records from dispensing transactions. Read-only view.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}

          {loading ? (
            <div className="text-center py-8 text-gray-500">Loading consumption logs...</div>
          ) : logs.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No consumption logs available. Logs are auto-generated from dispensing transactions.
            </div>
          ) : (
            <div className="w-full overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow style={{ backgroundColor: '#3C8C85' }}>
                    <TableHead className="font-semibold" style={{ color: '#fff' }}>Log ID</TableHead>
                    <TableHead className="font-semibold" style={{ color: '#fff' }}>Product ID</TableHead>
                    <TableHead className="font-semibold" style={{ color: '#fff' }}>Period Start</TableHead>
                    <TableHead className="font-semibold" style={{ color: '#fff' }}>Period End</TableHead>
                    <TableHead className="font-semibold text-right" style={{ color: '#fff' }}>Quantity Used</TableHead>
                    <TableHead className="font-semibold" style={{ color: '#fff' }}>Generated At</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {logs.map((log, idx) => (
                    <TableRow key={log?.logId || log?.id || idx} className="border-b border-gray-200">
                      <TableCell className="font-medium text-sm">
                        {log?.logId || log?.id || "-"}
                      </TableCell>
                      <TableCell className="text-sm">
                        {log?.productId || log?.product || "-"}
                      </TableCell>
                      <TableCell className="text-sm">
                        {log?.periodStart
                          ? new Date(log.periodStart).toLocaleDateString()
                          : "-"}
                      </TableCell>
                      <TableCell className="text-sm">
                        {log?.periodEnd
                          ? new Date(log.periodEnd).toLocaleDateString()
                          : "-"}
                      </TableCell>
                      <TableCell className="text-sm text-right font-medium">
                        {log?.quantityUsed !== undefined ? log.quantityUsed : "-"}
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">
                        {log?.generatedAt
                          ? new Date(log.generatedAt).toLocaleString()
                          : "-"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
