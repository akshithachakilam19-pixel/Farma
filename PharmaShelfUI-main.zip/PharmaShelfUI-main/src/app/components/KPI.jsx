import React, { useCallback, useEffect, useMemo, useState, useRef } from "react";
import { toast } from "sonner";
import {
  RefreshCw, Trash2, Eye, Play, ChevronLeft, ChevronRight,
  AlertTriangle, TrendingDown, Activity, Target, Lock,
  MoreVertical, X, Check, BarChart3, PieChart as PieChartIcon
} from "lucide-react";
import {
  BarChart, Bar, PieChart, Pie, Cell,
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  AreaChart, Area, Tooltip, Legend, ResponsiveContainer,
} from "recharts";
import { kpiService } from "../../services/kpiService";
import { batchesService } from "../../services/batchesService";
import { dispensingService } from "../../services/dispensingService";
import { returnService } from "../../services/returnService";
import { recallService } from "../../services/recallService";
 
const KPI_DEFINITIONS = [
  {
    id: "EXPIRY_RISK",
    name: "Expiry Risk",
    description: "Calculates the percentage of inventory at risk of expiring or spoiling before use.",
    icon: AlertTriangle,
    bgColor: "bg-red-50",
    iconColor: "text-red-600",
    target: 5,
  },
  {
    id: "CONSUMPTION",
    name: "Consumption",
    description: "Tracks overall consumption efficiency of medication and supplies across wards.",
    icon: Activity,
    bgColor: "bg-blue-50",
    iconColor: "text-blue-600",
    target: 90,
  },
  {
    id: "RECALL",
    name: "Recall",
    description: "Monitors recall completion rates and affected batch quarantines.",
    icon: TrendingDown,
    bgColor: "bg-orange-50",
    iconColor: "text-orange-600",
    target: 2,
  },
];
 
const PERIOD_OPTIONS = [
  { value: "daily", label: "Daily" },
  { value: "weekly", label: "Weekly" },
  { value: "monthly", label: "Monthly" },
];
 
const toArray = (value) => {
  if (!value) return [];
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.data)) return value.data;
  if (Array.isArray(value?.content)) return value.content;
  if (value && typeof value === "object") {
    const arr = Object.values(value).find(Array.isArray);
    if (arr) return arr;
  }
  return [];
};
 
const normalizeKpi = (item) => {
  if (!item || typeof item !== "object") return null;
  return {
    id: item.id || item.kpiId || item.KPIId || item._id || null,
    kpiName: item.kpiName || item.kpiId || item.name || item.KPIName || item.KPI || null,
    period: item.period || item.reportingPeriod || item.periodType || "monthly",
    target: item.target ?? item.Target ?? null,
    currentValue: item.currentValue ?? item.currentValue ?? item.CurrentValue ?? item.value ?? 0,
    computedAt: item.computedAt || item.createdAt || item.updatedAt || new Date().toISOString(),
    status: item.status || item.Status || null,
    raw: item,
  };
};
 
const getTargetValue = (id) => {
  const def = KPI_DEFINITIONS.find((d) => d.id === id);
  return def ? def.target : 0;
};
 
const round = (value) => {
  const num = Number(value);
  return Number.isFinite(num) ? Math.round(num * 100) / 100 : 0;
};
 
function KPI() {
  const [kpis, setKpis] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedKpiId, setSelectedKpiId] = useState(KPI_DEFINITIONS[0].id);
  const [selectedPeriod, setSelectedPeriod] = useState("monthly");
  const [previewTarget, setPreviewTarget] = useState(5);
  const [isComputing, setIsComputing] = useState(false);
  const [deletingId, setDeletingId] = useState(null);
  const [viewKpi, setViewKpi] = useState(null);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);
  const [activeMenuId, setActiveMenuId] = useState(null);
  const [deleteConfirmTarget, setDeleteConfirmTarget] = useState(null);
  const [liveKpiValues, setLiveKpiValues] = useState({
    EXPIRY_RISK: 0,
    CONSUMPTION: 0,
    RECALL: 0,
  });
  const [isLoadingLiveValues, setIsLoadingLiveValues] = useState(true);
 
  const menuRef = useRef(null);
 
  useEffect(() => {
    function handleClickOutside(event) {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setActiveMenuId(null);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);
 
  const FIXED_TARGETS = {
    EXPIRY_RISK: 5,
    CONSUMPTION: 90,
    RECALL: 2,
  };
 
  const selectedDef = useMemo(() => {
    return KPI_DEFINITIONS.find((d) => d.id === selectedKpiId) || KPI_DEFINITIONS[0];
  }, [selectedKpiId]);
 
  const loadKpis = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await kpiService.getAll();
      const records = toArray(result).map(normalizeKpi).filter(Boolean);
      setKpis(records);
      setCurrentPage(1);
    } catch (error) {
      console.error("Failed to load KPI records", error);
      toast.error("Unable to load KPI records from backend.");
    } finally {
      setIsLoading(false);
    }
  }, []);
 
  const loadLiveKpiValues = useCallback(async () => {
    console.log("[KPI] Loading live KPI values from services...");
    setIsLoadingLiveValues(true);
    try {
      // Note: buildKpiValue is called here but we don't add it as dependency
      // to avoid infinite loops since buildKpiValue is redefined on each render
      const expiryValue = await buildKpiValue("EXPIRY_RISK", "monthly");
      const consumptionValue = await buildKpiValue("CONSUMPTION", "monthly");
      const recallValue = await buildKpiValue("RECALL", "monthly");
     
      setLiveKpiValues({
        EXPIRY_RISK: expiryValue,
        CONSUMPTION: consumptionValue,
        RECALL: recallValue,
      });
      console.log("[KPI] Live values loaded:", { expiryValue, consumptionValue, recallValue });
    } catch (error) {
      console.error("[KPI] Error loading live values:", error);
    } finally {
      setIsLoadingLiveValues(false);
    }
  }, []);
 
  useEffect(() => {
    const target = KPI_DEFINITIONS.find((d) => d.id === selectedKpiId)?.target || 5;
    setPreviewTarget(target);
  }, [selectedKpiId]);
 
  useEffect(() => {
    loadKpis();
    loadLiveKpiValues();
  }, []);
 
  const buildKpiValue = async (kpiId, period) => {
    const target = getTargetValue(kpiId);
    const mode = kpiId || selectedKpiId;
   
    try {
      if (mode === "EXPIRY_RISK") {
        console.log("[KPI] Computing EXPIRY_RISK...");
        try {
          const batchData = await batchesService.getAll();
          console.log("[KPI] Batches API response:", batchData);
          const batches = toArray(batchData);
          console.log("[KPI] Batches array:", batches, "Length:", batches.length);
         
          if (!batches || batches.length === 0) {
            console.warn("[KPI] No batches found - returning 0");
            return 0;
          }
         
          const now = new Date();
          const soon = batches.filter((item) => {
            const expiryStr = item.expiryDate || item.expiry || item.ExpiryDate || item.Expiry;
            if (!expiryStr) return false;
            const expiry = new Date(expiryStr);
            if (Number.isNaN(expiry.getTime())) return false;
            const diffDays = Math.ceil((expiry - now) / 864e5);
            return diffDays >= 0 && diffDays <= 30;
          });
          console.log("[KPI] Batches expiring in 30 days:", soon.length, "Total batches:", batches.length);
          const active = batches.length || 1;
          const value = round((soon.length / active) * 100);
          console.log("[KPI] EXPIRY_RISK value:", value);
          return value;
        } catch (batchError) {
          console.error("[KPI] Error fetching batches:", batchError?.message || batchError);
          console.log("[KPI] Batches service failed - returning 0");
          return 0;
        }
      }
 
      if (mode === "CONSUMPTION") {
        console.log("[KPI] Computing CONSUMPTION...");
        try {
          let dispenses = [];
          let returns = [];
         
          try {
            const dispensingData = await dispensingService.getAll();
            console.log("[KPI] Dispensing API response:", dispensingData);
            dispenses = toArray(dispensingData);
            console.log("[KPI] Dispenses array length:", dispenses.length);
          } catch (dispenseError) {
            console.error("[KPI] Error fetching dispensing:", dispenseError?.message || dispenseError);
          }
         
          try {
            const returnData = await returnService.getAll();
            console.log("[KPI] Returns API response:", returnData);
            returns = toArray(returnData).filter(Boolean);
            console.log("[KPI] Returns array length:", returns.length);
          } catch (returnError) {
            console.error("[KPI] Error fetching returns:", returnError?.message || returnError);
          }
         
          const totalDispensed = dispenses.reduce((sum, item) => sum + Number(item.quantity || item.quantityDispensed || item.Quantity || 0), 0);
          const totalReturned = returns.reduce((sum, item) => sum + Number(item.quantity || item.quantityReturned || item.Quantity || 0), 0);
          console.log("[KPI] Total dispensed:", totalDispensed, "Total returned:", totalReturned);
         
          if (totalDispensed === 0 && totalReturned === 0) {
            console.warn("[KPI] No dispensing or return data found - returning 0");
            return 0;
          }
         
          const ratio = totalDispensed === 0 ? target : Math.max(0, Math.min(100, (totalDispensed - totalReturned) / Math.max(1, totalDispensed) * 100));
          const value = round(ratio);
          console.log("[KPI] CONSUMPTION value:", value);
          return value;
        } catch (consumptionError) {
          console.error("[KPI] Error computing consumption:", consumptionError?.message || consumptionError);
          console.log("[KPI] Consumption computation failed - returning 0");
          return 0;
        }
      }
 
      if (mode === "RECALL") {
        console.log("[KPI] Computing RECALL...");
        try {
          const recallData = await recallService.getAll();
          console.log("[KPI] Recalls API response:", recallData);
          const recalls = toArray(recallData);
          console.log("[KPI] Recalls array:", recalls, "Length:", recalls.length);
         
          // Filter to only ISSUED recalls
          const issuedRecalls = recalls.filter((item) => {
            const status = String(item.status || item.Status || "").toUpperCase();
            return status === "ISSUED";
          });
          console.log("[KPI] Issued recalls:", issuedRecalls.length, "Total recalls:", recalls.length);
         
          if (!issuedRecalls || issuedRecalls.length === 0) {
            console.warn("[KPI] No issued recalls found - returning 0");
            return 0;
          }
         
          const total = issuedRecalls.length || 1;
          const completed = issuedRecalls.filter((item) => {
            const status = String(item.status || item.Status || "").toUpperCase();
            return ["COMPLETED", "CLOSED", "RESOLVED", "DONE"].includes(status);
          }).length;
          console.log("[KPI] Completed recalls (from issued):", completed, "Total issued recalls:", total);
          const value = round((completed / total) * 100);
          console.log("[KPI] RECALL value:", value);
          return value;
        } catch (recallError) {
          console.error("[KPI] Error fetching recalls:", recallError?.message || recallError);
          console.log("[KPI] Recalls service failed - returning 0");
          return 0;
        }
      }
    } catch (error) {
      console.error("[KPI] Unexpected error in buildKpiValue for mode:", mode, error);
      return 0;
    }
  };
 
  const handleCompute = async () => {
    setIsComputing(true);
    try {
      console.log("[KPI] Starting computation for KPI:", selectedDef.name, selectedDef.id);
      const currentValue = await buildKpiValue(selectedKpiId, selectedPeriod);
      console.log("[KPI] Got currentValue:", currentValue);
     
      if (currentValue === 0) {
        console.warn("[KPI] WARNING: currentValue is 0. This could mean:");
        console.warn("  1. No data exists for this KPI");
        console.warn("  2. Backend services are not responding");
        console.warn("  3. Check Network tab in DevTools for failed API calls");
        toast.warning("⚠️ KPI computed with value 0. Check console for details. Ensure backend is running at localhost:7896");
      }
     
      const dto = {
        kpiName: selectedDef.name,
        kpiId: selectedDef.id,
        period: selectedPeriod,
        target: previewTarget,
        currentValue,
        computedAt: new Date().toISOString(),
      };
 
      console.log("[KPI] Saving KPI record:", dto);
      const created = await kpiService.create(dto);
      const record = normalizeKpi(created) || normalizeKpi(dto);
      setKpis((prev) => [record, ...prev]);
     
      // Update live KPI values
      setLiveKpiValues((prev) => ({
        ...prev,
        [selectedKpiId]: currentValue,
      }));
     
      setCurrentPage(1);
     
      const message = currentValue === 0
        ? `KPI computed. Value: 0% (check backend data)`
        : `KPI computed and saved successfully. Value: ${currentValue}%`;
      toast.success(message);
    } catch (error) {
      console.error("Failed to compute KPI", error);
      toast.error(`Error: ${error?.message || "Failed to compute KPI. Check console and ensure backend is running."}`);
    } finally {
      setIsComputing(false);
    }
  };
 
  const handleDelete = async (id) => {
    if (!id) return;
    setDeletingId(id);
    setDeleteConfirmTarget(null);
    try {
      await kpiService.delete(id);
      setKpis((prev) => prev.filter((item) => item.id !== id));
      toast.success("KPI record deleted.");
      const nextPage = Math.max(1, Math.min(currentPage, Math.ceil((kpis.length - 1) / rowsPerPage) || 1));
      setCurrentPage(nextPage);
    } catch (error) {
      console.error("Failed to delete KPI", error);
      toast.error(error?.message || "Failed to delete KPI.");
    } finally {
      setDeletingId(null);
    }
  };
 
  const getKpiStatus = (id, currentValue, target) => {
    if (currentValue <= (target || 5)) {
      return { label: "Optimal", cls: "border-green-300 bg-green-50 text-green-700" };
    }
    return { label: "At Risk", cls: "border-red-300 bg-red-50 text-red-700" };
  };
 
  const kpiVisuals = KPI_DEFINITIONS.map((def) => {
    // Use live computed values from services
    const current = liveKpiValues[def.id] || 0;
    const target = FIXED_TARGETS[def.id];
   
    // Also check saved KPI records for historical data
    const latest = [...kpis]
      .filter((k) => k.kpiName === def.name || k.kpiName === def.id)
      .sort((a, b) => new Date(b.computedAt || 0) - new Date(a.computedAt || 0))[0];
   
    return { def, current, target, latest };
  });
 
  const barData = kpiVisuals.map(({ def, current, target }) => ({
    name: def.name,
    Current: current,
    Target: target,
  }));
 
  const pieData = kpiVisuals.map(({ def, current, target }) => ({
    name: def.name,
    value: Math.max(0, Math.min(100, current)),
    target,
  }));
 
  const lineData = KPI_DEFINITIONS.map((def) => {
    const historical = [...kpis]
      .filter((k) => k.kpiName === def.name || k.kpiName === def.id)
      .sort((a, b) => new Date(a.computedAt || 0) - new Date(b.computedAt || 0));
    return {
      kpi: def.name,
      data: historical.length
        ? historical.map((h) => ({
            date: h.computedAt ? new Date(h.computedAt).toLocaleDateString() : '',
            Current: Number(h.currentValue || 0),
            Target: FIXED_TARGETS[def.id],
          }))
        : [{ date: 'Now', Current: 0, Target: FIXED_TARGETS[def.id] }],
    };
  });
 
  const totalPages = Math.ceil(kpis.length / rowsPerPage);
  const paginatedKpis = useMemo(() => {
    const start = (currentPage - 1) * rowsPerPage;
    return kpis.slice(start, start + rowsPerPage);
  }, [kpis, currentPage, rowsPerPage]);
 
  return (
    <div className="space-y-8">
      <style>{`.hide-scrollbar{-ms-overflow-style:none;scrollbar-width:none}.hide-scrollbar::-webkit-scrollbar{display:none}`}</style>
 
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">KPI Dashboard</h1>
          <p className="text-gray-600 mt-1">Real-time key performance indicators from your services</p>
        </div>
        <button
          onClick={loadLiveKpiValues}
          disabled={isLoadingLiveValues}
          className="flex items-center gap-2 px-4 py-2 bg-[#3C8C85] text-white rounded-lg hover:bg-[#2E6B5E] disabled:opacity-60 transition-colors"
        >
          <RefreshCw className={`size-4 ${isLoadingLiveValues ? 'animate-spin' : ''}`} />
          {isLoadingLiveValues ? 'Refreshing...' : 'Refresh Live Data'}
        </button>
      </div>
 
      {/* Loading Indicator */}
      {isLoadingLiveValues && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-center gap-3">
          <RefreshCw className="size-5 animate-spin text-blue-600" />
          <span className="text-sm text-blue-700">Loading live KPI values from services...</span>
        </div>
      )}
 
      {/* Interactive Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
          <h2 className="text-lg font-bold mb-4 flex items-center gap-2"><BarChart3 size={18} className="text-[#3C8C85]" /> KPI Comparison</h2>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData} margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip formatter={(v, n) => [`${v}%`, n]} />
                <Legend />
                <Bar dataKey="Current" fill="#3b82f6" radius={[4,4,0,0]} name="Current Value" />
                <Bar dataKey="Target" fill="#f97316" radius={[4,4,0,0]} name="Target" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
 
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
          <h2 className="text-lg font-bold mb-4 flex items-center gap-2"><PieChartIcon size={18} className="text-[#3C8C85]" /> KPI Distribution</h2>
          <div className="h-72 flex items-center justify-center">
            <div className="flex flex-wrap gap-4 justify-center items-center">
              {pieData.map((pd) => (
                <div key={pd.name} className="flex flex-col items-center">
                  <PieChart width={140} height={140}>
                    <Pie
                      data={[{ name: 'Current', value: pd.value }, { name: 'Target', value: pd.target }]}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={60}
                      label={({ name, value }) => `${name}: ${value}%`}
                    >
                      <Cell fill="#3b82f6" />
                      <Cell fill="#f97316" />
                    </Pie>
                    <Tooltip formatter={(v) => `${v}%`} />
                  </PieChart>
                  <span className="text-xs font-semibold text-gray-700">{pd.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
 
      {/* KPI Trends Section */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
        <h2 className="text-lg font-bold mb-6">KPI Trends (Line/Area Charts)</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {lineData.map((ld) => (
            <div key={ld.kpi} className="flex flex-col items-center">
              <div className="w-full h-64">
                <ResponsiveContainer width="100%" height="100%">
                  {ld.kpi === 'Expiry Risk' ? (
                    <AreaChart data={ld.data} margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
                      <defs>
                        <linearGradient id="expiryGradient2" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#16a34a" stopOpacity={0.35} />
                          <stop offset="60%" stopColor="#f59e0b" stopOpacity={0.25} />
                          <stop offset="100%" stopColor="#ef4444" stopOpacity={0.15} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip formatter={(v, n) => [`${Number(v).toFixed(2)}%`, n]} />
                      <Area type="monotone" dataKey="Current" stroke="#3b82f6" strokeWidth={2.5} fill="url(#expiryGradient2)" />
                      <Line type="monotone" dataKey="Target" stroke="#f97316" strokeWidth={2.5} strokeDasharray="5 5" />
                    </AreaChart>
                  ) : (
                    <LineChart data={ld.data} margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip formatter={(v, n) => [`${Number(v).toFixed(2)}%`, n]} />
                      <Legend />
                      <Line type="monotone" dataKey="Current" stroke="#3b82f6" strokeWidth={2.5} dot={{ r: 4 }} name="Current Value" />
                      <Line type="monotone" dataKey="Target" stroke="#f97316" strokeWidth={2.5} strokeDasharray="5 5" dot={{ r: 4 }} name="Target" />
                    </LineChart>
                  )}
                </ResponsiveContainer>
              </div>
              <div className="mt-2 text-sm font-semibold text-gray-700">{ld.kpi}</div>
            </div>
          ))}
        </div>
      </div>
 
      {/* Compute Panel */}
      <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
        <div className="px-6 py-4 bg-[#3C8C85] text-white flex items-center gap-2">
          <Target size={18} />
          <h2 className="text-lg font-bold">Compute KPI</h2>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-5 items-end">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">KPI Name <span className="text-red-500">*</span></label>
              <select
                value={selectedKpiId}
                onChange={(e) => setSelectedKpiId(e.target.value)}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#3C8C85]/30 focus:border-[#3C8C85]"
              >
                {KPI_DEFINITIONS.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Target <span className="text-xs font-normal text-gray-400">(immutable)</span></label>
              <div className="relative">
                <input
                  type="text"
                  readOnly
                  value={previewTarget !== null ? `${previewTarget}%` : "—"}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm bg-gray-50 text-gray-500 cursor-not-allowed"
                />
                <Lock className="size-4 absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Reporting Period <span className="text-red-500">*</span></label>
              <select
                value={selectedPeriod}
                onChange={(e) => setSelectedPeriod(e.target.value)}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#3C8C85]/30 focus:border-[#3C8C85]"
              >
                {PERIOD_OPTIONS.map((p) => <option key={p.value} value={p.value}>{p.label}</option>)}
              </select>
            </div>
            <div>
              <button
                onClick={handleCompute}
                disabled={isComputing}
                className="w-full px-5 py-2.5 bg-[#3C8C85] text-white rounded-lg font-semibold hover:bg-[#2E6B5E] disabled:opacity-60 flex items-center justify-center gap-2 text-sm transition-colors duration-200"
              >
                {isComputing
                  ? <><RefreshCw className="size-4 animate-spin" /> Computing…</>
                  : <><Play className="size-4 fill-current" /> Compute &amp; Save</>}
              </button>
            </div>
          </div>
          <div className="mt-4 p-3 rounded-lg bg-gray-50 border border-gray-200 text-xs text-gray-600">
            <span className="font-semibold">How it is calculated: </span>{selectedDef.description}
          </div>
        </div>
      </div>
 
      {/* KPI Repository */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 bg-[#3C8C85] flex items-center justify-between">
          <h2 className="text-lg font-bold text-white">KPI Repository</h2>
          <span className="text-sm text-white/80">{kpis.length} record{kpis.length !== 1 ? "s" : ""}</span>
        </div>
        <div className="overflow-x-auto hide-scrollbar">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                {["KPI Name", "Target", "Current Value", "Period", "Status", "Actions"].map((h) => (
                  <th key={h} className={`px-6 py-3 text-xs font-semibold text-gray-600 uppercase tracking-wider ${h === "Actions" ? "text-center" : "text-left"}`}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {isLoading ? (
                <tr><td colSpan={6} className="px-6 py-10 text-center text-sm text-gray-500">
                  <RefreshCw className="size-5 animate-spin mx-auto mb-2 text-gray-400" />Loading KPIs…
                </td></tr>
              ) : paginatedKpis.length ? (
                paginatedKpis.map((kpi) => {
                  const def = KPI_DEFINITIONS.find((d) => d.name === kpi.kpiName || d.id === kpi.kpiName) || KPI_DEFINITIONS[0];
                  const status = getKpiStatus(def.id, kpi.currentValue, kpi.target || def.target);
                  const Icon = def.icon;
 
                  return (
                    <tr key={kpi.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className={`p-1.5 rounded-md ${def.bgColor}`}><Icon className={`size-3.5 ${def.iconColor}`} /></div>
                          <span className="font-medium text-gray-900">{kpi.kpiName || "—"}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-gray-700 font-semibold">
                        {kpi.target !== undefined && kpi.target !== null ? (
                          <span className="inline-flex items-center gap-2">
                            <span>{`${kpi.target}%`}</span>
                            <Lock className="size-3 text-gray-400" />
                          </span>
                        ) : "—"}
                      </td>
                      <td className="px-6 py-4 text-gray-900 font-bold">{kpi.currentValue !== undefined && kpi.currentValue !== null ? `${kpi.currentValue}%` : "—"}</td>
                      <td className="px-6 py-4 text-gray-600 text-xs uppercase">{kpi.period || "—"}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${status.cls}`}>{status.label}</span>
                      </td>
                      <td className="px-6 py-4 text-center relative">
                        <button
                          onClick={() => setActiveMenuId(activeMenuId === kpi.id ? null : kpi.id)}
                          className="p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 transition-colors duration-150 inline-flex items-center justify-center"
                        >
                          <MoreVertical size={16} />
                        </button>
                        {activeMenuId === kpi.id && (
                          <div
                            ref={menuRef}
                            className="absolute right-14 top-12 z-20 w-36 bg-white border border-gray-200 rounded-lg shadow-lg flex flex-col py-1 text-left"
                          >
                            <button
                              onClick={() => {
                                setViewKpi(kpi);
                                setActiveMenuId(null);
                              }}
                              className="px-4 py-2 text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                            >
                              <Eye size={14} /> View
                            </button>
                            <button
                              onClick={() => {
                                setDeleteConfirmTarget(kpi);
                                setActiveMenuId(null);
                              }}
                              className="px-4 py-2 text-xs text-red-600 hover:bg-gray-50 flex items-center gap-2"
                            >
                              <Trash2 size={14} /> Delete
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr><td colSpan={6} className="px-6 py-10 text-center text-gray-500">No KPI records found. Use the Compute panel above to generate KPIs.</td></tr>
              )}
            </tbody>
          </table>
        </div>
        {kpis.length > 0 && (
          <div className="px-6 py-4 border-t border-gray-200 flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-gray-50">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <span>Rows per page</span>
              <select value={rowsPerPage} onChange={(e) => { setRowsPerPage(Number(e.target.value)); setCurrentPage(1); }} className="border border-gray-300 rounded-md px-2 py-1 text-sm bg-white">
                {[5,10,20,50].map((n) => <option key={n} value={n}>{n}</option>)}
              </select>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} disabled={currentPage === 1} className="px-3 py-1.5 border border-gray-300 rounded-md text-sm disabled:opacity-50 hover:bg-gray-100 inline-flex items-center gap-1">
                <ChevronLeft size={15} /> Previous
              </button>
              <span className="text-sm text-gray-600 px-1">Page <span className="font-semibold text-gray-900">{currentPage}</span> of <span className="font-semibold text-gray-900">{totalPages}</span></span>
              <button onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="px-3 py-1.5 border border-gray-300 rounded-md text-sm disabled:opacity-50 hover:bg-gray-100 inline-flex items-center gap-1">
                Next <ChevronRight size={15} />
              </button>
            </div>
          </div>
        )}
      </div>
 
      {/* Delete Confirmation Modal */}
      {deleteConfirmTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6 mx-4">
            <h3 className="text-lg font-bold text-gray-900">Are you really want to delete?</h3>
            <p className="text-sm text-gray-500 mt-2">
              The KPI record <span className="font-semibold text-gray-800">{deleteConfirmTarget.kpiName}</span> will be removed permanently.
            </p>
            <div className="flex justify-end gap-3 mt-6">
              <button
                onClick={() => setDeleteConfirmTarget(null)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deleteConfirmTarget.id)}
                disabled={deletingId === deleteConfirmTarget.id}
                className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700 disabled:opacity-50"
              >
                {deletingId === deleteConfirmTarget.id ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
 
      {/* View Modal */}
      {viewKpi && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/30 backdrop-blur-sm p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto flex flex-col">
            <div className="px-6 py-4 bg-[#3C8C85] text-white flex justify-between items-center sticky top-0 z-50">
              <h2 className="text-lg font-bold">KPI Analytics: {viewKpi.kpiName}</h2>
              <button onClick={() => setViewKpi(null)} className="p-1 hover:bg-[#2E6B5E] rounded-md transition-colors">
                <X size={20} />
              </button>
            </div>
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-3 gap-4 bg-gray-50 p-4 rounded-xl border border-gray-100">
                <div>
                  <div className="text-xs text-gray-500 uppercase tracking-wider font-medium">Value</div>
                  <div className="text-2xl font-black text-gray-900 mt-1">{viewKpi.currentValue}%</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500 uppercase tracking-wider font-medium">Target</div>
                  <div className="text-2xl font-black text-gray-900 mt-1">{viewKpi.target}%</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500 uppercase tracking-wider font-medium">Period</div>
                  <div className="text-2xl font-black text-gray-900 mt-1 uppercase text-gray-700">{viewKpi.period}</div>
                </div>
              </div>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={[
                      { name: viewKpi.kpiName, value: viewKpi.currentValue, target: viewKpi.target, date: new Date(viewKpi.computedAt).toLocaleDateString() }
                    ]}
                    margin={{ top: 10, right: 20, left: 0, bottom: 10 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="value" stroke="#3b82f6" strokeWidth={3} name="Value" dot={{ r: 6 }} />
                    <Line type="monotone" dataKey="target" stroke="#f97316" strokeWidth={2} strokeDasharray="5 5" name="Target" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-end pt-4 border-t border-gray-100">
                <button
                  onClick={() => setViewKpi(null)}
                  className="px-4 py-2 bg-gray-100 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-200 transition-colors"
                >
                  Close Window
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export { KPI };
export default KPI;