import { useEffect, useMemo, useRef, useState } from "react";
import { CheckCircle, XCircle, Clock, AlertCircle, MoreVertical } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { dispensingAPI } from "../../services/api";
import { productsAPI, batchesAPI } from "../../services/api";
import { PharmacistDispensing } from "./PharmacistDispensing";
import { NurseDispensing } from "./NurseDispensing";

// Toast Component
function Toast({ message, type = "success", onClose }) {
  return (
    <div
      className={`fixed top-5 right-5 z-50 px-4 py-3 rounded-lg shadow-lg
        text-white animate-slide-in
        ${type === "success" ? "bg-green-600" : type === "error" ? "bg-red-600" : "bg-blue-600"}`}
    >
      {message}
      <button onClick={onClose} className="ml-3 font-bold">
        ×
      </button>
    </div>
  );
}

export function Requisition() {
  const currentUser = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem("pharmaShelfUser") || "{}");
    } catch {
      return {};
    }
  }, []);

  const userRoleString = String(currentUser?.role || "").toUpperCase();
  const isPharmacistUser = userRoleString.includes("PHARM");
  const isClinicianUser = userRoleString.includes("CLINICIAN");
  const isNurseUser = userRoleString.includes("NURSE");

  console.log("🔍 Role Detection:", {
    rawRole: currentUser?.role,
    userRoleString,
    isPharmacistUser,
    isClinicianUser,
    isNurseUser,
  });

  // Route to appropriate component based on role
  if (isPharmacistUser) {
    return <PharmacistDispensing />;
  } else if (isNurseUser || isClinicianUser) {
    return <NurseDispensing />;
  }

  // Fallback for unknown role
  return (
    <div className="p-8 text-center">
      <h1 className="text-2xl font-bold text-gray-900">Access Denied</h1>
      <p className="text-gray-600 mt-2">Your role does not have access to this page.</p>
    </div>
  );
}

export default Requisition;
