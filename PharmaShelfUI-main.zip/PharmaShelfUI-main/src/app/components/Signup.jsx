import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Eye, EyeOff } from "lucide-react";
import { signupRoles, signupText } from "../constants/signupConstants";
import { authAPI } from "../../services/api";
 
export function Signup() {
  const navigate = useNavigate();
 
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    role: "",
    password: "",
    confirmPassword: "",
  });
 
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState("");
 
  const [errors, setErrors] = useState({});
 
  const validateField = (name, value) => {
    let error = "";
    switch (name) {
      case "name":
        if (!/^[a-zA-Z\s]*$/.test(value)) {
          error = "Name can only contain alphabets and spaces.";
        }
        break;
      case "email":
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
          error = "Invalid email address.";
        }
        break;
      case "phone":
        if (!/^\d{10}$/.test(value)) {
          error = "Phone number must be 10 digits.";
        }
        break;
      case "password":
        if (value.length < 6) {
          error = "Password must be at least 6 characters long.";
        }
        break;
      case "confirmPassword":
        if (value !== formData.password) {
          error = "Passwords do not match.";
        }
        break;
      default:
        break;
    }
    setErrors((prevErrors) => ({ ...prevErrors, [name]: error }));
  };
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    validateField(name, value);
  };
 
  const getApiErrorMessage = (error) => {
    const raw = error?.message || "";
    const jsonStart = raw.indexOf("{");
 
    if (jsonStart !== -1) {
      try {
        const parsed = JSON.parse(raw.slice(jsonStart));
        if (parsed?.message) return parsed.message;
      } catch {
        // ignore parse issues and fallback
      }
    }
 
    return raw || "Unable to register";
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
 
    if (formData.password !== formData.confirmPassword) {
      setMessage(signupText.passwordMismatch);
      setMessageType("error");
      return;
    }
 
    if (!formData.role) {
      setMessage("Please select a role");
      setMessageType("error");
      return;
    }
 
    try {
      await authAPI.signup({
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        role: formData.role,
        password: formData.password,
      });
      navigate("/login");
    } catch (error) {
      setMessage(signupText.signupFailedPrefix + getApiErrorMessage(error));
      setMessageType("error");
    }
  };
 
  const labelClass =
    "block text-sm font-medium text-gray-700 mb-1";
  const inputClass =
    "w-full rounded-lg border border-gray-300 bg-gray-50 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#3C8C85]";
 
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#3C8C85] px-4">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-xl p-6 sm:p-8">
        {/* Header */}
        <div className="text-center mb-6">
         
            <h2 className="text-2xl font-bold text-gray-900">
            {signupText.pageTitle}
            </h2>
 
          <p className="text-sm text-gray-500 mt-1">
            {signupText.pageSubtitle}
          </p>
        </div>
 
        {message && (
          <div className="mb-4 text-xs text-center text-red-600">
            {message}
          </div>
        )}
 
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Row 1: Name + Email */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className={labelClass}>Name</label>
              <input
                name="name"
                className={inputClass}
                placeholder={signupText.namePlaceholder}
                onChange={handleChange}
                required
              />
              {errors.name && (
                <p className="text-xs text-red-600 mt-1">{errors.name}</p>
              )}
            </div>
 
            <div>
              <label className={labelClass}>Email Address</label>
              <input
                type="email"
                name="email"
                className={inputClass}
                placeholder={signupText.emailPlaceholder}
                onChange={handleChange}
                required
              />
              {errors.email && (
                <p className="text-xs text-red-600 mt-1">{errors.email}</p>
              )}
            </div>
          </div>
 
          {/* Row 2: Phone + Role */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className={labelClass}>Phone Number</label>
              <input
                name="phone"
                className={inputClass}
                placeholder={signupText.phonePlaceholder}
                onChange={handleChange}
                required
              />
              {errors.phone && (
                <p className="text-xs text-red-600 mt-1">{errors.phone}</p>
              )}
            </div>
 
            <div>
              <label className={labelClass}>Role</label>
              <select
                name="role"
                className={inputClass}
                onChange={handleChange}
                required
              >
                {signupRoles.map((role) => (
                  <option key={role.value} value={role.value}>
                    {role.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
 
          {/* Row 3: Password + Confirm Password */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className={labelClass}>Password</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  className={`${inputClass} pr-10`}
                  placeholder={signupText.passwordPlaceholder}
                  onChange={handleChange}
                  required
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              {errors.password && (
                <p className="text-xs text-red-600 mt-1">{errors.password}</p>
              )}
            </div>
 
            <div>
              <label className={labelClass}>Confirm Password</label>
              <div className="relative">
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  name="confirmPassword"
                  className={`${inputClass} pr-10`}
                  placeholder={signupText.confirmPasswordPlaceholder}
                  onChange={handleChange}
                  required
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                  onClick={() =>
                    setShowConfirmPassword(!showConfirmPassword)
                  }
                >
                  {showConfirmPassword ? (
                    <EyeOff size={16} />
                  ) : (
                    <Eye size={16} />
                  )}
                </button>
              </div>
              {errors.confirmPassword && (
                <p className="text-xs text-red-600 mt-1">{errors.confirmPassword}</p>
              )}
            </div>
          </div>
 
          {/* Submit */}
          <button
            type="submit"
            className="w-2/5 mt-3 py-2.5 bg-[#3C8C85] text-white text-sm font-semibold rounded-lg hover:bg-[#35736e] mx-auto block"
          >
            {signupText.signupButton}
          </button>
 
          {/* Login */}
          <p className="text-sm text-center text-gray-600 mt-4">
            {signupText.switchToLoginText}{" "}
            <button
              type="button"
              onClick={() => navigate("/login")}
              className="text-[#3C8C85] hover:underline"
            >
              {signupText.loginButtonText}
            </button>
          </p>
        </form>
      </div>
    </div>
  );
}