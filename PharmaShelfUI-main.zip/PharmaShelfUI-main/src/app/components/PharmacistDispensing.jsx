import { useEffect, useMemo, useRef, useState } from "react";
import { CheckCircle, XCircle, Clock, AlertCircle, MoreVertical, Search } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { dispensingAPI } from "../../services/api";
import { productsAPI, batchesAPI } from "../../services/api";

// Toast Component
function Toast({ message, type = "success", onClose }) {
  return (
    <div
      className={`fixed top-5 right-5 z-50 px-4 py-3 rounded-lg shadow-lg
        text-white animate-slide-in
        ${type === "success" ? "bg-green-600" : type === "error" ? "bg-red-600" : "bg-blue-600"}`}
    >
      {message}
      <button onClick={onClose} className="ml-3 font-bold">
        ×
      </button>
    </div>
  );
}

export function PharmacistDispensing() {
  const currentUser = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem("pharmaShelfUser") || "{}");
    } catch {
      return {};
    }
  }, []);

  const currentUserId =
    currentUser?.userId ?? currentUser?.id ?? currentUser?.userID ?? null;
  const currentUserName =
    currentUser?.name || currentUser?.email || "Staff";

  // Ward options with IDs
  const wardOptions = [
    { id: 1, name: "General" },
    { id: 2, name: "Medical" },
    { id: 3, name: "Surgery" },
    { id: 4, name: "ICU" },
    { id: 5, name: "Emergency/ER" },
    { id: 6, name: "Maternity" },
    { id: 7, name: "Pediatrics" },
    { id: 8, name: "Oncology" },
    { id: 9, name: "Psychiatric" },
    { id: 10, name: "Isolation" },
    { id: 11, name: "Rehab" },
    { id: 12, name: "Private" },
  ];

  // Helper to get ward name from ID
  const getWardName = (wardId) => {
    if (!wardId) return "—";
    const ward = wardOptions.find(w => w.id === Number(wardId) || w.name === String(wardId));
    return ward ? ward.name : String(wardId);
  };

  const [activeTab, setActiveTab] = useState("requests");
  const [searchQuery, setSearchQuery] = useState("");
  const [searchStatus, setSearchStatus] = useState("");
  const [toast, setToast] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [acting, setActing] = useState(false);

  const [requests, setRequests] = useState([]);
  const [products, setProducts] = useState([]);
  const [batches, setBatches] = useState([]);
  const [showDispenseModal, setShowDispenseModal] = useState(false);
  const [selectedRequestForDispense, setSelectedRequestForDispense] = useState(null);
  const [selectedBatchForDispense, setSelectedBatchForDispense] = useState("");

  // Actions menu state
  const [openActionsMenu, setOpenActionsMenu] = useState(null);
  const actionsMenuRef = useRef(null);

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const PAGE_SIZE = 10;

  // Load all data in parallel
  const loadAllData = async () => {
    try {
      setLoading(true);
      setError("");
      
      console.log("🔄 Starting data load for Pharmacist Dispensing...");
      
      const [requestsData, productsData, batchesData] = await Promise.all([
        dispensingAPI.getAll().catch((err) => {
          console.warn("⚠️ Failed to fetch dispenses:", err);
          return [];
        }),
        productsAPI.getAll().catch((err) => {
          console.warn("⚠️ Failed to fetch products:", err);
          return [];
        }),
        batchesAPI.getAll().catch((err) => {
          console.warn("⚠️ Failed to fetch batches:", err);
          return [];
        }),
      ]);

      console.log("📊 Raw API Responses:", {
        requestsData,
        productsData: productsData?.length || 0,
        batchesData: batchesData?.length || 0,
      });

      // Process requests
      let requestsRows = [];
      if (Array.isArray(requestsData)) {
        requestsRows = requestsData;
        console.log(`✅ Requests: ${requestsRows.length} items received`);
      } else if (requestsData?.data && Array.isArray(requestsData.data)) {
        requestsRows = requestsData.data;
        console.log(`✅ Requests (wrapped): ${requestsRows.length} items received`);
      } else {
        console.warn("⚠️ Requests data is not in expected format:", requestsData);
      }

      // Process products
      let productsRows = [];
      if (Array.isArray(productsData)) {
        productsRows = productsData;
      } else if (productsData?.data && Array.isArray(productsData.data)) {
        productsRows = productsData.data;
      }
      
      // Create a product map for quick lookup
      const productMap = {};
      productsRows.forEach(product => {
        const prodId = product.productId || product.id;
        productMap[prodId] = product.name || product.productName || `Product ${prodId}`;
      });

      // Normalize requests with product names
      const normalized = requestsRows.map(row => normalizeRequest(row, productMap));
      console.log("📋 Normalized requests:", normalized);
      setRequests(normalized);

      const activeProducts = productsRows.filter((product) => {
        const status = String(product.status || "").trim().toUpperCase();
        const isActive = product.isActive !== false;
        return status === "ACTIVE" && isActive;
      });
      console.log(`✅ Products: ${activeProducts.length} active items`);
      setProducts(activeProducts);

      // Process batches
      let batchesRows = [];
      if (Array.isArray(batchesData)) {
        batchesRows = batchesData;
      }
      console.log(`✅ Batches: ${batchesRows.length} items`);
      setBatches(batchesRows);
    } catch (err) {
      console.error("❌ Error loading data:", err);
      setError("Failed to load data");
      setRequests([]);
      setProducts([]);
      setBatches([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  // Close Actions menu on click outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (actionsMenuRef.current && !actionsMenuRef.current.contains(event.target)) {
        // Check if click is on the button that opens the menu
        const isMenuButton = event.target.closest('button')?.innerHTML.includes('MoreVertical');
        if (!isMenuButton) {
          setOpenActionsMenu(null);
        }
      }
    };

    if (openActionsMenu) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => {
        document.removeEventListener('mousedown', handleClickOutside);
      };
    }
  }, [openActionsMenu]);

  const normalizeRequest = (row, productMap = {}) => {
    const id = row?.dispenseID ?? row?.dispenseId ?? row?.id;
    const patientId = row?.patientID ?? row?.patientId ?? "";
    const ward = row?.wardID ?? row?.wardId ?? "";
    const productId = row?.productID ?? row?.productId ?? "";
    const purpose = row?.purpose ?? "";
    const status = String(row?.status || "PENDING").toUpperCase();

    // Debug: log all fields in the row to understand structure
    console.log("🔍 Full row data:", row);

    // Extract user email - check many possible field names
    const userEmail = 
      row?.email || 
      row?.userEmail || 
      row?.user?.email ||
      row?.requestedBy?.email ||
      row?.createdByEmail ||
      row?.nurseName || 
      row?.createdBy || 
      row?.requestedBy ||
      row?.user?.name ||
      row?.requestedByName ||
      row?.createdByName ||
      "Unknown User";
    
    // Extract user role - check many possible field names
    const userRole = 
      row?.role || 
      row?.userRole ||
      row?.requestedByRole || 
      row?.createdByRole || 
      row?.user?.role ||
      row?.requestedBy?.role ||
      "Staff";

    // Extract product name from productMap or row
    const productName = row?.productName || productMap[productId] || `Product ${productId}`;

    console.log("👤 Extracted user info:", { userEmail, userRole });

    const normalized = {
      id,
      batchId: row?.batchID ?? row?.batchId ?? null,
      productId,
      productName,
      patientId,
      ward,
      quantity: Number(row?.quantity ?? 0),
      purpose,
      reason: purpose,
      status,
      requestedBy: userEmail,
      requestedByRole: userRole,
      requestedByUserId: row?.requestedByUserId ?? row?.createdByUserId ?? row?.nurseId ?? null,
      requestedAt: row?.requestedAt || row?.createdAt || "-",
      approvedBy: row?.approvedBy || null,
      approvedAt: row?.approvedAt || null,
      rejectedBy: row?.rejectedBy || null,
      rejectedAt: row?.rejectedAt || null,
      rejectionReason: row?.rejectionReason || null,
      dispensedBy: row?.dispensedBy ?? null,
      dispensedAt: row?.dispensedAt ?? null,
    };
    
    console.log("📝 Normalized request:", normalized);
    return normalized;
  };

  const showToast = (message, type = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const approveRequest = async (requestId) => {
    try {
      console.log("📤 Approving request:", requestId);
      setActing(true);
      // Use update method with approve payload
      await dispensingAPI.update(requestId, {
        status: "APPROVED",
        approvedBy: currentUserName,
        approvedAt: new Date().toISOString(),
        dispensedBy: currentUserName,
        dispensedAt: new Date().toISOString(),
      });
      showToast("Request approved successfully!");
      console.log("✅ Request approved successfully");
      loadAllData();
    } catch (err) {
      console.error("❌ Failed to approve request:", err);
      showToast("Failed to approve request", "error");
    } finally {
      setActing(false);
    }
  };

  const rejectRequest = async (requestId, reason) => {
    if (!reason) {
      showToast("Please provide a rejection reason", "error");
      return;
    }
    try {
      console.log("📤 Rejecting request:", requestId, "Reason:", reason);
      setActing(true);
      // Use update method with reject payload
      await dispensingAPI.update(requestId, {
        status: "REJECTED",
        rejectionReason: reason,
        rejectedBy: currentUserName,
        rejectedAt: new Date().toISOString(),
      });
      showToast("Request rejected successfully!");
      console.log("✅ Request rejected successfully");
      loadAllData();
    } catch (err) {
      console.error("❌ Failed to reject request:", err);
      showToast("Failed to reject request", "error");
    } finally {
      setActing(false);
    }
  };

  const dispenseRequest = async (requestId, batchId) => {
    if (!batchId) {
      showToast("Please select a batch", "error");
      return;
    }
    try {
      console.log("📤 Dispensing request:", requestId, "Batch:", batchId);
      setActing(true);
      // Use update method with dispense payload
      await dispensingAPI.update(requestId, {
        status: "DISPENSED",
        batchId: Number(batchId),
        dispensedBy: currentUserName,
        dispensedAt: new Date().toISOString(),
      });
      showToast("Medication dispensed successfully!");
      console.log("✅ Medication dispensed successfully");
      setShowDispenseModal(false);
      setSelectedRequestForDispense(null);
      setSelectedBatchForDispense("");
      loadAllData();
    } catch (err) {
      console.error("❌ Failed to dispense medication:", err);
      showToast("Failed to dispense medication", "error");
    } finally {
      setActing(false);
    }
  };

  const filteredRequests = useMemo(() => {
    return requests.filter((r) => {
      // Map tab names to actual statuses
      const tabStatusMap = {
        "all": null, // Show all
        "requests": "REQUESTED",
        "approved": "APPROVED",
        "rejected": "REJECTED",
      };
      
      const targetStatus = tabStatusMap[activeTab] || activeTab.toUpperCase();
      const matchesTab = activeTab === "all" || r.status === targetStatus;
      
      const matchesSearch =
        !searchQuery ||
        r.productName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.patientId.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus =
        !searchStatus || r.status.toLowerCase().includes(searchStatus.toLowerCase());
      
      console.log("🔍 Filter check:", { tab: activeTab, targetStatus, requestStatus: r.status, matchesTab, matchesSearch, matchesStatus });
      
      return matchesTab && matchesSearch && matchesStatus;
    });
  }, [requests, activeTab, searchQuery, searchStatus]);

  const totalPages = Math.ceil(filteredRequests.length / PAGE_SIZE);
  const paginatedRequests = filteredRequests.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE
  );

  return (
    <div className="space-y-4 p-4">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Pharmacist - Review Requests</h1>
        <p className="text-gray-600 text-sm mt-1">Review and approve/reject medication dispensing requests from nurses and clinicians</p>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      {/* Tab Navigation */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="flex border-b border-gray-200">
          {["requests", "approved", "rejected", "all"].map((tab) => {
            const statusMap = {
              "requests": "REQUESTED",
              "approved": "APPROVED",
              "rejected": "REJECTED",
              "all": null,
            };
            const tabStatus = statusMap[tab];
            const count = tabStatus ? requests.filter(r => r.status === tabStatus).length : requests.length;
            
            return (
              <button
                key={tab}
                onClick={() => {
                  setActiveTab(tab);
                  setCurrentPage(1);
                }}
                className={`px-6 py-3 font-medium text-sm transition-colors ${
                  activeTab === tab
                    ? "text-[#3C8C85] border-b-2 border-[#3C8C85] bg-[#3C8C85]/5"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
                <span className="ml-2 text-gray-500">({count})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Search */}
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-3 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search by product name or patient ID..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            className="pl-10"
          />
        </div>
      </div>

      {/* Requests Table */}
      <Card>
        <CardHeader>
          <CardTitle>Dispensing Requests</CardTitle>
          <CardDescription>
            Total: {filteredRequests.length} requests
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-gray-500">Loading...</div>
          ) : paginatedRequests.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No requests found
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-[#3C8C85]">
                      <TableHead className="text-white">Product</TableHead>
                      <TableHead className="text-white">Patient ID</TableHead>
                      <TableHead className="text-white">Ward</TableHead>
                      <TableHead className="text-white">Quantity</TableHead>
                      <TableHead className="text-white">Status</TableHead>
                      <TableHead className="text-white">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedRequests.map((request) => (
                      <TableRow key={request.id}>
                        <TableCell className="font-medium">
                          {request.productName}
                        </TableCell>
                        <TableCell>{request.patientId}</TableCell>
                        <TableCell>{getWardName(request.ward)}</TableCell>
                        <TableCell>{request.quantity}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            request.status === "REQUESTED"
                              ? "bg-yellow-100 text-yellow-800"
                              : request.status === "APPROVED"
                              ? "bg-green-100 text-green-800"
                              : "bg-red-100 text-red-800"
                          }`}>
                            {request.status}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="relative inline-block">
                            <button
                              onClick={(e) => {
                                const rect = e.currentTarget.getBoundingClientRect();
                                const spaceBelow = window.innerHeight - rect.bottom;
                                const dir = spaceBelow < 120 ? 'up' : 'down';
                                setOpenActionsMenu(prev => prev?.id === request.id ? null : {
                                  id: request.id,
                                  dir,
                                  top: rect.bottom + 4,
                                  bottom: window.innerHeight - rect.top + 4,
                                  right: window.innerWidth - rect.right,
                                });
                              }}
                              className="p-1.5 rounded hover:bg-gray-100 text-gray-600 hover:text-gray-800"
                            >
                              <MoreVertical size={16} />
                            </button>
                            {openActionsMenu?.id === request.id && (
                              <div
                                ref={actionsMenuRef}
                                className="bg-white border border-gray-200 rounded-lg shadow-xl"
                                style={{
                                  position: 'fixed',
                                  zIndex: 9999,
                                  width: '200px',
                                  display: 'flex',
                                  flexDirection: 'column',
                                  right: openActionsMenu.right,
                                  ...(openActionsMenu.dir === 'up'
                                    ? { bottom: openActionsMenu.bottom }
                                    : { top: openActionsMenu.top }),
                                  maxHeight: '300px',
                                }}
                              >
                                {request.status === "REQUESTED" && (
                                  <>
                                    <button
                                      onClick={() => { approveRequest(request.id); setOpenActionsMenu(null); }}
                                      className="w-full px-4 py-2.5 text-left text-sm font-medium text-green-600 hover:bg-green-50 border-b border-gray-100 transition-colors"
                                      disabled={acting}
                                    >
                                      <span className="flex items-center gap-2">
                                        <span className="text-lg">✓</span> Approve
                                      </span>
                                    </button>
                                    <button
                                      onClick={() => {
                                        const reason = prompt("Enter rejection reason:");
                                        if (reason) {
                                          rejectRequest(request.id, reason);
                                          setOpenActionsMenu(null);
                                        }
                                      }}
                                      className="w-full px-4 py-2.5 text-left text-sm font-medium text-red-600 hover:bg-red-50 transition-colors"
                                      disabled={acting}
                                    >
                                      <span className="flex items-center gap-2">
                                        <span className="text-lg">✕</span> Reject
                                      </span>
                                    </button>
                                  </>
                                )}
                                {request.status === "APPROVED" && (
                                  <button
                                    onClick={() => {
                                      setSelectedRequestForDispense(request);
                                      setShowDispenseModal(true);
                                      setOpenActionsMenu(null);
                                    }}
                                    className="w-full px-4 py-2.5 text-left text-sm font-medium text-blue-600 hover:bg-blue-50 transition-colors"
                                    disabled={acting}
                                  >
                                    <span className="flex items-center gap-2">
                                      <span className="text-lg">💊</span> Dispense
                                    </span>
                                  </button>
                                )}
                                {request.status === "REJECTED" && (
                                  <div className="px-4 py-2.5 text-sm text-gray-500 bg-gray-50">
                                    <p className="font-medium">Request Rejected</p>
                                    <p className="text-xs mt-1">{request.rejectionReason || "No reason provided"}</p>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex justify-between items-center mt-4 pt-4 border-t">
                  <div className="text-sm text-gray-600">
                    Page {currentPage} of {totalPages}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                      disabled={currentPage === 1}
                    >
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        setCurrentPage(Math.min(totalPages, currentPage + 1))
                      }
                      disabled={currentPage === totalPages}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Dispense Modal */}
      {showDispenseModal && selectedRequestForDispense && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center">
          <Card className="w-full max-w-md border-0 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-[#3C8C85]/10 to-transparent border-b">
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Dispense Medication</CardTitle>
                  <CardDescription>Select batch and dispense the medication</CardDescription>
                </div>
                <button
                  onClick={() => {
                    setShowDispenseModal(false);
                    setSelectedRequestForDispense(null);
                    setSelectedBatchForDispense("");
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              {/* Request Info */}
              <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm font-medium text-blue-900">Request Details</p>
                <div className="mt-2 text-sm text-blue-800 space-y-1">
                  <p><strong>Product:</strong> {selectedRequestForDispense.productName}</p>
                  <p><strong>Patient:</strong> {selectedRequestForDispense.patientId}</p>
                  <p><strong>Quantity:</strong> {selectedRequestForDispense.quantity}</p>
                </div>
              </div>

              {/* Batch Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select Batch <span className="text-red-500">*</span>
                </label>
                <Select value={selectedBatchForDispense} onValueChange={setSelectedBatchForDispense}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a batch (FEFO)" />
                  </SelectTrigger>
                  <SelectContent>
                    {batches
                      .filter((b) => {
                        // Filter batches: active, not expired, matching product, with available quantity
                        const today = new Date();
                        const isActive = String(b.status || "ACTIVE").toUpperCase() === "ACTIVE";
                        const expiryDate = b.expiryDate ? new Date(b.expiryDate) : null;
                        const isNotExpired = !expiryDate || expiryDate >= today;
                        const matchesProduct = String(b.productId || b.id) === String(selectedRequestForDispense.productId);
                        const hasQuantity = Number(b.quantityAvailable || b.quantity || 0) >= selectedRequestForDispense.quantity;
                        return isActive && isNotExpired && matchesProduct && hasQuantity;
                      })
                      .sort((a, b) => {
                        // Sort by expiry date (FEFO - earliest first)
                        const dateA = a.expiryDate ? new Date(a.expiryDate) : new Date('9999-12-31');
                        const dateB = b.expiryDate ? new Date(b.expiryDate) : new Date('9999-12-31');
                        return dateA - dateB;
                      })
                      .map((batch) => (
                        <SelectItem key={batch.batchId || batch.id} value={String(batch.batchId || batch.id)}>
                          Batch: {batch.batchNumber} | Exp: {batch.expiryDate} | Qty: {batch.quantityAvailable || batch.quantity}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Form Actions */}
              <div className="mt-6 flex gap-3 justify-end border-t pt-4">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowDispenseModal(false);
                    setSelectedRequestForDispense(null);
                    setSelectedBatchForDispense("");
                  }}
                >
                  Cancel
                </Button>
                <Button
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={() => dispenseRequest(selectedRequestForDispense.id, selectedBatchForDispense)}
                  disabled={acting || !selectedBatchForDispense}
                >
                  {acting ? "Dispensing..." : "Dispense"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
}

export default PharmacistDispensing;
