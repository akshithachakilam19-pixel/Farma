import { useEffect, useState } from "react";
import { Plus, Edit, MoreVertical, Edit2 } from "lucide-react";
import { usersAPI } from "../../services/api";
import { AddUserModal } from "./AddUserModal";
import { EditUserModal } from "./EditUserModal";
import { ROLE_DEFINITIONS } from "../constants/roleConstants";
 
export function UserManagement() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [editUser, setEditUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRole, setSelectedRole] = useState("All Types");
  const [openMenuUserId, setOpenMenuUserId] = useState(null);
 
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const USERS_PER_PAGE = 6;
 
  // ✅ RBAC: current user
  const currentUser = JSON.parse(
    localStorage.getItem("pharmaShelfUser")
  );
  const isAdmin = true; // Role-based access removed – all users have full access
 
  /* =========================
     Fetch users (DB source of truth)
  ========================= */
  const fetchUsers = async () => {
    try {
      setLoading(true);
      const data = await usersAPI.getAll();
      setUsers(data);
    } catch (err) {
      console.error(err);
      setError("Failed to load users");
    } finally {
      setLoading(false);
    }
  };
 
  useEffect(() => {
    fetchUsers();
  }, []);
 
  /* =========================
     Helpers
  ========================= */
  const getRoleLabel = (role) =>
    ROLE_DEFINITIONS[role]?.label || role;
 
  const getRoleBadgeClass = (role) =>
    ROLE_DEFINITIONS[role]?.badgeClass ||
    "bg-gray-100 text-gray-700";
 
  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.role.toLowerCase().includes(searchQuery.toLowerCase());
 
    const matchesRole =
      selectedRole === "All Types" || user.role === selectedRole;
 
    return matchesSearch && matchesRole;
  });
 
  // CSV export helper
  function exportToCSV() {
    const headers = ["Name", "Email", "Role", "Phone"];
    const rows = filteredUsers.map(user => [
      user.name,
      user.email,
      user.role,
      user.phone || ""
    ]);
    const csvContent = [
      headers.join(","),
      ...rows.map(row => row.map(field => `"${String(field).replace(/"/g, '""')}"`).join(","))
    ].join("\r\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "users.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
 
  /* =========================
     Render
  ========================= */
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            User Management & Access Control
          </h1>
          <p className="text-gray-600 mt-1">
            Manage users, roles, and audit trails
          </p>
        </div>
 
        {/* ✅ Admin only */}
        {isAdmin && (
          <div className="relative group flex items-center">
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center justify-center w-10 h-10 rounded-lg text-white"
              style={{ backgroundColor: '#3C8C85' }}
              aria-label="Add User"
            >
              <Plus className="size-5" />
            </button>
            <div className="absolute left-1/2 -translate-x-1/2 mt-2 z-10 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity bg-gray-900 text-white text-xs rounded py-1 px-2 whitespace-nowrap shadow-lg" style={{top: '100%'}}>
              Add User
            </div>
          </div>
        )}
      </div>
 
      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
        <input
          type="text"
          placeholder="Search by name or role"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full sm:w-1/2 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] mb-2 sm:mb-0"
        />
 
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={selectedRole}
            onChange={(e) => setSelectedRole(e.target.value)}
            className="w-full sm:w-40 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] sm:ml-auto"
          >
            <option value="All Types">All Types</option>
            {Object.keys(ROLE_DEFINITIONS).map((role) => (
              <option key={role} value={role}>
                {ROLE_DEFINITIONS[role]?.label || role}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={exportToCSV}
            className="ml-2 px-4 py-2 bg-[#3C8C85] text-white rounded-lg hover:bg-[#36766F] text-sm font-medium"
          >
            Export
          </button>
        </div>
      </div>
 
      {/* Users Table */}
      <div className="bg-white rounded-xl border overflow-hidden">
        {loading ? (
          <div className="p-6 text-gray-500">Loading users…</div>
        ) : error ? (
          <div className="p-6 text-red-600">{error}</div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px]">
              <thead>
                <tr style={{ backgroundColor: '#3C8C85' }}>
                  <th className="px-6 py-4 text-center text-base font-bold tracking-wide" style={{ color: '#fff' }}>
                    User
                  </th>
                  <th className="px-6 py-4 text-center text-base font-bold tracking-wide" style={{ color: '#fff' }}>
                    Email
                  </th>
                  <th className="px-6 py-4 text-center text-base font-bold tracking-wide" style={{ color: '#fff' }}>
                    Role
                  </th>
                  <th className="px-6 py-4 text-center text-base font-bold tracking-wide" style={{ color: '#fff' }}>
                    Phone
                  </th>
                  <th className="px-6 py-4 text-center text-base font-bold tracking-wide" style={{ color: '#fff' }}>
                    Actions
                  </th>
                </tr>
              </thead>
 
              <tbody>
                {filteredUsers
                  .slice((currentPage - 1) * USERS_PER_PAGE, currentPage * USERS_PER_PAGE)
                  .map((user) => (
                    <tr key={user.userID} className="border-t">
 
                      <td className="px-6 py-4 text-center">
                        <span className="font-medium text-gray-900">{user.name}</span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className="text-sm text-black">{user.email}</span>
                      </td>
 
 
                      <td className="px-6 py-4 text-center">
                        <span
                          className={`inline-flex justify-center items-center px-3 py-1 rounded-full text-xs font-semibold ${getRoleBadgeClass(
                            user.role
                          )}`}
                          style={{ minWidth: 120, textAlign: 'center', display: 'inline-block' }}
                        >
                          {getRoleLabel(user.role)}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        {user.phone || <span className="text-gray-400">-</span>}
                      </td>
 
                      <td className="px-6 py-4 text-center">
                        {isAdmin && (
                          <div className="relative inline-block text-left">
                            <button
                              className="p-2 rounded hover:bg-gray-100"
                              onClick={() => setOpenMenuUserId(openMenuUserId === user.userID ? null : user.userID)}
                              aria-label="More actions"
                            >
                              <MoreVertical className="size-5 text-[#3C8C85]" />
                            </button>
                            {openMenuUserId === user.userID && (
                              <div className="origin-top-right absolute right-0 mt-2 w-28 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none z-10">
                                <div className="py-1">
                                  <button
                                    className="w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-[#3C8C85]/10 flex items-center gap-2"
                                    onClick={() => {
                                      setEditUser(user);
                                      setOpenMenuUserId(null);
                                    }}
                                  >
                                    <Edit2 className="size-3.5 text-[#3C8C85]" /> Edit
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
              </tbody>
              </table>
            </div>
 
            {/* Pagination Controls */}
            {filteredUsers.length > USERS_PER_PAGE && (
              <div className="flex justify-end items-center gap-2 mt-4 pr-6">
                <button
                  className="px-3 py-1 rounded bg-gray-200 text-gray-700 text-xs font-medium disabled:opacity-50"
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                >
                  Previous
                </button>
                <span className="text-sm">
                  Page {currentPage} of {Math.ceil(filteredUsers.length / USERS_PER_PAGE)}
                </span>
                <button
                  className="px-3 py-1 rounded bg-gray-200 text-gray-700 text-xs font-medium disabled:opacity-50"
                  onClick={() => setCurrentPage((p) => Math.min(Math.ceil(filteredUsers.length / USERS_PER_PAGE), p + 1))}
                  disabled={currentPage === Math.ceil(filteredUsers.length / USERS_PER_PAGE)}
                >
                  Next
                </button>
              </div>
            )}
          </>
        )}
      </div>
 
      {/* Modals */}
      {showAddModal && (
        <AddUserModal
          onClose={() => setShowAddModal(false)}
          onUserCreated={fetchUsers}
        />
      )}
 
      {editUser && (
        <EditUserModal
          user={editUser}
          onClose={() => setEditUser(null)}
          onUserUpdated={fetchUsers}
        />
      )}
    </div>
  );
}