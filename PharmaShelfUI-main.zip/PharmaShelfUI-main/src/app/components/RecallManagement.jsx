import { useState, useEffect, useCallback, useRef } from "react";
import {
  AlertTriangle,
  Plus,
  Search,
  CheckCircle,
  XCircle,
  MoreVertical,
  Bell,
  RotateCw,
  FileCheck,
  Package,
  Trash2,
  Edit2,
  X,
} from "lucide-react";
import { recallService } from "../../services/recallService";
import { productsService } from "../../services/productsService";
import { batchesService } from "../../services/batchesService";
import { quarantineService } from "../../services/quarantineService";
import { notificationService } from "../../services/notificationService";

const toArray = (data) => Array.isArray(data) ? data : (data ? [data] : []);
const toastMsg = (msg, type = "info") => console.log(`[${type}] ${msg}`);

// CSS for hiding scrollbars while maintaining scroll functionality
const scrollbarHideStyles = `
  .no-scrollbar {
    scrollbar-width: none;
    -ms-overflow-style: none;
  }
  .no-scrollbar::-webkit-scrollbar {
    display: none;
  }
`;

export function RecallManagement() {
  const [activeTab, setActiveTab] = useState("active");
  const [searchQuery, setSearchQuery] = useState("");
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [expandedRecall, setExpandedRecall] = useState(null);
  const [loading, setLoading] = useState(true);
  const [recalls, setRecalls] = useState([]);
  const [products, setProducts] = useState([]);
  const [batches, setBatches] = useState([]);
  const [quarantines, setQuarantines] = useState([]);
  const [openActionMenu, setOpenActionMenu] = useState(null);
  const [evidenceFile, setEvidenceFile] = useState(null);
  const [evidencePreview, setEvidencePreview] = useState(null);
  const [editingRecall, setEditingRecall] = useState(null);
  const actionsMenuRef = useRef(null);

  const [newRecall, setNewRecall] = useState({
    product: "",
    batch: "",
    issuer: "",
    reason: "",
    scope: "FACILITY_WIDE",
    scopeDetails: [],
  });

  // Load recalls, products, and batches from API on mount
  const loadRecalls = useCallback(async () => {
    try {
      setLoading(true);
      const [recallsData, productsData, batchesData, quarantinesData] = await Promise.all([
        recallService.getAll().catch(() => []),
        productsService.getAll().catch(() => []),
        batchesService.getAll().catch(() => []),
        quarantineService.getAll().catch(() => []),
      ]);
      const recalls = toArray(recallsData);
      console.log("Loaded recalls:", recalls);
      console.log("Number of recalls loaded:", recalls.length);
      setRecalls(recalls);
      setProducts(toArray(productsData));
      setBatches(toArray(batchesData));
      setQuarantines(toArray(quarantinesData));
    } catch (err) {
      console.error("Failed to load data:", err);
      toastMsg("Failed to load data", "error");
      setRecalls([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadRecalls();
  }, [loadRecalls]);

  // Handler for Verify & Approve quarantine (set to APPROVED status)
  const handleVerifyAndApprove = async (quarantineId) => {
    try {
      await quarantineService.approveLock(quarantineId, "APPROVED", "Approved by compliance officer");
      toastMsg("Quarantine approved successfully", "success");
      setOpenActionMenu(null);
      await loadRecalls();
    } catch (err) {
      console.error("Failed to approve quarantine:", err);
      toastMsg(err?.message || "Failed to approve quarantine", "error");
    }
  };

  // Handler for Release to Stock (set to RELEASED status)
  const handleReleaseToStock = async (quarantineId) => {
    try {
      await quarantineService.releaseToStock(quarantineId);
      toastMsg("Batch released to stock successfully", "success");
      setOpenActionMenu(null);
      await loadRecalls();
    } catch (err) {
      console.error("Failed to release batch:", err);
      toastMsg(err?.message || "Failed to release batch", "error");
    }
  };

  const affectedDispenses = [
    {
      dispenseId: "DIS-001",
      patientId: "PAT-501",
      ward: "WARD-A1",
      medication: "Losartan 50mg",
      quantity: 30,
      dispensedAt: "2026-03-20",
      dispensedBy: "Nurse Emma",
      status: "NOTIFIED",
    },
    {
      dispenseId: "DIS-002",
      patientId: "PAT-502",
      ward: "WARD-B2",
      medication: "Losartan 50mg",
      quantity: 30,
      dispensedAt: "2026-03-22",
      dispensedBy: "Nurse John",
      status: "RECOVERED",
    },
    {
      dispenseId: "DIS-003",
      patientId: "PAT-503",
      ward: "WARD-A1",
      medication: "Losartan 50mg",
      quantity: 15,
      dispensedAt: "2026-03-21",
      dispensedBy: "Nurse Sarah",
      status: "NOTIFIED",
    },
  ];

  const wardsList = ["WARD-A1", "WARD-A2", "WARD-B1", "WARD-B2", "WARD-C1", "WARD-C2"];

  // Simplified recall creation (kept for future use if needed)
  // const handleCreateRecall = async () => { ... }

  const handleNotifyWards = async (recallId) => {
    try {
      const recall = recalls.find(r => r.recallId === recallId);
      if (!recall) {
        toastMsg("Recall not found", "error");
        return;
      }
      
      // Update recall status
      await recallService.update(recallId, { notifiedWards: true });
      
      // Create notification for wards
      try {
        const notificationData = {
          userId: null, // Will be resolved by the notification service
          title: "⚠️ Ward Notification - Product Recall",
          message: `Critical recall notification for product (Batch ${recall.batchId}). Scope: ${recall.scope}. Please review and take necessary actions.`,
          category: "RECALL",
          severity: "CRITICAL",
          status: "UNREAD",
          createdAt: new Date().toISOString(),
        };
        
        await notificationService.create(notificationData);
        console.log("✅ Notification sent to wards for recall:", recallId);
      } catch (notifErr) {
        console.error("⚠️ Failed to create ward notification:", notifErr);
      }
      
      toastMsg("Wards notified successfully", "success");
      await loadRecalls();
    } catch (err) {
      console.error("Failed to notify wards:", err);
      toastMsg("Failed to notify wards", "error");
    }
  };

  const handleCompleteRecall = async (recallId) => {
    try {
      const recall = recalls.find(r => r.recallId === recallId);
      if (!recall) {
        toastMsg("Recall not found", "error");
        return;
      }
      
      // Use same status values as BatchManagement expects
      await recallService.update(recallId, { status: "COMPLETED" });
      toastMsg("Recall marked as completed", "success");
      await loadRecalls();
    } catch (err) {
      console.error("Failed to complete recall:", err);
      toastMsg("Failed to complete recall", "error");
    }
  };

  const handleDeleteRecall = async (recallId) => {
    if (!window.confirm("Are you sure you want to delete this recall?")) return;
    try {
      await recallService.delete(recallId);
      toastMsg("Recall deleted successfully", "success");
      setOpenActionMenu(null);
      await loadRecalls();
    } catch (err) {
      console.error("Failed to delete recall:", err);
      toastMsg(err?.message || "Failed to delete recall", "error");
    }
  };

  const handleEditRecall = (recall) => {
    setEditingRecall(recall);
    setNewRecall({
      product: recall.productId || "",
      batch: recall.batchId || "",
      issuer: recall.issuedBy || "",
      reason: recall.actionsJSON ? JSON.parse(recall.actionsJSON).reason || "" : "",
      scope: recall.scope || "FACILITY_WIDE",
      scopeDetails: [],
    });
    setEvidencePreview(recall.evidenceURI || null);
    setShowCreateForm(true);
    setOpenActionMenu(null);
  };

  const handleSaveRecall = async () => {
    if (!newRecall.product || !newRecall.batch || !newRecall.issuer) {
      toastMsg("Please fill all required fields", "error");
      return;
    }

    try {
      const selectedBatch = batches.find(b => {
        const batchNum = String(b.batchNumber || b.batchId || "Unknown");
        return batchNum === String(newRecall.batch);
      });
      const batchId = selectedBatch?.batchId || selectedBatch?.id;

      const selectedProduct = products.find(p => {
        const prodVal = String(p.productName || p.name || p.id);
        return prodVal === String(newRecall.product);
      });
      const productId = selectedProduct?.productId || selectedProduct?.id;

      if (!batchId || !productId) {
        toastMsg("Invalid product or batch selection", "error");
        return;
      }

      // Convert evidence file to base64 if provided
      let evidenceURI = null;
      if (evidenceFile) {
        const reader = new FileReader();
        evidenceURI = await new Promise((resolve, reject) => {
          reader.onload = () => resolve(reader.result);
          reader.onerror = () => reject(reader.error);
          reader.readAsDataURL(evidenceFile);
        });
      }

      const recallDTO = {
        productId: productId,
        batchId: batchId,
        issuedBy: newRecall.issuer,
        scope: newRecall.scope,
        actionsJSON: newRecall.reason ? JSON.stringify({ reason: newRecall.reason }) : null,
        status: editingRecall?.status || "ISSUED",
        issuedAt: editingRecall?.issuedAt || new Date().toISOString().split('T')[0],
        evidenceURI: evidenceURI || null
      };

      if (editingRecall) {
        await recallService.update(editingRecall.recallId, recallDTO);
        toastMsg("Recall updated successfully", "success");
      } else {
        await recallService.create(recallDTO);
        try {
          const notificationData = {
            userId: null,
            title: "🚨 New Recall Issued",
            message: `Product ${newRecall.product} (Batch ${newRecall.batch}) has been recalled by ${newRecall.issuer}. Reason: ${newRecall.reason || 'N/A'}`,
            category: "RECALL",
            severity: "CRITICAL",
            status: "UNREAD",
            createdAt: new Date().toISOString(),
          };
          await notificationService.create(notificationData);
        } catch (notifErr) {
          console.error("⚠️ Failed to create notification:", notifErr);
        }
        toastMsg("Recall issued successfully", "success");
      }
      
      setShowCreateForm(false);
      setEditingRecall(null);
      setNewRecall({
        product: "",
        batch: "",
        issuer: "",
        reason: "",
        scope: "FACILITY_WIDE",
        scopeDetails: [],
      });
      setEvidenceFile(null);
      setEvidencePreview(null);
      await loadRecalls();
    } catch (err) {
      console.error("Failed to save recall:", err);
      toastMsg(err?.message || "Failed to save recall", "error");
    }
  };

  const filteredRecalls = recalls.filter((recall) => {
    const statusUpper = String(recall.status || "").toUpperCase();
    const matchesTab =
      activeTab === "active"
        ? (statusUpper === "ISSUED" || statusUpper === "ACTIVE" || statusUpper === "IN_PROGRESS" || statusUpper === "OPEN")
        : statusUpper === "COMPLETED";
    const matchesSearch =
      searchQuery === "" ||
      (recall.productId || "").toString().toLowerCase().includes(searchQuery.toLowerCase()) ||
      (recall.batchId || "").toString().toLowerCase().includes(searchQuery.toLowerCase());
    if (!matchesTab) {
      console.log(`Recall ${recall.recallId} filtered out: status="${recall.status}" doesn't match tab="${activeTab}"`);
    }
    return matchesTab && matchesSearch;
  });
  console.log(`Active tab: ${activeTab}, Total recalls: ${recalls.length}, Filtered recalls: ${filteredRecalls.length}`);

  const getStatusBadge = (status) => {
    const statusUpper = String(status || "").toUpperCase();
    const styles = {
      ISSUED: "bg-red-100 text-red-700",
      ACTIVE: "bg-red-100 text-red-700",
      "IN_PROGRESS": "bg-yellow-100 text-yellow-700",
      OPEN: "bg-red-100 text-red-700",
      COMPLETED: "bg-green-100 text-green-700",
      CANCELLED: "bg-gray-100 text-gray-700",
    };
    return styles[statusUpper] || styles.ACTIVE;
  };

  const getRecoveryPercentage = (affected, recovered) => {
    return affected === 0 ? 0 : Math.round((recovered / affected) * 100);
  };

  return (
    <div className="space-y-6 p-6">
      <style>{scrollbarHideStyles}</style>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Quarantine & Recall Management</h1>
          <p className="text-gray-600 mt-1">Track, manage, and recover quarantined items and recalled medications</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={loadRecalls}
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-lg font-medium"
          >
            <RotateCw className="size-5" />
            Refresh
          </button>
          <button
            onClick={() => setShowCreateForm(!showCreateForm)}
            className="flex items-center justify-center w-10 h-10 bg-[#3C8C85] hover:bg-[#2E6F6A] text-white rounded-lg font-medium"
            title="Upload Evidence"
          >
            <Plus className="size-5" />
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Quarantined Items</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{quarantines.length}</p>
            </div>
            <div className="bg-orange-500 p-3 rounded-lg">
              <AlertTriangle className="size-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Active Recalls</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{recalls.filter(r => r.status === "ACTIVE").length}</p>
            </div>
            <div className="bg-red-500 p-3 rounded-lg">
              <XCircle className="size-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Evidence Pending</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{recalls.filter(r => r.status === "PENDING_EVIDENCE").length}</p>
            </div>
            <div className="bg-purple-500 p-3 rounded-lg">
              <FileCheck className="size-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Total Details</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{recalls.length}</p>
            </div>
            <div className="bg-green-500 p-3 rounded-lg">
              <Package className="size-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Create/Edit Recall Form Modal */}
      {showCreateForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full my-4 flex flex-col">
            <div className="px-6 py-4 border-b bg-[#3C8C85] text-white rounded-t-xl flex items-center justify-between flex-shrink-0">
              <h3 className="font-semibold text-lg flex items-center gap-2">
                <Plus className="size-5" /> {editingRecall ? 'Edit Recall' : 'Issue New Recall'}
              </h3>
              <button 
                onClick={() => {
                  setShowCreateForm(false);
                  setEditingRecall(null);
                  setEvidenceFile(null);
                  setEvidencePreview(null);
                }} 
                className="text-white/80 hover:text-white text-xl"
              >
                &times;
              </button>
            </div>
            <div className="p-6 space-y-4 overflow-y-auto" style={{maxHeight: 'calc(90vh - 120px)'}}>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-2">
                    Product Name *
                  </label>
                  <select
                    value={newRecall.product}
                    onChange={(e) =>
                      setNewRecall({ ...newRecall, product: e.target.value })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#3C8C85]"
                  >
                    <option value="">Select Product</option>
                    {products.map((p) => (
                      <option key={p.productId || p.id} value={p.productName || p.name || p.id}>
                        {p.productName || p.name || "Unknown"} {p.strength ? `(${p.strength})` : ""}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-2">
                    Batch Number *
                  </label>
                  <select
                    value={newRecall.batch}
                    onChange={(e) =>
                      setNewRecall({ ...newRecall, batch: e.target.value })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#3C8C85]"
                  >
                    <option value="">Select Batch</option>
                    {batches.map((b) => {
                      const batchNum = b.batchNumber || b.batchId || "Unknown";
                      const expiry = b.expiryDate ? new Date(b.expiryDate).toLocaleDateString("en-IN") : "N/A";
                      const qty = b.quantity || "0";
                      return (
                        <option key={b.batchId || b.id} value={batchNum}>
                          {batchNum} (Exp: {expiry}, Qty: {qty})
                        </option>
                      );
                    })}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-2">
                    Issuing Authority *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., FDA, EMA, WHO"
                    value={newRecall.issuer}
                    onChange={(e) =>
                      setNewRecall({ ...newRecall, issuer: e.target.value })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#3C8C85]"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-2">
                    Scope *
                  </label>
                  <select
                    value={newRecall.scope}
                    onChange={(e) =>
                      setNewRecall({ ...newRecall, scope: e.target.value })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#3C8C85]"
                  >
                    <option value="FACILITY_WIDE">Facility Wide</option>
                    <option value="SPECIFIC_WARDS">Specific Wards</option>
                    <option value="SPECIFIC_PATIENTS">Specific Patients</option>
                  </select>
                </div>
                <div className="col-span-2">
                  <label className="text-sm font-medium text-gray-700 block mb-2">
                    Reason for Recall *
                  </label>
                  <textarea
                    placeholder="Describe the reason for this recall..."
                    value={newRecall.reason}
                    onChange={(e) =>
                      setNewRecall({ ...newRecall, reason: e.target.value })
                    }
                    rows="3"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#3C8C85]"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Evidence Photo (Optional - JPG/PNG, max 5MB)
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-[#3C8C85] transition-colors cursor-pointer"
                    onClick={() => document.getElementById("recallEvidenceInput").click()}
                  >
                    {evidencePreview ? (
                      <div className="space-y-3">
                        <img src={evidencePreview} alt="Preview" className="w-full h-32 object-cover rounded-lg" />
                        <p className="text-xs text-gray-500">Click to change</p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <Plus className="size-6 text-gray-400 mx-auto" />
                        <p className="text-sm text-gray-600">Click to upload evidence</p>
                        <p className="text-xs text-gray-500">JPG, PNG • Max 5MB</p>
                      </div>
                    )}
                  </div>
                  <input
                    id="recallEvidenceInput"
                    type="file"
                    accept="image/jpeg,image/png"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        if (file.size > 5 * 1024 * 1024) {
                          toastMsg("File size must be less than 5MB", "error");
                          return;
                        }
                        setEvidenceFile(file);
                        const reader = new FileReader();
                        reader.onloadend = () => setEvidencePreview(reader.result);
                        reader.readAsDataURL(file);
                      }
                    }}
                    className="hidden"
                  />
                </div>
              </div>
            </div>
            <div className="flex gap-3 p-6 border-t bg-gray-50 rounded-b-xl flex-shrink-0">
              <button
                onClick={() => {
                  setShowCreateForm(false);
                  setEditingRecall(null);
                  setEvidenceFile(null);
                  setEvidencePreview(null);
                }}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveRecall}
                className="flex-1 px-4 py-2 bg-[#3C8C85] hover:bg-[#2E6F6A] text-white rounded-lg text-sm font-medium transition-colors"
              >
                {editingRecall ? 'Update Recall' : 'Issue Recall'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-0 border-b border-gray-200">
        <button
          onClick={() => setActiveTab("quarantined")}
          className={`px-6 py-3 font-medium text-sm transition-all ${
            activeTab === "quarantined"
              ? "text-[#3C8C85] border-b-2 border-[#3C8C85]"
              : "text-gray-600 hover:text-gray-900"
          }`}
        >
          Quarantine List ({quarantines.length})
        </button>
        <button
          onClick={() => setActiveTab("active")}
          className={`px-6 py-3 font-medium text-sm transition-all ${
            activeTab === "active"
              ? "text-[#3C8C85] border-b-2 border-[#3C8C85]"
              : "text-gray-600 hover:text-gray-900"
          }`}
        >
          Active Recalls ({recalls.filter((r) => {
            const s = String(r.status || "").toUpperCase();
            return s === "ISSUED" || s === "ACTIVE" || s === "IN_PROGRESS" || s === "OPEN";
          }).length})
        </button>
        <button
          onClick={() => setActiveTab("completed")}
          className={`px-6 py-3 font-medium text-sm transition-all ${
            activeTab === "completed"
              ? "text-[#3C8C85] border-b-2 border-[#3C8C85]"
              : "text-gray-600 hover:text-gray-900"
          }`}
        >
          Completed ({recalls.filter((r) => String(r.status || "").toUpperCase() === "COMPLETED").length})
        </button>
      </div>

      {/* Search */}
      <div className="flex gap-3">
        <div className="flex-1 max-w-xs">
          <div className="relative">
            <Search className="absolute left-3 top-3 size-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search by product or batch..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#3C8C85]"
            />
          </div>
        </div>
      </div>

      {/* Recalls List */}
      <div className="space-y-4">
        {activeTab !== "quarantined" && filteredRecalls.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            {/* Table Header */}
            <div className="px-6 py-4 grid grid-cols-5 gap-4 text-xs font-bold uppercase tracking-wider text-white" style={{backgroundColor: '#3C8C85'}}>
              <div>BATCH ID</div>
              <div>ISSUED BY</div>
              <div>SCOPE</div>
              <div>STATUS</div>
              <div className="text-right">ACTIONS</div>
            </div>

            {/* Table Rows */}
            <div className="divide-y divide-gray-200">
              {filteredRecalls.map((recall) => (
                <div key={recall.recallId}>
                  <div
                    className="px-6 py-4 grid grid-cols-5 gap-4 hover:bg-gray-50 items-center cursor-pointer"
                    onClick={() =>
                      setExpandedRecall(
                        expandedRecall === recall.recallId ? null : recall.recallId
                      )
                    }
                  >
                    {/* Batch ID */}
                    <div className="font-mono font-semibold text-gray-900">
                      {recall.batchId || "-"}
                    </div>

                    {/* Issued By */}
                    <div className="text-sm text-gray-700">
                      {recall.issuedBy || "-"}
                    </div>

                    {/* Scope */}
                    <div className="text-sm text-gray-600">
                      {(recall.scope || "").replace(/_/g, " ") || "-"}
                    </div>

                    {/* Status */}
                    <div>
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusBadge(recall.status)}`}>
                        {recall.status}
                      </span>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center justify-end">
                      <div className="relative inline-block">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setOpenActionMenu(
                              openActionMenu === recall.recallId ? null : recall.recallId
                            );
                          }}
                          className="p-1.5 rounded hover:bg-gray-100 text-gray-600 hover:text-gray-800"
                        >
                          <MoreVertical size={16} />
                        </button>
                        {openActionMenu === recall.recallId && (
                          <div
                            ref={actionsMenuRef}
                            className="w-28 bg-white border border-gray-200 rounded-lg shadow-lg overflow-hidden absolute right-0 top-full mt-1 z-50"
                          >
                            <button
                              onClick={() => { handleEditRecall(recall); }}
                              className="w-full px-3 py-1.5 text-left text-xs font-normal text-gray-700 hover:bg-blue-50 flex items-center gap-1.5 whitespace-nowrap"
                            >
                              <Edit2 size={12} className="text-blue-600 shrink-0" /> Edit
                            </button>
                            <button
                              onClick={() => { handleDeleteRecall(recall.recallId); }}
                              className="w-full px-3 py-1.5 text-left text-xs font-normal text-red-600 hover:bg-red-50 flex items-center gap-1.5 whitespace-nowrap border-t border-gray-200"
                            >
                              <Trash2 size={12} className="shrink-0" /> Delete
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Expanded Details */}
        {activeTab !== "quarantined" && filteredRecalls.map((recall) => (
          expandedRecall === recall.recallId && (
            <div
              key={`details-${recall.recallId}`}
              className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden"
            >
              <div className="p-6 bg-gray-50 space-y-6">
                {/* Recall Information */}
                <div>
                  <h3 className="font-semibold text-gray-900 mb-4">
                    Recall Information
                  </h3>
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <p className="text-sm text-gray-600">Issuer</p>
                      <p className="font-medium text-gray-900">
                        {recall.issuedBy || "-"}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Issued Date</p>
                      <p className="font-medium text-gray-900">
                        {recall.issuedAt}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Scope</p>
                      <p className="font-medium text-gray-900">
                        {recall.scope.replace(/_/g, " ")}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Evidence URI</p>
                      <p className="font-medium text-gray-900 text-xs break-all">
                        {recall.evidenceURI ? recall.evidenceURI.substring(0, 50) + '...' : "-"}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Actions JSON</p>
                      <p className="font-medium text-gray-900 text-xs break-all">
                        {recall.actionsJSON ? recall.actionsJSON.substring(0, 50) + (recall.actionsJSON.length > 50 ? '...' : '') : "-"}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Recall Details */}
                <div>
                  <h3 className="font-semibold text-gray-900 mb-4">
                    Batch & Product Information
                  </h3>
                  <div className="bg-white p-4 rounded-lg space-y-4">
                    <div>
                      <p className="text-sm text-gray-600">Batch ID</p>
                      <p className="font-medium text-gray-900">{recall.batchId || "-"}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Product ID</p>
                      <p className="font-medium text-gray-900">{recall.productId || "-"}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Current Status</p>
                      <p className="font-medium">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusBadge(recall.status)}`}>
                          {recall.status || "-"}
                        </span>
                      </p>
                    </div>
                  </div>
                </div>

                {/* Affected Dispensing */}
                <div>
                  <h3 className="font-semibold text-gray-900 mb-4">
                    Affected Dispensing Records
                  </h3>
                  <div className="bg-white rounded-lg overflow-hidden border border-gray-200">
                    <table className="w-full text-sm">
                      <thead className="bg-gray-50 border-b border-gray-200">
                        <tr>
                          <th className="px-4 py-3 text-left font-semibold text-gray-900">
                            Patient ID
                          </th>
                          <th className="px-4 py-3 text-left font-semibold text-gray-900">
                            Ward
                          </th>
                          <th className="px-4 py-3 text-left font-semibold text-gray-900">
                            Quantity
                          </th>
                          <th className="px-4 py-3 text-left font-semibold text-gray-900">
                            Dispensed Date
                          </th>
                          <th className="px-4 py-3 text-left font-semibold text-gray-900">
                            Status
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {affectedDispenses.map((disp) => (
                          <tr
                            key={disp.dispenseId}
                            className="border-b border-gray-200 hover:bg-gray-50"
                          >
                            <td className="px-4 py-3 text-gray-900">
                              {disp.patientId}
                            </td>
                            <td className="px-4 py-3 text-gray-900">
                              {disp.ward}
                            </td>
                            <td className="px-4 py-3 text-gray-900">
                              {disp.quantity} units
                            </td>
                            <td className="px-4 py-3 text-gray-600">
                              {disp.dispensedAt}
                            </td>
                            <td className="px-4 py-3">
                              <span
                                className={`px-2 py-1 rounded text-xs font-semibold ${
                                  disp.status === "RECOVERED"
                                    ? "bg-green-100 text-green-700"
                                    : "bg-orange-100 text-orange-700"
                                }`}
                              >
                                {disp.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Actions */}
                {recall.status === "ACTIVE" && (
                  <div className="flex gap-3">
                    {!recall.notifiedWards && (
                      <button
                        onClick={() => handleNotifyWards(recall.recallId)}
                        className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium"
                      >
                        <Bell className="size-4" />
                        Notify Wards
                      </button>
                    )}
                    {recall.notifiedWards && (
                      <div className="flex items-center gap-2 px-4 py-2 bg-green-100 text-green-700 rounded-lg text-sm font-medium">
                        <CheckCircle className="size-4" />
                        Wards Notified
                      </div>
                    )}
                    <button
                      onClick={() => handleCompleteRecall(recall.recallId)}
                      className="flex items-center gap-2 px-4 py-2 bg-[#3C8C85] hover:bg-[#2E6F6A] text-white rounded-lg text-sm font-medium"
                    >
                      <FileCheck className="size-4" />
                      Complete Recall
                    </button>
                  </div>
                )}
              </div>
            </div>
          )
        ))}
      </div>

      <>
        {/* Quarantine List Tab */}
        {activeTab === "quarantined" && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="p-6 border-b border-gray-200 bg-[#3C8C85]/10">
              <h2 className="text-lg font-semibold text-gray-900">Quarantine List</h2>
              <p className="text-sm text-gray-600 mt-1">Review and manage quarantined batches</p>
            </div>
            {quarantines.length > 0 ? (
              <div className="overflow-x-auto no-scrollbar relative">
                <table className="w-full">
                  <thead>
                    <tr style={{backgroundColor: '#3C8C85'}} className="border-b border-gray-200">
                      <th className="px-6 py-3 text-left text-xs font-semibold text-white uppercase tracking-wide">Product</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-white uppercase tracking-wide">Batch ID</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-white uppercase tracking-wide">Expiry Date</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-white uppercase tracking-wide">Quarantined By</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-white uppercase tracking-wide">Reason</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-white uppercase tracking-wide">Date Quarantined</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-white uppercase tracking-wide">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-white uppercase tracking-wide">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {quarantines.map((q, index) => {
                      const quarantine = q.quarantine || q; // Handle both nested and flat structures
                      const batchInfo = batches.find(b => b.batchId == quarantine.batchId || b.id == quarantine.batchId);
                      const productInfo = products.find(p => p.productId == batchInfo?.productId || p.id == batchInfo?.productId);
                      const qId = quarantine.quarantineId || quarantine.id;
                      
                      return (
                        <tr key={qId || index} className="hover:bg-gray-50 transition-colors">
                          <td className="px-6 py-4 text-sm text-gray-900">
                            {productInfo?.productName || productInfo?.name || batchInfo?.productName || "Unknown"}
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-600">
                            {batchInfo?.batchNumber || batchInfo?.batchId || quarantine.batchId}
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-600">
                            {batchInfo?.expiryDate ? new Date(batchInfo.expiryDate).toLocaleDateString("en-IN") : "-"}
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-600">
                            {quarantine.quarantinedBy || "System"}
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-600">
                            {quarantine.reason}
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-600">
                            {quarantine.quarantinedAt ? new Date(quarantine.quarantinedAt).toLocaleDateString("en-IN") : "-"}
                          </td>
                          <td className="px-6 py-4 text-sm">
                            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-yellow-100 text-yellow-700">
                              {quarantine.status || "QUARANTINED"}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm">
                            <div className="relative">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setOpenActionMenu(openActionMenu === qId ? null : qId);
                                }}
                                className="p-1.5 rounded hover:bg-gray-100 text-gray-600 hover:text-gray-800 transition-colors"
                              >
                                <MoreVertical size={16} />
                              </button>
                              {openActionMenu === qId && (
                                <div
                                  className="absolute right-0 mt-1 w-44 bg-white border border-gray-200 rounded-lg shadow-xl overflow-hidden z-50"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <button
                                    onClick={() => handleVerifyAndApprove(qId)}
                                    className="w-full px-4 py-2.5 text-left text-xs font-normal text-gray-700 hover:bg-blue-50 flex items-center gap-2 whitespace-nowrap transition-colors"
                                  >
                                    <CheckCircle className="size-4 text-blue-600" />
                                    Verify & Approve
                                  </button>
                                  <button
                                    onClick={() => handleReleaseToStock(qId)}
                                    className="w-full px-4 py-2.5 text-left text-xs font-normal text-gray-700 hover:bg-green-50 border-t border-gray-200 flex items-center gap-2 whitespace-nowrap transition-colors"
                                  >
                                    <Package className="size-4 text-green-600" />
                                    Release to Stock
                                  </button>
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-12">
                <Package className="size-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 font-medium">No quarantined batches</p>
                <p className="text-sm text-gray-500 mt-1">All batches are in good condition</p>
              </div>
            )}
          </div>
        )}

        {activeTab !== "quarantined" && filteredRecalls.length === 0 && (
          <div className="text-center py-12 bg-white rounded-xl border border-gray-200">
            <AlertTriangle className="size-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 font-medium">No recalls found</p>
            <p className="text-sm text-gray-500 mt-1">
              {activeTab === "active"
                ? "Great! No active recalls at this time"
                : "No completed recalls"}
            </p>
          </div>
        )}
      </>
    </div>
  );
}
