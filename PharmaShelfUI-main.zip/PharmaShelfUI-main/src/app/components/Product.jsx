import React, { useState, useRef, useMemo, useEffect } from "react";
import { Search, Plus, MoreVertical, Edit2, Trash2, X, Download, CheckCircle2, XCircle, Layers, Package, Archive, AlertCircle } from "lucide-react";
import { productsAPI } from "../../services/api";
 
const PAGE_SIZE = 7;
 
const PRODUCT_CATEGORIES = [
  "Antibiotics",
  "Analgesics",
  "Antifungals",
  "Antivirals",
  "Cardiovascular",
  "Diabetes",
  "Respiratory",
  "Gastrointestinal",
  "Dermatology",
  "Neurology",
  "Vitamins & Minerals",
  "OTC",
  "Supplements",
];
 
// Simple Excel export utility
const exportToExcel = (data, fileName) => {
  if (!data || data.length === 0) {
    alert("No data to export");
    return;
  }
  const headers = Object.keys(data[0]);
  let csv = headers.join(",") + "\n";
  data.forEach(row => {
    csv += headers.map(header => {
      let value = row[header];
      if (value === null || value === undefined) value = "";
      if (String(value).includes(",") || String(value).includes('"')) {
        value = '"' + String(value).replace(/"/g, '""') + '"';
      }
      return value;
    }).join(",") + "\n";
  });
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);
  link.setAttribute("href", url);
  link.setAttribute("download", fileName + ".csv");
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
 
export default function Product({ allProducts, allBatches, onDataChange, showToast }) {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const [openActionsMenu, setOpenActionsMenu] = useState(null);
  const actionsMenuRef = useRef(null);
  const actionsTriggerRef = useRef(null);
 
  const defaultForm = {
    name: "",
    genericName: "",
    category: "Antibiotics",
    strength: "",
    formulation: "Tablet",
    uom: "Unit",
    storageCondition: "Room Temperature",
    status: "ACTIVE",
  };
 
  useEffect(() => {
    function handleClickOutside(e) {
      if (
        actionsMenuRef.current && !actionsMenuRef.current.contains(e.target) &&
        actionsTriggerRef.current !== e.target && !actionsTriggerRef.current?.contains(e.target)
      ) {
        setOpenActionsMenu(null);
      }
    }
    if (openActionsMenu?.id != null) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [openActionsMenu]);
 
  const resetForm = () => {
    setNameError("");
    setGenericNameError("");
    setStrengthError("");
    if (editingProduct) {
      setForm({
        name: editingProduct.name || "",
        genericName: editingProduct.genericName || "",
        category: editingProduct.category || "Antibiotics",
        strength: editingProduct.strength || "",
        formulation: editingProduct.formulation || "Tablet",
        uom: editingProduct.uom || "Unit",
        storageCondition: editingProduct.storageCondition || "Room Temperature",
        status: editingProduct.status || "ACTIVE",
      });
    } else {
      setForm(defaultForm);
    }
  };
 
  const [form, setForm] = useState({
    name: "",
    genericName: "",
    category: "Antibiotics",
    strength: "",
    formulation: "Tablet",
    uom: "Unit",
    storageCondition: "Room Temperature",
    status: "ACTIVE",
  });
  const [nameError, setNameError] = useState("");
  const [genericNameError, setGenericNameError] = useState("");
  const [strengthError, setStrengthError] = useState("");
 
  // Validation regex: only alphabets, numbers, spaces, hyphens, and forward slashes
  const alphanumericSpaceRegex = /^[a-zA-Z0-9\s\-/]*$/;
 
  const validateProductName = (value) => {
    if (!value.trim()) {
      setNameError("Product Name is required.");
      return false;
    }
    if (!alphanumericSpaceRegex.test(value)) {
      setNameError("Cannot enter special characters");
      return false;
    }
    setNameError("");
    return true;
  };
 
  const validateGenericName = (value) => {
    if (value && !alphanumericSpaceRegex.test(value)) {
      setGenericNameError("Cannot enter special characters");
      return false;
    }
    setGenericNameError("");
    return true;
  };
 
  const validateStrength = (value) => {
    if (value && !alphanumericSpaceRegex.test(value)) {
      setStrengthError("Cannot enter special characters");
      return false;
    }
    setStrengthError("");
    return true;
  };
 
  const getProductId = (product) => product?.productId ?? product?.id;
 
  const createSkuFromName = (name) => {
    const cleaned = String(name || "")
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, "")
      .slice(0, 6);
    return `${cleaned || "PRD"}-${Date.now().toString().slice(-6)}`;
  };
 
  const filteredProducts = useMemo(() => {
    return (allProducts || []).filter((p) => {
      const matchesSearch = !searchQuery || (p.name || "").toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = filterCategory === "all" || p.category === filterCategory;
      const matchesStatus = filterStatus === "all" || (p.status || "").toUpperCase() === filterStatus.toUpperCase();
      return matchesSearch && matchesCategory && matchesStatus;
    });
  }, [allProducts, searchQuery, filterCategory, filterStatus]);
 
  const totalPages = Math.max(1, Math.ceil(filteredProducts.length / PAGE_SIZE));
  const safePage = Math.min(Math.max(1, currentPage), totalPages);
  const start = (safePage - 1) * PAGE_SIZE;
  const paginatedProducts = filteredProducts.slice(start, start + PAGE_SIZE);
 
  const activeProductsCount = (allProducts || []).filter(p => String(p.status || "").toUpperCase() === "ACTIVE").length;
 
  function getActiveBatchesForProduct(productId) {
    return (allBatches || []).filter(b => Number(b.productId) === Number(productId) && String(b.status || "").toUpperCase() === "ACTIVE").length;
  }
 
  function openAdd() {
    setEditingProduct(null);
    setForm({
      name: "",
      genericName: "",
      category: "Antibiotics",
      strength: "",
      formulation: "Tablet",
      uom: "Unit",
      storageCondition: "Room Temperature",
      status: "ACTIVE",
    });
    setShowModal(true);
  }
 
  function openEdit(product) {
    setEditingProduct(product);
    setForm({
      name: product.name || "",
      genericName: product.genericName || "",
      category: product.category || "Antibiotics",
      strength: product.strength || "",
      formulation: product.formulation || "Tablet",
      uom: product.uom || "Unit",
      storageCondition: product.storageCondition || "Room Temperature",
      status: product.status || "ACTIVE",
    });
    setShowModal(true);
  }
 
  async function handleSave() {
    // Validate all required fields
    const isNameValid = validateProductName(form.name);
    const isGenericValid = validateGenericName(form.genericName);
    const isStrengthValid = validateStrength(form.strength);
   
    if (!isNameValid || !form.category) {
      if (!form.category) {
        showToast("Category is required.", "error");
      }
      return;
    }
    setSaving(true);
    try {
      const payload = {
        sku: editingProduct ? (editingProduct.sku || createSkuFromName(form.name)) : createSkuFromName(form.name),
        name: form.name.trim(),
        genericName: form.genericName.trim() || form.name.trim(),
        category: form.category,
        strength: form.strength || "",
        formulation: form.formulation || "Tablet",
        uom: form.uom || "Unit",
        storageCondition: form.storageCondition || "Room Temperature",
        status: form.status,
      };
 
      if (editingProduct) {
        await productsAPI.update(getProductId(editingProduct), payload);
        showToast("Product updated successfully!", "success");
      } else {
        await productsAPI.create(payload);
        showToast("Product added successfully!", "success");
      }
      setShowModal(false);
      onDataChange();
    } catch (e) {
      showToast(`Save failed: ${e.message}`, "error");
    } finally {
      setSaving(false);
    }
  }
 
  async function handleDelete(product) {
    if (!window.confirm(`Delete product "${product.name}"?`)) return;
    setDeleting(getProductId(product));
    try {
      await productsAPI.delete(getProductId(product));
      showToast("Product deleted successfully!", "success");
      onDataChange();
    } catch (e) {
      showToast(`Delete failed: ${e.message}`, "error");
    } finally {
      setDeleting(null);
    }
  }
 
  function handleExport() {
    const exportData = filteredProducts.map(p => ({
      "Product Name": p.name || "",
      "Generic Name": p.genericName || "",
      "Category": p.category || "",
      "Strength": p.strength || "",
      "Formulation": p.formulation || "",
      "UOM": p.uom || "",
      "Storage": p.storageCondition || "",
      "Status": p.status || "",
    }));
    exportToExcel(exportData, "products_" + new Date().toISOString().split('T')[0]);
    showToast("Products exported successfully!", "success");
  }
 
  return (
    <div className="space-y-4">
      {/* Product Catalog Table */}
      <div className="bg-white border rounded-xl overflow-hidden">
      <div className="p-4 border-b flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <h2 className="text-base font-semibold text-gray-900">Product Catalog</h2>
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            onClick={openAdd}
            className="flex items-center justify-center w-8 h-8 bg-[#3C8C85] hover:bg-[#337872] text-white rounded-md text-xs font-medium"
            title="Add Product"
            aria-label="Add Product"
          >
            <Plus size={16} />
          </button>
          <button
            onClick={handleExport}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-xs font-medium"
          >
            Export
          </button>
        </div>
      </div>
 
      {/* Search & Filters */}
      <div className="p-4 bg-gray-50 border-b flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
          <input
            className="w-full pl-8 pr-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#3C8C85]/40"
            placeholder="Search products..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>
        <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)} className="px-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#3C8C85]/40">
          <option value="all">All Categories</option>
          {PRODUCT_CATEGORIES.map((category) => (
            <option key={category} value={category}>{category}</option>
          ))}
        </select>
        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="px-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#3C8C85]/40">
          <option value="all">All Status</option>
          <option value="ACTIVE">Active</option>
          <option value="INACTIVE">Inactive</option>
        </select>
      </div>
 
      {paginatedProducts.length === 0 && (
        <div className="p-6 text-center text-sm text-gray-500">
          No products found.
        </div>
      )}
 
      {paginatedProducts.length > 0 && (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead style={{ background: '#3C8C85' }} className="border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: '#fff' }}>Product Name</th>
                <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: '#fff' }}>Category</th>
                <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: '#fff' }}>Strength</th>
                <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: '#fff' }}>Status</th>
                <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: '#fff' }}>Formulation</th>
                <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: '#fff' }}>Active Batches</th>
                <th className="px-4 py-3 text-center text-xs font-semibold tracking-wider" style={{ color: '#fff' }}>Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {paginatedProducts.map((product) => {
                const productId = getProductId(product);
                const isActive = String(product.status || "").toUpperCase() === "ACTIVE";
                return (
                  <tr key={productId} className="hover:bg-gray-50">
                    <td className="px-4 py-3 text-center text-gray-900 font-medium">{product.name || "-"}</td>
                    <td className="px-4 py-3 text-center text-gray-600">{product.category || "-"}</td>
                    <td className="px-4 py-3 text-center text-gray-600">{product.strength || "-"}</td>
                    <td className="px-4 py-3 text-center">
                      {isActive ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[#3C8C85]/10 text-[#3C8C85] border border-[#3C8C85]/30">
                          <CheckCircle2 className="size-3" /> Active
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-gray-100 text-gray-600 border border-gray-200">
                          <XCircle className="size-3" /> Inactive
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-center text-gray-600">{product.formulation || "-"}</td>
                    <td className="px-4 py-3 text-center">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-[#3C8C85]/10 text-[#3C8C85] border border-[#3C8C85]/30">
                        <Layers className="size-3.5" />
                        {getActiveBatchesForProduct(productId)} active
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="relative inline-block">
                        <button
                          ref={actionsTriggerRef}
                          onClick={(e) => {
                            const rect = e.currentTarget.getBoundingClientRect();
                            const spaceBelow = window.innerHeight - rect.bottom;
                            const dir = spaceBelow < 90 ? 'up' : 'down';
                            setOpenActionsMenu(prev => prev?.id === productId ? null : {
                              id: productId, dir,
                              top: rect.bottom + 4,
                              bottom: window.innerHeight - rect.top + 4,
                              right: window.innerWidth - rect.right,
                            });
                          }}
                          className="p-1.5 rounded hover:bg-gray-100 text-gray-600 hover:text-gray-800"
                        >
                          <MoreVertical size={16} />
                        </button>
                        {openActionsMenu?.id === productId && (
                          <div
                            ref={actionsMenuRef}
                            className="w-28 bg-white border border-gray-200 rounded-lg shadow-lg overflow-hidden"
                            style={{
                              position: 'fixed',
                              zIndex: 9999,
                              right: openActionsMenu.right,
                              ...(openActionsMenu.dir === 'up'
                                ? { bottom: openActionsMenu.bottom }
                                : { top: openActionsMenu.top }),
                            }}
                          >
                            <button
                              onClick={() => { openEdit(product); setOpenActionsMenu(null); }}
                              className="w-full px-3 py-1.5 text-left text-xs font-normal text-gray-700 hover:bg-blue-50 flex items-center gap-1.5 whitespace-nowrap"
                            >
                              <Edit2 size={12} className="text-blue-600 shrink-0" /> Edit
                            </button>
                            <button
                              onClick={() => { handleDelete(product); setOpenActionsMenu(null); }}
                              disabled={deleting === productId}
                              className={`w-full px-3 py-1.5 text-left text-xs font-normal flex items-center gap-1.5 whitespace-nowrap ${deleting === productId ? "text-gray-400 cursor-not-allowed" : "text-red-600 hover:bg-red-50"}`}
                            >
                              <Trash2 size={12} className="shrink-0" /> Delete
                            </button>
                          </div>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
 
      {/* Pagination */}
      <div className="px-4 py-3 border-t border-gray-200 flex items-center justify-end gap-3 bg-gray-50">
        <button
          onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
          disabled={safePage <= 1}
          className="px-3 py-1.5 rounded border border-gray-300 text-gray-700 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-gray-100 text-sm"
        >
          Prev
        </button>
        <span className="text-sm text-gray-700">Page {safePage} / {totalPages}</span>
        <button
          onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
          disabled={safePage >= totalPages}
          className="px-3 py-1.5 rounded border border-gray-300 text-gray-700 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-gray-100 text-sm"
        >
          Next
        </button>
      </div>
 
      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between p-3 border-b flex-shrink-0">
              <h3 className="text-base font-semibold">{editingProduct ? 'Edit Product' : 'Add Product'}</h3>
              <button onClick={() => setShowModal(false)} className="p-1 hover:bg-gray-100 rounded"><X size={18} /></button>
            </div>
            <div className="p-3 space-y-2 overflow-y-auto flex-1">
              <div className="grid gap-3 md:grid-cols-2">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Product Name *</label>
                  <input
                    type="text"
                    placeholder="e.g. Amoxicillin 500mg"
                    value={form.name}
                    onChange={(e) => {
                      const value = e.target.value;
                      setForm(prev => ({ ...prev, name: value }));
                      validateProductName(value);
                    }}
                    className="w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none"
                  />
                  {nameError && <p className="flex items-center gap-1 text-xs mt-1" style={{color:'#dc2626'}}>{nameError}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Generic Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Amoxicillin"
                    value={form.genericName}
                    onChange={(e) => {
                      const value = e.target.value;
                      setForm(prev => ({ ...prev, genericName: value }));
                      validateGenericName(value);
                    }}
                    className="w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none"
                  />
                  {genericNameError && <p className="flex items-center gap-1 text-xs mt-1" style={{color:'#dc2626'}}>{genericNameError}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Category *</label>
                  <select
                    value={form.category}
                    onChange={(e) => setForm(prev => ({ ...prev, category: e.target.value }))}
                    className="w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none"
                  >
                    {PRODUCT_CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Strength</label>
                  <input
                    type="text"
                    placeholder="e.g. 500mg"
                    value={form.strength}
                    onChange={(e) => {
                      const value = e.target.value;
                      setForm(prev => ({ ...prev, strength: value }));
                      validateStrength(value);
                    }}
                    className="w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none"
                  />
                  {strengthError && <p className="flex items-center gap-1 text-xs mt-1" style={{color:'#dc2626'}}>{strengthError}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Formulation</label>
                  <select
                    value={form.formulation}
                    onChange={(e) => setForm(prev => ({ ...prev, formulation: e.target.value }))}
                    className="w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none"
                  >
                    {["Tablet", "Capsule", "Syrup", "Injectable", "Cream", "Ointment", "Drops", "Inhaler", "Patch", "Powder", "Suppository"].map((f) => (
                      <option key={f} value={f}>{f}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Unit of Measure</label>
                  <select
                    value={form.uom}
                    onChange={(e) => setForm(prev => ({ ...prev, uom: e.target.value }))}
                    className="w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none"
                  >
                    {["Unit", "Tablet", "Capsule", "mL", "mg", "Vial", "Ampoule", "Sachet", "Strip", "Bottle", "Tube"].map((u) => (
                      <option key={u} value={u}>{u}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Storage Condition</label>
                  <select
                    value={form.storageCondition}
                    onChange={(e) => setForm(prev => ({ ...prev, storageCondition: e.target.value }))}
                    className="w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none"
                  >
                    {["Room Temperature", "Refrigerated (2–8°C)", "Frozen (-20°C)", "Cool & Dry", "Protected from Light"].map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                  <select
                    value={form.status}
                    onChange={(e) => setForm(prev => ({ ...prev, status: e.target.value }))}
                    className="w-full px-2.5 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85] focus:outline-none"
                  >
                    <option value="ACTIVE">Active</option>
                    <option value="INACTIVE">Inactive</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 p-3 border-t bg-gray-50 flex-shrink-0">
              <button
                onClick={resetForm}
                className="px-4 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-100"
              >
                Reset
              </button>
              <button onClick={handleSave} disabled={saving} className="px-4 py-2 text-sm bg-[#3C8C85] hover:bg-[#337872] text-white rounded-lg disabled:opacity-50">
                {saving ? 'Saving...' : (editingProduct ? 'Update' : 'Create')}
              </button>
            </div>
          </div>
        </div>
      )}
      </div>
    </div>
  );
}