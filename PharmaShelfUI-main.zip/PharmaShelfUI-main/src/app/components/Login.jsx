import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { PillBottle, Eye, EyeOff, ShieldCheck } from "lucide-react";
import { authAPI } from "../../services/api";
import { API_BASE_URL } from "../../services/apiClient";
import { SERVICE_PREFIX, serviceUrl } from "../../services/serviceEndpoints";
import { LOGIN_CONSTANTS } from "../constants/loginConstants";
import { normalizeRole } from "../constants/accessControl";
 
export function Login() {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});
 
  const decodeJWT = (token) => {
    try {
      const payload = token.split(".")[1] || "";
      const normalized = payload.replace(/-/g, "+").replace(/_/g, "/");
      const padded = normalized.padEnd(normalized.length + ((4 - (normalized.length % 4)) % 4), "=");
      return JSON.parse(atob(padded));
    } catch {
      return null;
    }
  };

  const extractRoleFromToken = (decoded) => {
    if (!decoded) return "";

    const directRole = decoded.role || decoded.user?.role;
    if (directRole) return normalizeRole(directRole);

    const roleFromArray =
      (Array.isArray(decoded.roles) && decoded.roles[0]) ||
      (Array.isArray(decoded.authorities) && decoded.authorities[0]) ||
      "";

    if (roleFromArray) return normalizeRole(roleFromArray);

    return "";
  };

  const extractUserIdFromToken = (decoded) => {
    // Spring Security JwtUtil puts userId in the 'userId' claim
    if (decoded?.userId) return decoded.userId;
    
    // Fallback to other possible fields
    return decoded?.userID || 
           decoded?.userid || 
           decoded?.UserID || 
           decoded?.id || 
           decoded?.uid || 
           decoded?.user?.userId || 
           null;
  };
 
  const validateField = (name, value) => {
    let error = "";
    switch (name) {
      case "email":
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
          error = "Invalid email address.";
        }
        break;
      case "password":
        if (value.length < 6) {
          error = "Password must be at least 6 characters long.";
        }
        break;
      default:
        break;
    }
    setErrors((prevErrors) => ({ ...prevErrors, [name]: error }));
  };
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "email") setEmail(value);
    if (name === "password") setPassword(value);
    validateField(name, value);
  };
 
  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setErrors({});

    try {
      const response = await authAPI.login(email, password);
      
      console.log("🔍 Login response:", response);
      
      if (!response || !response.token) {
        console.error("❌ No token in response. Response was:", response);
        throw new Error("No token received from server");
      }
      
      const token = response.token;
      console.log("🔍 Token value:", token);
      console.log("🔍 Token type:", typeof token);
      console.log("🔍 Token length:", token?.length);
      
      // Store token FIRST
      localStorage.setItem("authToken", token);
      console.log("✅ Token stored in localStorage");
      console.log("🔍 Verify stored token:", localStorage.getItem("authToken"));

      const decoded = decodeJWT(token);

      if (decoded) {
        let resolvedUserId = extractUserIdFromToken(decoded);
        const tokenUsername = decoded.sub; // 'sub' contains the username from JwtUtil.setSubject

        if (tokenUsername) {
          try {
            const usersResponse = await fetch(
              `${API_BASE_URL}${serviceUrl(SERVICE_PREFIX.users, "/fetchAllUsers")}`,
              {
                method: "GET",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${token}`,
                },
              }
            );
 
            if (usersResponse.ok) {
              const users = await usersResponse.json();
 
              if (Array.isArray(users)) {
                const matchedUser = users.find(
                  (item) =>
                    String(item.email || "").toLowerCase() ===
                    String(tokenUsername || "").toLowerCase()
                );
 
                const userIdFromLookup =
                  matchedUser?.userID ?? matchedUser?.userId;

                if (userIdFromLookup && !resolvedUserId) {
                  resolvedUserId = userIdFromLookup;
                }

                const resolvedRole =
                  matchedUser?.role ||
                  extractRoleFromToken(decoded);

                localStorage.setItem(
                  "pharmaShelfUser",
                  JSON.stringify({
                    userId: resolvedUserId,
                    email: tokenUsername,
                    name: matchedUser?.name || matchedUser?.firstName || tokenUsername,
                    role: normalizeRole(resolvedRole),
                    loginTime: new Date().toISOString(),
                  })
                );
                
                console.log("✅ User data stored in localStorage");
                navigate("/");
                return;
              }
            }
          } catch (fetchError) {
            console.warn("Could not fetch user details, proceeding with token data", fetchError);
          }
        }

        // Fallback: Store user info from token even if user lookup fails
        localStorage.setItem(
          "pharmaShelfUser",
          JSON.stringify({
            userId: resolvedUserId,
            email: tokenUsername || decoded.sub,
            name: tokenUsername || decoded.sub,
            role: normalizeRole(extractRoleFromToken(decoded)),
            loginTime: new Date().toISOString(),
          })
        );
        
        console.log("✅ User data stored from token claims");
      }
 
      navigate("/");
    } catch (error) {
      console.error("Login error:", error);
      setErrors({ form: error.message || "Invalid email or password" });
    } finally {
      setIsLoading(false);
    }
  };
 
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#e8f3f1] via-white to-[#cbe7e3] flex items-center justify-center p-6">
      <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
 
        {/* Left Side - Branding */}
        <div className="hidden lg:block">
          <div className="bg-gradient-to-br from-[#3C8C85] to-[#2e6a65] rounded-3xl p-12 text-white shadow-2xl">
            <div className="flex items-center gap-4 mb-8">
              <div className="bg-white rounded-2xl p-4">
                <PillBottle className="size-12 text-[#3C8C85]" />
              </div>
              <div>
                <h1 className="text-4xl font-bold">
                  {LOGIN_CONSTANTS.APP_NAME}
                </h1>
                <p className="text-[#b2d6d2] text-lg">
                  {LOGIN_CONSTANTS.APP_TAGLINE}
                </p>
              </div>
            </div>
 
            <div className="space-y-6 mt-12">
              {LOGIN_CONSTANTS.FEATURES.map((item) => (
                <div key={item.title} className="flex items-start gap-4">
                  <div className="bg-[#35736e] rounded-lg p-3">
                    <ShieldCheck className="size-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-1">
                      {item.title}
                    </h3>
                    <p className="text-[#b2d6d2] text-sm">
                      {item.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
 
        {/* Right Side - Login Form */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 lg:p-12">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">
              {LOGIN_CONSTANTS.TITLE}
            </h2>
            <p className="text-gray-600">
              {LOGIN_CONSTANTS.SUBTITLE}
            </p>
          </div>
 
          <form onSubmit={handleLogin} className="space-y-6">
            {/* Form Error Alert */}
            {errors.form && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                <p className="text-sm text-red-600">{errors.form}</p>
              </div>
            )}

            {/* Email */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                {LOGIN_CONSTANTS.EMAIL_LABEL}
              </label>
              <input
                type="email"
                name="email"
                value={email}
                onChange={handleChange}
                placeholder={LOGIN_CONSTANTS.EMAIL_PLACEHOLDER}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3C8C85]"
                required
              />
              {errors.email && (
                <p className="text-xs text-red-600 mt-1">{errors.email}</p>
              )}
            </div>
 
            {/* Password */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                {LOGIN_CONSTANTS.PASSWORD_LABEL}
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  value={password}
                  onChange={handleChange}
                  placeholder={LOGIN_CONSTANTS.PASSWORD_PLACEHOLDER}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg pr-12 focus:ring-2 focus:ring-[#3C8C85]"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
                >
                  {showPassword ? <EyeOff /> : <Eye />}
                </button>
              </div>
              {errors.password && (
                <p className="text-xs text-red-600 mt-1">{errors.password}</p>
              )}
            </div>
 
            {/* Remember / Forgot */}
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="size-4" />
                <span className="text-sm text-gray-700">
                  {LOGIN_CONSTANTS.REMEMBER_ME}
                </span>
              </label>
              <button
                type="button"
                className="text-sm text-[#3C8C85] hover:text-[#35736e]"
              >
                {LOGIN_CONSTANTS.FORGOT_PASSWORD}
              </button>
            </div>
 
            {/* Login Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 bg-gradient-to-r from-[#3C8C85] to-[#35736e] text-white rounded-lg font-semibold disabled:opacity-50 shadow-md hover:brightness-110 transition-all duration-150"
            >
              {isLoading
                ? LOGIN_CONSTANTS.SIGNING_IN
                : LOGIN_CONSTANTS.SIGN_IN}
            </button>
 
            {/* ✅ Sign Up Link */}
            <div className="text-center">
              <p className="text-sm text-gray-600">
                Don&apos;t have an account?{" "}
                <button
                  type="button"
                  onClick={() => navigate("/signup")}
                  className="text-[#3C8C85] hover:text-[#35736e] font-medium"
                >
                  Sign up
                </button>
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}