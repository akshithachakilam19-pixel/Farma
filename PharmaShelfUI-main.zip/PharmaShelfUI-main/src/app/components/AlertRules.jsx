import { useEffect, useRef, useState } from "react";
import { ChevronDown, Plus, X } from "lucide-react";
import { alertRulesAPI } from "../../services/api";
import {
  ALERT_RULES_RECIPIENT_ROLE_OPTIONS,
  ALERT_RULES_SEVERITY_OPTIONS,
  ALERT_RULES_TRIGGER_HELPER_TEXT,
  ALERT_RULES_TRIGGER_TYPE_OPTIONS,
} from "../constants/alertRulesConstants";
 
const emptyForm = {
  name: "",
  triggerExpressionNote: "",
  severity: "WARNING",
  triggerType: "LOW_STOCK",
  recipients: [],
  active: true,
};
 
function getSeverityBadgeClass(severity = "") {
  switch (severity.toUpperCase()) {
    case "CRITICAL":
      return "bg-red-100 text-red-700";
    case "WARNING":
      return "bg-orange-100 text-orange-700";
    case "INFO":
      return "bg-[#e0f4f2] text-[#3C8C85]";
    default:
      return "bg-gray-100 text-gray-700";
  }
}
 
function parseRecipients(recipientsList) {
  if (Array.isArray(recipientsList)) {
    return recipientsList
      .map((entry) => String(entry).trim())
      .filter(Boolean);
  }
 
  if (!recipientsList) return [];
 
  return String(recipientsList)
    .split(",")
    .map((entry) => entry.trim())
    .filter(Boolean);
}
 
function ToggleSwitch({ checked, onChange, disabled = false }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
        checked ? '' : 'bg-gray-300'
      } ${disabled ? "cursor-not-allowed opacity-60" : "cursor-pointer"}`}
      style={checked ? { backgroundColor: '#3C8C85' } : {}}
    >
      <span
        className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${
          checked ? "translate-x-5" : "translate-x-1"
        }`}
      />
    </button>
  );
}
 
export function AlertRules() {
  const [rules, setRules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [togglingRuleId, setTogglingRuleId] = useState(null);
 
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState(emptyForm);
  const [formError, setFormError] = useState("");
  const [recipientsDropdownOpen, setRecipientsDropdownOpen] =
    useState(false);
 
  const recipientsDropdownRef = useRef(null);
 
  const currentUser = JSON.parse(localStorage.getItem("pharmaShelfUser"));
  const isAdmin = currentUser?.role === "ADMINISTRATOR";
 
  const fetchRules = async () => {
    try {
      setLoading(true);
      setError("");
      const data = await alertRulesAPI.getAll();
      setRules(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error(err);
      setError("Failed to load alert rules");
    } finally {
      setLoading(false);
    }
  };
  const [currentPage, setCurrentPage] = useState(1);
  const RULES_PER_PAGE = 10;
 
  useEffect(() => {
    fetchRules();
  }, []);
 
  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (
        recipientsDropdownRef.current &&
        !recipientsDropdownRef.current.contains(event.target)
      ) {
        setRecipientsDropdownOpen(false);
      }
    };
 
    document.addEventListener("mousedown", handleOutsideClick);
    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
    };
  }, []);
 
  const openAddModal = () => {
    setFormData(emptyForm);
    setFormError("");
    setRecipientsDropdownOpen(false);
    setShowModal(true);
  };
 
  const closeModal = () => {
    setShowModal(false);
    setFormData(emptyForm);
    setFormError("");
    setRecipientsDropdownOpen(false);
  };
 
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };
 
  const toggleRecipient = (role) => {
    setFormData((prev) => ({
      ...prev,
      recipients: prev.recipients.includes(role)
        ? prev.recipients.filter((item) => item !== role)
        : [...prev.recipients, role],
    }));
  };
 
  const buildPayload = (nextActiveValue = formData.active) => ({
    name: formData.name.trim(),
    triggerExpressionNote: formData.triggerExpressionNote.trim(),
    severity: formData.severity,
    triggerType: formData.triggerType,
    recipientsList: formData.recipients.join(", "),
    active: nextActiveValue,
  });
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError("");
 
    if (!formData.name.trim()) {
      setFormError("Rule Name is required");
      return;
    }
 
    if (!formData.triggerExpressionNote.trim()) {
      setFormError("Trigger Condition is required");
      return;
    }
 
    if (formData.recipients.length === 0) {
      setFormError("Select at least one recipient role");
      return;
    }
 
    try {
      setSubmitting(true);
      await alertRulesAPI.create(buildPayload());
      closeModal();
      await fetchRules();
    } catch (err) {
      console.error(err);
      setFormError("Failed to save alert rule");
    } finally {
      setSubmitting(false);
    }
  };
 
  const handleToggleActive = async (rule) => {
    if (!isAdmin) return;
 
    const nextActive = !Boolean(rule.active);
 
    try {
      setTogglingRuleId(rule.ruleID);
      await alertRulesAPI.create({
        ruleID: rule.ruleID,
        name: rule.name,
        triggerExpressionNote: rule.triggerExpressionNote,
        severity: rule.severity,
        recipientsList: rule.recipientsList,
        active: nextActive,
      });
 
      setRules((prev) =>
        prev.map((item) =>
          item.ruleID === rule.ruleID
            ? { ...item, active: nextActive }
            : item
        )
      );
    } catch (err) {
      console.error(err);
      setError("Failed to update rule status");
    } finally {
      setTogglingRuleId(null);
    }
  };
 
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            Alert Rules Management
          </h1>
          <p className="text-gray-600 mt-1">
            Configure rule triggers, severity, recipients, and active status
          </p>
        </div>
 
        {isAdmin && (
          <div className="relative group flex items-center">
            <button
              onClick={openAddModal}
              className="flex items-center justify-center w-10 h-10 rounded-lg text-white"
              style={{ backgroundColor: '#3C8C85' }}
              aria-label="Add Alert Rule"
            >
              <Plus className="size-5" />
            </button>
            <div className="absolute left-1/2 -translate-x-1/2 mt-2 z-10 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity bg-gray-900 text-white text-xs rounded py-1 px-2 whitespace-nowrap shadow-lg" style={{top: '100%'}}>
              Add Alert Rule
            </div>
          </div>
        )}
      </div>
 
      <div className="bg-white rounded-xl border overflow-hidden">
        {loading ? (
          <div className="p-6 text-gray-500">Loading alert rules…</div>
        ) : error ? (
          <div className="p-6 text-red-600">{error}</div>
        ) : rules.length === 0 ? (
          <div className="p-6 text-gray-500">No alert rules found</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-semibold">
                    Rule Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold">
                    Trigger Condition
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold">
                    Severity
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold">
                    Recipients
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold">
                    Status
                  </th>
                </tr>
              </thead>
 
              <tbody>
                {rules
                  .slice((currentPage - 1) * RULES_PER_PAGE, currentPage * RULES_PER_PAGE)
                  .map((rule) => {
                    const recipients = parseRecipients(rule.recipientsList);
                    return (
                      <tr key={rule.ruleID} className="border-t align-top">
                        <td className="px-6 py-4 font-medium text-gray-900">
                          {rule.name}
                        </td>
                        <td className="px-6 py-4 text-gray-700">
                          {rule.triggerExpressionNote}
                        </td>
                        <td className="px-6 py-4">
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-semibold ${getSeverityBadgeClass(
                              rule.severity
                            )}`}
                          >
                            {rule.severity}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex flex-wrap gap-2">
                            {recipients.length === 0 ? (
                              <span className="text-xs text-gray-400">-</span>
                            ) : (
                              recipients.map((recipient) => (
                                <span
                                  key={`${rule.ruleID}-${recipient}`}
                                  className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-700"
                                >
                                  {recipient}
                                </span>
                              ))
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <ToggleSwitch
                              checked={Boolean(rule.active)}
                              disabled={togglingRuleId === rule.ruleID || !isAdmin}
                              onChange={() => handleToggleActive(rule)}
                            />
                            <span className="text-xs text-gray-500">
                              {rule.active ? "Active" : "Inactive"}
                            </span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
                  {/* Pagination Controls */}
                  {rules.length > RULES_PER_PAGE && (
                    <div className="flex justify-center items-center gap-2 mt-4">
                      <button
                        className="px-3 py-1 rounded bg-gray-200 text-gray-700 text-xs font-medium disabled:opacity-50"
                        onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                        disabled={currentPage === 1}
                      >
                        Previous
                      </button>
                      <span className="text-sm">
                        Page {currentPage} of {Math.ceil(rules.length / RULES_PER_PAGE)}
                      </span>
                      <button
                        className="px-3 py-1 rounded bg-gray-200 text-gray-700 text-xs font-medium disabled:opacity-50"
                        onClick={() => setCurrentPage((p) => Math.min(Math.ceil(rules.length / RULES_PER_PAGE), p + 1))}
                        disabled={currentPage === Math.ceil(rules.length / RULES_PER_PAGE)}
                      >
                        Next
                      </button>
                    </div>
                  )}
            </table>
          </div>
        )}
      </div>
 
      {showModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-xl p-6 relative">
            <button
              onClick={closeModal}
              className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
            >
              <X className="size-5" />
            </button>
 
            <h2 className="text-xl font-bold mb-4">Add Alert Rule</h2>
 
            {formError && (
              <div className="mb-3 text-sm text-red-600">{formError}</div>
            )}
 
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-sm font-medium">Rule Name</label>
                <input
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:outline-none"
                  style={{ boxShadow: '0 0 0 2px #3C8C85333', outlineColor: '#3C8C85' }}
                  required
                />
              </div>
 
              <div>
                <label className="text-sm font-medium">Trigger Condition</label>
                <input
                  name="triggerExpressionNote"
                  value={formData.triggerExpressionNote}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:outline-none"
                  style={{ boxShadow: '0 0 0 2px #3C8C8533', outlineColor: '#3C8C85' }}
                  required
                />
                <p className="mt-1 text-xs text-gray-500 italic">
                  {ALERT_RULES_TRIGGER_HELPER_TEXT}
                </p>
              </div>
 
              <div>
                <label className="text-sm font-medium">Severity</label>
                <select
                  name="severity"
                  value={formData.severity}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:outline-none"
                  style={{ boxShadow: '0 0 0 2px #3C8C8533', outlineColor: '#3C8C85' }}
                  required
                >
                  {ALERT_RULES_SEVERITY_OPTIONS.map((severity) => (
                    <option key={severity} value={severity}>
                      {severity}
                    </option>
                  ))}
                </select>
              </div>
 
              <div>
                <label className="text-sm font-medium">Trigger Type</label>
                <select
                  name="triggerType"
                  value={formData.triggerType}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:outline-none"
                  style={{ boxShadow: '0 0 0 2px #3C8C8533', outlineColor: '#3C8C85' }}
                  required
                >
                  {ALERT_RULES_TRIGGER_TYPE_OPTIONS.map((type) => (
                    <option key={type} value={type}>
                      {type.replace(/_/g, " ")}
                    </option>
                  ))}
                </select>
              </div>
 
              <div>
                <label className="text-sm font-medium">
                  Recipients (multi-select)
                </label>
                <div className="relative mt-1" ref={recipientsDropdownRef}>
                  <button
                    type="button"
                    onClick={() =>
                      setRecipientsDropdownOpen(
                        (prevOpen) => !prevOpen
                      )
                    }
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm flex items-center justify-between focus:ring-2 focus:outline-none"
                    style={{ boxShadow: '0 0 0 2px #3C8C8533', outlineColor: '#3C8C85' }}
                  >
                    <span className="text-gray-700">
                      {formData.recipients.length > 0
                        ? `${formData.recipients.length} recipient(s) selected`
                        : "Select recipient roles"}
                    </span>
                    <ChevronDown className="size-4 text-gray-500" />
                  </button>
 
                  {recipientsDropdownOpen && (
                    <div className="absolute z-20 mt-1 w-full bg-white border border-gray-300 rounded-lg shadow-lg p-2 max-h-48 overflow-hidden">
                      {ALERT_RULES_RECIPIENT_ROLE_OPTIONS.map((role) => (
                        <label
                          key={role}
                          className="flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-50 cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            checked={formData.recipients.includes(role)}
                            onChange={() => toggleRecipient(role)}
                            className="rounded border-gray-300"
                          />
                          <span className="text-sm text-gray-700">
                            {role}
                          </span>
                        </label>
                      ))}
                    </div>
                  )}
                </div>
              </div>
 
              <div className="flex items-center gap-3">
                <ToggleSwitch
                  checked={formData.active}
                  onChange={(nextValue) =>
                    setFormData((prev) => ({
                      ...prev,
                      active: nextValue,
                    }))
                  }
                />
                <span className="text-sm text-gray-700">Active rule</span>
              </div>
 
              <button
                type="submit"
                disabled={submitting}
                className="w-full mt-2 py-2 text-white rounded-lg disabled:opacity-50"
                style={{ backgroundColor: '#3C8C85' }}
              >
                {submitting ? "Saving..." : "Create Alert Rule"}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}