import { useState } from "react";
import { X } from "lucide-react";
import { usersAPI } from "../../services/api";
import {
  ROLE_DEFINITIONS,
  ASSIGNABLE_ROLES,
} from "../constants/roleConstants";
 
 
export function AddUserModal({ onClose, onUserCreated }) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    role: "",
    password: "",
  });
 
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState({});
 
  const validateField = (name, value) => {
    switch (name) {
      case "name":
        if (!/^[A-Za-z ]*$/.test(value)) {
          return "Name must contain only alphabets and spaces.";
        }
        if (!value.trim()) {
          return "Name is required.";
        }
        return "";
      case "email":
        if (!value.trim()) return "Email is required.";
        // Simple email regex
        if (!/^\S+@\S+\.\S+$/.test(value)) {
          return "Enter a valid email address.";
        }
        return "";
      case "phone":
        if (!value.trim()) return "Phone number is required.";
        if (!/^[0-9]{10,15}$/.test(value)) {
          return "Enter a valid phone number (10-15 digits).";
        }
        return "";
      default:
        return "";
    }
  };
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    setFieldErrors((prev) => ({
      ...prev,
      [name]: validateField(name, value),
    }));
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
 
    // Validate all fields before submit
    const errors = {};
    Object.keys(formData).forEach((key) => {
      if (["name", "email", "phone"].includes(key)) {
        const errMsg = validateField(key, formData[key]);
        if (errMsg) errors[key] = errMsg;
      }
    });
    setFieldErrors(errors);
    if (Object.values(errors).some(Boolean)) return;
 
    setLoading(true);
    try {
      const createdUser = await usersAPI.create(formData);
      onUserCreated(createdUser); // ✅ update table
      onClose();                  // ✅ close modal
    } catch (err) {
      console.error("Create user failed:", err);
      setError("Failed to create user");
    } finally {
      setLoading(false);
    }
  };
 
  const handleReset = () => {
    setFormData({
      name: "",
      email: "",
      phone: "",
      role: "",
      password: "",
    });
    setFieldErrors({});
  };
 
  const inputClass =
    "w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none";
  const errorClass = "text-xs text-red-600 mt-1";
 
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6 relative">
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <X className="size-5" />
        </button>
 
        <h2 className="text-xl font-bold mb-4">
          Add User
        </h2>
 
        {error && (
          <div className="mb-3 text-sm text-red-600">
            {error}
          </div>
        )}
 
        <form onSubmit={handleSubmit} className="space-y-3">
          {/* Name */}
          <div>
            <label className="text-sm font-medium">Name</label>
            <input
              name="name"
              className={inputClass}
              value={formData.name}
              onChange={handleChange}
              required
              autoComplete="off"
              inputMode="text"
              pattern="[A-Za-z ]*"
            />
            {fieldErrors.name && (
              <div className={errorClass}>{fieldErrors.name}</div>
            )}
          </div>
 
          {/* Email */}
          <div>
            <label className="text-sm font-medium">Email</label>
            <input
              name="email"
              type="email"
              className={inputClass}
              value={formData.email}
              onChange={handleChange}
              required
              autoComplete="off"
            />
            {fieldErrors.email && (
              <div className={errorClass}>{fieldErrors.email}</div>
            )}
          </div>
 
          {/* Phone */}
          <div>
            <label className="text-sm font-medium">Phone</label>
            <input
              name="phone"
              className={inputClass}
              value={formData.phone}
              onChange={handleChange}
              required
              autoComplete="off"
              inputMode="numeric"
              pattern="[0-9]{10,15}"
            />
            {fieldErrors.phone && (
              <div className={errorClass}>{fieldErrors.phone}</div>
            )}
          </div>
 
          {/* Role (ENUM SAFE) */}
          <div>
            <label className="text-sm font-medium">Role</label>
            <select
              name="role"
              className={inputClass}
              value={formData.role}
              onChange={handleChange}
              required
            >
              <option value="">Select Role</option>
              {ASSIGNABLE_ROLES.map((role) => (
                <option key={role} value={role}>
                  {ROLE_DEFINITIONS[role].label}
                </option>
              ))}
            </select>
          </div>
 
          {/* Password */}
          <div>
            <label className="text-sm font-medium">Password</label>
            <input
              name="password"
              type="password"
              className={inputClass}
              onChange={handleChange}
              required
            />
          </div>
 
          <div className="flex justify-between mt-4">
            <button
              type="submit"
              disabled={loading}
              className="w-[48%] py-2 bg-[#3C8C85] text-white rounded-lg hover:bg-[#36766F] disabled:opacity-50"
            >
              {loading ? "Creating..." : "Create"}
            </button>
            <button
              type="button"
              onClick={handleReset}
              className="w-[48%] py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400"
            >
              Reset
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}