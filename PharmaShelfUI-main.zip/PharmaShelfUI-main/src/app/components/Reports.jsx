import React, { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  RefreshCw, Download, FileText, Eye, Trash2, Play, ChevronLeft, ChevronRight,
  AlertTriangle, TrendingDown, Activity, CheckCircle, MoreVertical, ArrowLeft, XCircle, ThumbsUp, ThumbsDown
} from "lucide-react";
import { reportsAPI } from "../../services/reportsService";
import { productsAPI } from "../../services/productsService";
import { batchesAPI } from "../../services/batchesService";
import { dispensingAPI } from "../../services/dispensingService";
import { returnAPI } from "../../services/returnService";
import { recallAPI } from "../../services/recallService";
 
// Report categories — Stock Valuation removed
const REPORT_CATEGORIES = [
  {
    id: "EXPIRY",
    name: "Expiry",
    display: "Expiry Report",
    icon: AlertTriangle,
    color: "bg-red-500",
    description: "Medicines nearing expiry",
  },
  {
    id: "CONSUMPTION",
    name: "Consumption",
    display: "Consumption Report",
    icon: TrendingDown,
    color: "bg-blue-500",
    description: "Usage analytics by ward/period",
  },
  {
    id: "RECALL",
    name: "Recall",
    display: "Recall Logs",
    icon: Activity,
    color: "bg-amber-500",
    description: "Compliance and recall events",
  },
];
 
const SCOPE_PARAMETERS = {
  EXPIRY: [
    { key: "startDate", label: "Start Date", type: "date", required: true },
    { key: "endDate", label: "End Date", type: "date", required: true },
  ],
  CONSUMPTION: [
    { key: "startDate", label: "Start Date", type: "date", required: true },
    { key: "endDate", label: "End Date", type: "date", required: true },
  ],
  RECALL: [
    { key: "startDate", label: "Start Date", type: "date", required: true },
    { key: "endDate", label: "End Date", type: "date", required: true },
  ],
};
 
const getBatchField = (batch, keys, fallback = "") => {
  for (const key of keys) {
    const value = key.split(".").reduce((acc, part) => acc?.[part], batch);
    if (value !== undefined && value !== null && String(value).trim() !== "") return value;
  }
  return fallback;
};
 
const normalizeBatchRecord = (batch) => {
  const productName = getBatchField(batch, [
    "productName", "product.name", "medicineName", "itemName", "name", "product.productName",
  ], "—");
  const batchNo = getBatchField(batch, [
    "batchNo", "batchNumber", "lotNo", "lotNumber", "batch.number", "batch.id",
  ], "—");
  const expiryValue = getBatchField(batch, [
    "expiryDate", "expiry", "expDate", "expirationDate", "expiry_date",
  ], null);
 
  return { productName, batchNo, expiryValue };
};
 
const getDaysToExpiry = (expiryValue) => {
  const expiryDate = new Date(expiryValue);
  if (Number.isNaN(expiryDate.getTime())) return null;
  return Math.ceil((expiryDate - new Date()) / (1000 * 60 * 60 * 24));
};
 
const getExpiryStatus = (daysToExpiry) => {
  if (daysToExpiry === null) return "Unknown";
  if (daysToExpiry <= 0) return "Expired";
  if (daysToExpiry <= 30) return "Critical";
  if (daysToExpiry <= 60) return "Warning";
  return "Safe";
};
 
const formatDateTime = (v) => {
  // Always use current time for display
  const d = new Date();
  return d.toLocaleDateString("en-IN", { 
    year: "numeric", 
    month: "short", 
    day: "numeric", 
    hour: "2-digit", 
    minute: "2-digit",
    second: "2-digit"
  });
};
 
export function ReportManagement() {
  const toArray = (value) => {
    if (Array.isArray(value)) return value;
    if (Array.isArray(value?.data)) return value.data;
    if (Array.isArray(value?.content)) return value.content;
    if (Array.isArray(value?.items)) return value.items;
    if (Array.isArray(value?.result)) return value.result;
    if (Array.isArray(value?.rows)) return value.rows;
    if (Array.isArray(value?.records)) return value.records;
    if (Array.isArray(value?.list)) return value.list;
    if (Array.isArray(value?.dispenses)) return value.dispenses;
    if (Array.isArray(value?.returns)) return value.returns;
    if (Array.isArray(value?.recalls)) return value.recalls;
    if (value && typeof value === "object") {
      const firstArrayValue = Object.values(value).find((entry) => Array.isArray(entry));
      if (Array.isArray(firstArrayValue)) return firstArrayValue;
    }
    return [];
  };
 
  const normalizeReport = (report) => ({
    ...report,
    id: report?.id ?? report?.reportId ?? report?.report_id ?? report?.reportID,
    scope: report?.scope ?? report?.reportType ?? report?.type ?? "",
    generatedAt: report?.generatedAt ?? report?.generatedDate ?? report?.createdAt,
    generatedBy: report?.generatedBy ?? report?.createdBy ?? report?.author,
    parametersJSON: report?.parametersJSON ?? report?.parametersJson ?? report?.parameters,
    status: report?.status ?? "Generated",
  });
 
  const [selectedType, setSelectedType] = useState("ALL");
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [formData, setFormData] = useState({});
  const [formErrors, setFormErrors] = useState({});
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [deletingId, setDeletingId] = useState(null);
  const [previewReport, setPreviewReport] = useState(null);
  const [reportData, setReportData] = useState(null);
  const [reports, setReports] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [actionMenuId, setActionMenuId] = useState(null);
  const [reportStatuses, setReportStatuses] = useState({});
 
  const sessionUser = (() => {
    try { return JSON.parse(localStorage.getItem("pharmaShelfUser") || "{}"); } catch { return {}; }
  })();
  const generatedByName = sessionUser?.name || sessionUser?.username || "ComplianceOfficer";
 
  const reportCardIconClasses = {
    EXPIRY:      { text: "text-red-700",   border: "border-red-300",   bg: "bg-red-50",   ring: "ring-red-100" },
    CONSUMPTION: { text: "text-blue-700",  border: "border-blue-300",  bg: "bg-blue-50",  ring: "ring-blue-100" },
    RECALL:      { text: "text-amber-700", border: "border-amber-300", bg: "bg-amber-50", ring: "ring-amber-100" },
    ALL:         { text: "text-gray-700",  border: "border-gray-300",  bg: "bg-gray-50",  ring: "ring-gray-100" },
  };
 
  const resolveReportId = (value) => {
    if (value && typeof value === "object") {
      return value.id ?? value.reportId ?? value.report_id ?? value.reportID ?? null;
    }
    return value ?? null;
  };
 
  const getField = (record, keys, fallback = "") => {
    for (const key of keys) {
      const value = key.split(".").reduce((acc, part) => acc?.[part], record);
      if (value !== undefined && value !== null && String(value).trim() !== "") return value;
    }
    return fallback;
  };
 
  const parseDate = (value) => {
    if (!value) return null;
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? null : d;
  };
 
  const isWithinDateRange = (value, startDateInput, endDateInput) => {
    const eventDate = parseDate(value);
    if (!eventDate) return false;
    const start = parseDate(startDateInput);
    const end = parseDate(endDateInput);
    if (!start || !end) return true;
    start.setHours(0, 0, 0, 0);
    end.setHours(23, 59, 59, 999);
    return eventDate >= start && eventDate <= end;
  };
 
  // ── Consumption helpers ──────────────────────────────────────────────────────
  const normalizeDispenseItem = (item) => ({
    quantity: Number(getField(item, ["quantity", "qty", "dispensedQty", "dispenseQuantity", "issuedQty"], 0)) || 0,
    productName: getField(item, [
      "productName", "product.name", "product.productName", "medicineName", "itemName", "name",
    ], "Unknown Product"),
    batchNo: getField(item, ["batchNo", "batchNumber", "lotNo", "lotNumber"], "—"),
    wardName: getField(item, ["wardName", "ward", "ward.name", "location", "dispensedTo", "issuedTo"], "—"),
    eventDate: getField(item, [
      "dispensedAt", "dispenseDate", "dispenseTime", "dispenseDateTime", "dispensedDate",
      "issuedAt", "issueDate", "createdAt", "date", "timestamp", "txnDate",
    ], null),
  });
 
  const normalizeReturnItem = (item) => ({
    quantity: Number(getField(item, ["quantity", "qty", "returnedQty", "returnQty", "receivedQty"], 0)) || 0,
    productName: getField(item, [
      "productName", "product.name", "product.productName", "medicineName", "itemName", "name",
    ], "Unknown Product"),
    eventDate: getField(item, [
      "returnedAt", "returnDate", "returnTime", "returnDateTime", "returnedDate",
      "receivedAt", "dateOfReturn", "createdAt", "date", "timestamp", "txnDate",
    ], null),
  });
 
  const buildConsumptionReportData = async (startDate, endDate) => {
    const [allDispenses, allReturns] = await Promise.all([
      dispensingAPI.getAll?.(),
      returnAPI.getAll?.(),
    ]);
 
    const dispenses = toArray(allDispenses)
      .map(normalizeDispenseItem)
      .filter((item) => isWithinDateRange(item.eventDate, startDate, endDate));
 
    const returns = toArray(allReturns)
      .map(normalizeReturnItem)
      .filter((item) => isWithinDateRange(item.eventDate, startDate, endDate));
 
    // Build per-product map
    const productMap = new Map();
 
    dispenses.forEach((item) => {
      const key = item.productName || "Unknown Product";
      if (!productMap.has(key)) {
        productMap.set(key, { productName: key, batchNo: item.batchNo, wardName: item.wardName, totalDispensed: 0, totalReturned: 0 });
      }
      const entry = productMap.get(key);
      entry.totalDispensed += item.quantity;
      if (item.batchNo && item.batchNo !== "—") entry.batchNo = item.batchNo;
      if (item.wardName && item.wardName !== "—") entry.wardName = item.wardName;
    });
 
    returns.forEach((item) => {
      const key = item.productName || "Unknown Product";
      if (!productMap.has(key)) {
        productMap.set(key, { productName: key, batchNo: "—", wardName: "—", totalDispensed: 0, totalReturned: 0 });
      }
      productMap.get(key).totalReturned += item.quantity;
    });
 
    if (productMap.size === 0) {
      const totalDispensed = dispenses.reduce((s, i) => s + i.quantity, 0);
      const totalReturned  = returns.reduce((s, i) => s + i.quantity, 0);
      return [{
        productName: "All Products", batchNo: "—", wardName: "—",
        totalDispensed: Number(totalDispensed.toFixed(2)),
        totalReturned:  Number(totalReturned.toFixed(2)),
        totalConsumed:  Number((totalDispensed - totalReturned).toFixed(2)),
      }];
    }
 
    return Array.from(productMap.values())
      .map((item) => ({
        ...item,
        totalDispensed: Number(item.totalDispensed.toFixed(2)),
        totalReturned:  Number(item.totalReturned.toFixed(2)),
        totalConsumed:  Number((item.totalDispensed - item.totalReturned).toFixed(2)),
      }))
      .sort((a, b) => b.totalConsumed - a.totalConsumed);
  };
 
  // ── Recall helpers ───────────────────────────────────────────────────────────
  const normalizeRecall = (item) => {
    const productName = getField(item, [
      "productName", "product.name", "product.productName", "product.medicineName",
      "medicineName", "itemName", "name", "item.productName", "item.name",
    ], "—");
    const batchNo = getField(item, [
      "batchNo", "batchNumber", "batch.batchNo", "batch.batchNumber",
      "batch.lotNo", "lotNo", "lotNumber", "batchId",
    ], "—");
    const recallDate = getField(item, [
      "issuedAt", "recallDate", "recalledAt", "recallInitiatedDate", "initiatedDate",
      "recalledDate", "recallDateTime", "issuedOn",
      "issueDate", "recallIssuedDate", "dateOfRecall",
      "createdAt", "updatedAt", "date",
    ], null);
    const status    = getField(item, ["status", "recallStatus", "currentStatus"], "—");
    const quantity  = Number(getField(item, ["quantity", "qty", "recalledQty", "affectedQty", "recalledQuantity", "batchQuantity"], 0)) || 0;
    const issuedBy  = getField(item, ["issuedBy", "recalledBy", "initiatedBy", "createdBy", "authority", "recalledByUser"], "—");
    const recallScope = getField(item, ["recallScope", "recallType", "type"], "—");
    const issueCount = status === "ISSUED" ? 1 : 0; // Count issued recalls
    return { productName, batchNo, recallDate, status, quantity, issuedBy, recallScope, issueCount };
  };
 
  const buildRecallReportData = async (startDate, endDate) => {
    let rawRecalls = [];
 
    try {
      const allResult = await recallAPI.getAll();
      rawRecalls = toArray(allResult);
      console.log("📋 RECALL: Fetched all recalls:", rawRecalls.length, "items");
      if (rawRecalls.length > 0) {
        console.log("📋 RECALL: First raw recall sample:", rawRecalls[0]);
      }
    } catch (err) {
      console.error("[Recall] getAll failed:", err.message);
      return [];
    }

    // Filter to only ISSUED recalls
    const issuedRecalls = rawRecalls.filter((item) => {
      const status = String(item.status || item.Status || "").toUpperCase();
      return status === "ISSUED";
    });
    console.log("📋 RECALL: Filtered to issued recalls:", issuedRecalls.length, "items");

    const normalized = issuedRecalls.map(normalizeRecall);
    if (normalized.length > 0) {
      console.log("📋 RECALL: First normalized recall:", normalized[0]);
    }
 
    return normalized;
  };
 
  // ── Fetch reports ────────────────────────────────────────────────────────────
  const fetchReports = useCallback(async (silent = false) => {
    if (!silent) setIsLoading(true);
    try {
      const data = await reportsAPI.getAllReports?.() || [];
      const normalizedReports = toArray(data).map(normalizeReport);
      setReports(normalizedReports);
    } catch (err) {
      toast.error(`Failed to fetch reports: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  }, []);
 
  useEffect(() => { fetchReports(); }, [fetchReports]);
 
  // ── Preview data loader ──────────────────────────────────────────────────────
  useEffect(() => {
    if (!previewReport) { setReportData(null); return; }
 
    const fetchReportData = async () => {
      try {
        const params = JSON.parse(previewReport.parametersJSON || "{}");
        let data = [];
 
        if (previewReport.reportContent && previewReport.scope !== "CONSUMPTION" && previewReport.scope !== "RECALL") {
          try {
            data = typeof previewReport.reportContent === "string"
              ? JSON.parse(previewReport.reportContent)
              : previewReport.reportContent;
          } catch { data = []; }
        }
 
        if (previewReport.scope === "EXPIRY") {
          if (!data || data.length === 0) {
            try {
              console.log("🔍 EXPIRY: No stored data, fetching from Batch Service...");
              const allBatches = await batchesAPI.getAll();
              console.log("✅ EXPIRY: Batches received:", allBatches?.length || 0, "items");
              data = toArray(allBatches)
              .filter(batch => {
                const { expiryValue } = normalizeBatchRecord(batch);
                const daysToExpiry = getDaysToExpiry(expiryValue);
                // Only include batches that are NOT safe (daysToExpiry <= 60)
                return daysToExpiry !== null && daysToExpiry <= 60;
              })
              .map(batch => {
                const { productName, batchNo, expiryValue } = normalizeBatchRecord(batch);
                const expiryDate   = new Date(expiryValue);
                const daysToExpiry = getDaysToExpiry(expiryValue);
                return {
                  productName,
                  batchNo,
                  expiryDate:   expiryDate.toISOString().split("T")[0],
                  daysToExpiry,
                  status: getExpiryStatus(daysToExpiry),
                };
              });
            } catch (batchErr) {
              console.error("❌ EXPIRY: Failed to fetch batches:");
              console.error("   Error Message:", batchErr?.message);
              console.error("   Error Status:", batchErr?.status);
              console.error("   Full Error:", batchErr);
              const errorMsg = `Failed to load batch data: ${batchErr?.message || "Unknown error"}`;
              console.error("🚨 SHOWING TOAST:", errorMsg);
              toast.error(errorMsg, { duration: 5000 });
              alert("Batch loading failed: " + errorMsg); // Extra visible alert
              data = [];
            }
          } else {
            // Ensure stored data doesn't include qty/location
            data = data.map(({ productName, batchNo, expiryDate, daysToExpiry, status }) => ({
              productName, batchNo, expiryDate, daysToExpiry, status,
            }));
          }
        } else if (previewReport.scope === "CONSUMPTION") {
          data = await buildConsumptionReportData(params.startDate, params.endDate);
        } else if (previewReport.scope === "RECALL") {
          data = await buildRecallReportData(params.startDate, params.endDate);
        }

        console.log("📊 Final reportData being set:", data?.length || 0, "items");
        console.log("   Data:", data);
        setReportData(data);
      } catch (err) {
        console.error("Error fetching report data:", err);
        setReportData([]);
      }
    };

    fetchReportData();
  }, [previewReport]);
 
  // ── Form ─────────────────────────────────────────────────────────────────────
  const scopeConfig = selectedCategory ? SCOPE_PARAMETERS[selectedCategory.id] || [] : [];
 
  const handleFormChange = (key, value) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
    if (formErrors[key]) setFormErrors((prev) => ({ ...prev, [key]: undefined }));
  };
 
  const validateForm = () => {
    const errors = {};
    if (!selectedCategory?.id) errors.scope = "Required";
    scopeConfig.forEach((f) => {
      if (f.required && !String(formData[f.key] || "").trim()) errors[f.key] = "Required";
    });
    if (formData.startDate && formData.endDate && new Date(formData.startDate) > new Date(formData.endDate)) {
      errors.endDate = "End date must be after start date";
    }
    return errors;
  };
 
  const handleSaveReport = async () => {
    const errors = validateForm();
    if (Object.keys(errors).length) { setFormErrors(errors); return; }
    setIsSaving(true);
    try {
      let reportContent = [];
 
      if (selectedCategory.id === "EXPIRY") {
        const startDate = new Date(formData.startDate);
        const endDate   = new Date(formData.endDate);
        try {
          const allBatches = await batchesAPI.getAll();
          reportContent = toArray(allBatches)
            .filter(batch => {
              const { expiryValue } = normalizeBatchRecord(batch);
              const expiryDate   = new Date(expiryValue);
              const daysToExpiry = getDaysToExpiry(expiryValue);
              if (Number.isNaN(expiryDate.getTime()) || daysToExpiry === null) return false;
              // Only include batches that are NOT safe (Expired, Critical, or Warning)
              return expiryDate >= startDate && expiryDate <= endDate && daysToExpiry <= 60;
            })
            .map(batch => {
              const { productName, batchNo, expiryValue } = normalizeBatchRecord(batch);
              const expiryDate   = new Date(expiryValue);
              const daysToExpiry = getDaysToExpiry(expiryValue);
              return { productName, batchNo, expiryDate: expiryDate.toISOString().split("T")[0], daysToExpiry, status: getExpiryStatus(daysToExpiry) };
            });
        } catch { reportContent = []; }
      } else if (selectedCategory.id === "CONSUMPTION") {
        try { reportContent = await buildConsumptionReportData(formData.startDate, formData.endDate); } catch { reportContent = []; }
      } else if (selectedCategory.id === "RECALL") {
        try { reportContent = await buildRecallReportData(formData.startDate, formData.endDate); } catch { reportContent = []; }
      }
 
      const now    = new Date();
      const userId = sessionUser?.id || sessionUser?.userId || "unknown";
      const currentDateTime = now.toLocaleString("en-IN", { 
        year: "numeric", 
        month: "short", 
        day: "numeric", 
        hour: "2-digit", 
        minute: "2-digit",
        second: "2-digit"
      });
      const reportFileName = selectedCategory.id === "EXPIRY"
        ? `expiryreport_${userId}.csv`
        : `/reports/${selectedCategory.name}_${now.getTime()}.pdf`;
 
      const payload = {
        scope:          selectedCategory.id,
        parametersJSON: JSON.stringify({ startDate: formData.startDate, endDate: formData.endDate }),
        generatedBy:    generatedByName,
        generatedAt:    now.toISOString(),
        reportURI:      reportFileName,
        status:         "Generated",
        comments:       "",
        reportContent:  JSON.stringify(reportContent),
      };
 
      await reportsAPI.createReport?.(payload) || new Promise((res) => setTimeout(res, 500));
      setShowSuccessModal(true);
      setFormData({});
      setFormErrors({});
      fetchReports(true);
    } catch {
      toast.error("Failed to save report");
    } finally {
      setIsSaving(false);
    }
  };
 
  // ── Delete ───────────────────────────────────────────────────────────────────
  const deleteReport = async (idOrReport) => {
    const reportId = resolveReportId(idOrReport);
    if (!reportId) { toast.error("Invalid report id. Cannot delete."); return false; }
    if (!window.confirm("Delete this report permanently from repository?")) return false;
    setDeletingId(reportId);
    try {
      if (!reportsAPI.deleteReport) throw new Error("Delete API is not configured");
      await reportsAPI.deleteReport(reportId);
      setReports((prev) => prev.filter((r) => String(resolveReportId(r)) !== String(reportId)));
      await fetchReports(true);
      toast.success("The report has been deleted");
      return true;
    } catch (err) {
      toast.error(`Failed to delete report: ${err?.message || "Unknown error"}`);
      return false;
    } finally {
      setDeletingId(null);
    }
  };
 
  // ── Filtering & pagination ───────────────────────────────────────────────────
  const filteredReports = useMemo(() => {
    if (!selectedType || selectedType === "ALL") return reports;
    return reports.filter((r) => r.scope === selectedType);
  }, [reports, selectedType]);
 
  const totalPages = Math.max(1, Math.ceil(filteredReports.length / rowsPerPage));
 
  const paginatedReports = useMemo(() => {
    const start = (currentPage - 1) * rowsPerPage;
    return filteredReports.slice(start, start + rowsPerPage);
  }, [filteredReports, currentPage, rowsPerPage]);
 
  useEffect(() => { setCurrentPage(1); }, [selectedType, rowsPerPage]);
  useEffect(() => { if (currentPage > totalPages) setCurrentPage(totalPages); }, [currentPage, totalPages]);
 
  // ────────────────────────────────────────────────────────────────────────────
  // PREVIEW VIEW
  // ────────────────────────────────────────────────────────────────────────────
  if (previewReport) {
    return (
      <div className="space-y-6">
        <style>{`.hide-scrollbar{-ms-overflow-style:none;scrollbar-width:none}.hide-scrollbar::-webkit-scrollbar{display:none}`}</style>
 
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Report Details</h1>
            <p className="text-gray-600 mt-1">View and manage selected report</p>
          </div>
          <button
            onClick={() => setPreviewReport(null)}
            className="inline-flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100 text-sm font-medium"
          >
            <ArrowLeft size={16} /> Back to Reports
          </button>
        </div>
 
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="p-6 space-y-6">
 
            {/* Meta cards — no "Generated By", no Report ID shown separately for Recall */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gradient-to-br from-[#3C8C85]/15 to-[#3C8C85]/25 rounded-lg p-4 border border-[#3C8C85]/40">
                <p className="text-xs text-[#2E6B5E] font-semibold uppercase">Report ID</p>
                <p className="text-lg font-bold text-gray-900 mt-1">#{previewReport.id}</p>
              </div>
              <div className="bg-gradient-to-br from-[#3C8C85]/15 to-[#3C8C85]/25 rounded-lg p-4 border border-[#3C8C85]/40">
                <p className="text-xs text-[#2E6B5E] font-semibold uppercase">Report Type</p>
                <p className="text-lg font-bold text-gray-900 mt-1">
                  {REPORT_CATEGORIES.find((c) => c.id === previewReport.scope)?.display || previewReport.scope}
                </p>
              </div>
              <div className="bg-gradient-to-br from-[#3C8C85]/15 to-[#3C8C85]/25 rounded-lg p-4 border border-[#3C8C85]/40 md:col-span-2">
                <p className="text-xs text-[#2E6B5E] font-semibold uppercase">Generated At</p>
                <p className="text-lg font-bold text-gray-900 mt-1">{formatDateTime(previewReport.generatedAt)}</p>
              </div>
            </div>
 
            {/* Data table */}
            {reportData === null && (
              <div className="bg-gray-50 rounded-lg p-8 text-center border border-gray-200">
                <RefreshCw size={28} className="mx-auto text-gray-400 mb-3 animate-spin" />
                <p className="text-gray-500">Loading report data…</p>
              </div>
            )}
 
            {reportData && reportData.length === 0 && (
              <div className="bg-gray-50 rounded-lg p-8 text-center border border-gray-200">
                <FileText size={32} className="mx-auto text-gray-400 mb-3" />
                <p className="text-gray-500">No records found for the selected date range.</p>
              </div>
            )}
 
            {reportData && reportData.length > 0 && (
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                <p className="text-xs text-gray-600 font-semibold uppercase mb-4 flex items-center gap-2">
                  <FileText size={14} /> Report Data ({reportData.length} record{reportData.length !== 1 ? "s" : ""})
                </p>
                <div className="overflow-x-auto hide-scrollbar">
                  <table className="w-full text-xs md:text-sm">
                    <thead className="bg-gradient-to-r from-[#3C8C85] to-[#2E6B5E] text-white">
                      <tr>
                        {previewReport.scope === "CONSUMPTION" ? (
                          <>
                            <th className="px-3 py-3 text-left font-semibold">Product Name</th>
                            <th className="px-3 py-3 text-left font-semibold">Batch No</th>
                            <th className="px-3 py-3 text-left font-semibold">Ward / Location</th>
                            <th className="px-3 py-3 text-center font-semibold">Dispensed</th>
                            <th className="px-3 py-3 text-center font-semibold">Returned</th>
                            <th className="px-3 py-3 text-center font-semibold">Net Consumed</th>
                          </>
                        ) : previewReport.scope === "RECALL" ? (
                          <>
                            <th className="px-3 py-3 text-left font-semibold">Recall Date</th>
                            <th className="px-3 py-3 text-left font-semibold">Batch No</th>
                            <th className="px-3 py-3 text-center font-semibold">Issue Count</th>
                            <th className="px-3 py-3 text-left font-semibold">Issued By</th>
                            <th className="px-3 py-3 text-center font-semibold">Status</th>
                          </>
                        ) : (
                          <>
                            <th className="px-3 py-3 text-left font-semibold">Product Name</th>
                            <th className="px-3 py-3 text-left font-semibold">Batch No</th>
                            <th className="px-3 py-3 text-left font-semibold">Expiry Date</th>
                            <th className="px-3 py-3 text-center font-semibold">Days to Expiry</th>
                            <th className="px-3 py-3 text-center font-semibold">Status</th>
                          </>
                        )}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {reportData.map((item, idx) => (
                        <tr key={idx} className={`${idx % 2 === 0 ? "bg-white" : "bg-gray-50"} hover:bg-blue-50 transition-all`}>
                          {previewReport.scope === "CONSUMPTION" ? (
                            <>
                              <td className="px-3 py-3 font-semibold text-gray-900">{item.productName || "—"}</td>
                              <td className="px-3 py-3 text-gray-700 font-mono text-xs">{item.batchNo || "—"}</td>
                              <td className="px-3 py-3 text-gray-700">{item.wardName || "—"}</td>
                              <td className="px-3 py-3 text-center font-semibold text-gray-900">{item.totalDispensed ?? 0}</td>
                              <td className="px-3 py-3 text-center font-semibold text-gray-900">{item.totalReturned ?? 0}</td>
                              <td className="px-3 py-3 text-center">
                                <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${
                                  (item.totalConsumed ?? 0) < 0
                                    ? "bg-red-100 text-red-800 border-red-300"
                                    : "bg-green-100 text-green-800 border-green-300"
                                }`}>
                                  {item.totalConsumed ?? 0}
                                </span>
                              </td>
                            </>
                          ) : previewReport.scope === "RECALL" ? (
                            <>
                              <td className="px-3 py-3 text-gray-700 font-medium">{item.recallDate}</td>
                              <td className="px-3 py-3 text-gray-700 font-mono text-xs">{item.batchNo}</td>
                              <td className="px-3 py-3 text-center font-semibold text-blue-700">{item.issueCount || "—"}</td>
                              <td className="px-3 py-3 text-gray-700">
                                {item.issuedBy}
                                {item.recallScope && item.recallScope !== "—" && (
                                  <span className="ml-1 text-xs text-gray-400">({item.recallScope})</span>
                                )}
                              </td>
                              <td className="px-3 py-3 text-center">
                                <span className={`px-2 py-1 rounded-full text-xs font-semibold border ${
                                  String(item.status).toLowerCase() === "active"   ? "bg-red-100 text-red-800 border-red-300"
                                  : String(item.status).toLowerCase() === "completed" ? "bg-green-100 text-green-800 border-green-300"
                                  : "bg-amber-100 text-amber-800 border-amber-300"
                                }`}>
                                  {item.status}
                                </span>
                              </td>
                            </>
                          ) : (
                            /* EXPIRY — no qty/location columns */
                            <>
                              <td className="px-3 py-3 font-medium text-gray-900">{item.productName}</td>
                              <td className="px-3 py-3 text-gray-700 font-semibold">{item.batchNo}</td>
                              <td className="px-3 py-3 text-gray-700">{item.expiryDate}</td>
                              <td className="px-3 py-3 text-center text-gray-700 font-semibold">{item.daysToExpiry}</td>
                              <td className="px-3 py-3 text-center">
                                <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${
                                  item.status === "Critical" ? "bg-red-100 text-red-800 border-red-300"
                                  : item.status === "Warning" ? "bg-orange-100 text-orange-800 border-orange-300"
                                  : "bg-green-100 text-green-800 border-green-300"
                                }`}>
                                  {item.status}
                                </span>
                              </td>
                            </>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
 
            {/* Actions */}
            <div className="bg-gray-50 border border-gray-200 rounded-lg px-6 py-4 flex gap-3 justify-end">
              <button
                onClick={() => {
                  if (!reportData || reportData.length === 0) return;
                  const isConsumption = previewReport.scope === "CONSUMPTION";
                  const isRecall      = previewReport.scope === "RECALL";
                  const headers = isConsumption
                    ? ["Product Name", "Batch No", "Ward / Location", "Total Dispensed", "Total Returned", "Net Consumed"]
                    : isRecall
                    ? ["Recall Date", "Batch No", "Issue Count", "Issued By", "Status", "Scope"]
                    : ["Product Name", "Batch No", "Expiry Date", "Days to Expiry", "Status"];
                  const rows = isConsumption
                    ? reportData.map((i) => [i.productName, i.batchNo, i.wardName, i.totalDispensed, i.totalReturned, i.totalConsumed])
                    : isRecall
                    ? reportData.map((i) => [i.recallDate, i.batchNo, i.issueCount, i.issuedBy, i.status, i.recallScope])
                    : reportData.map((i) => [i.productName, i.batchNo, i.expiryDate, i.daysToExpiry, i.status]);
                  const csv = [headers, ...rows].map((row) => row.map((cell) => `"${cell ?? ""}"`).join(",")).join("\n");
                  const blob = new Blob([csv], { type: "text/csv" });
                  const link = document.createElement("a");
                  link.href = URL.createObjectURL(blob);
                  link.download = previewReport.reportURI || `report_${previewReport.id}.csv`;
                  link.click();
                  URL.revokeObjectURL(link.href);
                  toast.success("Report downloaded!");
                }}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 flex items-center gap-2"
              >
                <Download size={16} /> Download CSV
              </button>
              <button
                onClick={async () => {
                  const deleted = await deleteReport(previewReport);
                  if (deleted) setPreviewReport(null);
                }}
                disabled={deletingId === resolveReportId(previewReport)}
                className="px-6 py-2 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 disabled:opacity-60 inline-flex items-center gap-2"
              >
                {deletingId === resolveReportId(previewReport)
                  ? <><RefreshCw size={16} className="animate-spin" /> Deleting…</>
                  : <><Trash2 size={16} /> Delete Report</>}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
 
  // ────────────────────────────────────────────────────────────────────────────
  // MAIN DASHBOARD
  // ────────────────────────────────────────────────────────────────────────────
  return (
    <div className="space-y-6">
      <style>{`.hide-scrollbar{-ms-overflow-style:none;scrollbar-width:none}.hide-scrollbar::-webkit-scrollbar{display:none}`}</style>
 
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Report Center & Audit Logs</h1>
          <p className="text-gray-600 mt-1">Compliance reporting workspace</p>
        </div>
      </div>
 
      {/* Success Modal */}
      {showSuccessModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-sm text-center">
            <div className="flex justify-center mb-4">
              <CheckCircle className="size-16 text-green-500 animate-bounce" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Report Generated Successfully!</h3>
            <p className="text-gray-600 mb-6">
              Your {selectedCategory?.display || "report"} has been generated and saved to the repository.
            </p>
            <button
              onClick={() => setShowSuccessModal(false)}
              className="w-full px-6 py-3 bg-green-600 text-white rounded-lg font-semibold hover:bg-green-700"
            >
              Done
            </button>
          </div>
        </div>
      )}
 
      {/* Report Type Filter Cards — same grid pattern as ExpiryMonitoring summary cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {REPORT_CATEGORIES.map((type) => {
          const Icon     = type.icon;
          const isSelected = selectedType === type.id;
          const iconClass  = reportCardIconClasses[type.id] || reportCardIconClasses.ALL;
          return (
            <button
              key={type.id}
              onClick={() => setSelectedType(type.id)}
              className={`flex flex-col items-center px-6 py-5 rounded-xl border-2 shadow-sm transition-all bg-white
                ${isSelected ? "border-[#3C8C85]" : "border-gray-200 hover:border-[#3C8C85]/50"}`}
            >
              <div className={`p-3 rounded-full mb-2 border shadow-sm ring-4 ${
                isSelected
                  ? "border-[#3C8C85] bg-[#3C8C85]/10 ring-[#3C8C85]/20"
                  : `${iconClass.border} ${iconClass.bg} ${iconClass.ring}`
              }`}>
                <Icon className={`size-7 stroke-[2.4] ${isSelected ? "text-[#3C8C85]" : iconClass.text}`} />
              </div>
              <span className="font-semibold text-gray-900">{type.display}</span>
              <span className="text-xs text-gray-600 mt-1 text-center">{type.description}</span>
            </button>
          );
        })}
 
        {/* All Reports card */}
        <button
          onClick={() => setSelectedType("ALL")}
          className={`flex flex-col items-center px-6 py-5 rounded-xl border-2 shadow-sm transition-all bg-white
            ${selectedType === "ALL" ? "border-[#3C8C85]" : "border-gray-200 hover:border-[#3C8C85]/50"}`}
        >
          <div className={`p-3 rounded-full mb-2 border shadow-sm ring-4 ${
            selectedType === "ALL"
              ? "border-[#3C8C85] bg-[#3C8C85]/10 ring-[#3C8C85]/20"
              : "border-gray-300 bg-gray-50 ring-gray-100"
          }`}>
            <FileText className={`size-7 stroke-[2.4] ${selectedType === "ALL" ? "text-[#3C8C85]" : "text-gray-700"}`} />
          </div>
          <span className="font-semibold text-gray-900">All Reports</span>
          <span className="text-xs text-gray-600 mt-1">Show all reports</span>
        </button>
      </div>
 
      {/* Generate Report Panel */}
      <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
        <div className="px-6 py-4 bg-[#3C8C85] text-white">
          <h2 className="text-lg font-bold">Generate Report</h2>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                Type of Report <span className="text-red-500">*</span>
              </label>
              <select
                value={selectedCategory?.id || ""}
                onChange={(e) => {
                  const cat = REPORT_CATEGORIES.find((c) => c.id === e.target.value) || null;
                  setSelectedCategory(cat);
                  if (formErrors.scope) setFormErrors((prev) => ({ ...prev, scope: undefined }));
                }}
                className={`w-full px-4 py-2.5 border rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#3C8C85]/30 focus:border-[#3C8C85] ${formErrors.scope ? "border-red-500" : "border-gray-300"}`}
              >
                <option value="">Select report type</option>
                {REPORT_CATEGORIES.map((cat) => (
                  <option key={cat.id} value={cat.id}>{cat.display}</option>
                ))}
              </select>
              {formErrors.scope && <p className="text-red-500 text-xs mt-1">{formErrors.scope}</p>}
            </div>
 
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                From <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={formData.startDate ?? ""}
                onChange={(e) => handleFormChange("startDate", e.target.value)}
                max={new Date().toISOString().split("T")[0]}
                className={`w-full px-4 py-2.5 border rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#3C8C85]/30 focus:border-[#3C8C85] ${formErrors.startDate ? "border-red-500" : "border-gray-300"}`}
              />
              {formErrors.startDate && <p className="text-red-500 text-xs mt-1">{formErrors.startDate}</p>}
            </div>
 
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                To <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={formData.endDate ?? ""}
                onChange={(e) => handleFormChange("endDate", e.target.value)}
                max={new Date().toISOString().split("T")[0]}
                className={`w-full px-4 py-2.5 border rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#3C8C85]/30 focus:border-[#3C8C85] ${formErrors.endDate ? "border-red-500" : "border-gray-300"}`}
              />
              {formErrors.endDate && <p className="text-red-500 text-xs mt-1">{formErrors.endDate}</p>}
            </div>
 
            <div className="flex items-end">
              <button
                onClick={handleSaveReport}
                disabled={isSaving}
                title="Click to generate and save the selected report"
                className="w-full px-5 py-2.5 bg-[#3C8C85] text-white rounded-lg font-semibold hover:bg-[#2E6B5E] disabled:opacity-60 flex items-center justify-center gap-2 shadow-sm text-sm"
              >
                {isSaving
                  ? <><RefreshCw className="size-4 animate-spin" /> Generating…</>
                  : <><Play className="size-4 fill-current" /> Generate</>}
              </button>
            </div>
          </div>
        </div>
      </div>
 
      {/* Report Repository */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 bg-[#3C8C85] flex items-center justify-between">
          <h2 className="text-lg font-bold text-white">Report Repository</h2>
          <span className="text-sm text-white/80">
            {filteredReports.length} report{filteredReports.length !== 1 ? "s" : ""}
          </span>
        </div>
 
        <div className="overflow-x-auto hide-scrollbar">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Generated At</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {isLoading ? (
                <tr>
                  <td colSpan={4} className="px-6 py-10 text-center text-sm text-gray-500">
                    <RefreshCw className="size-5 animate-spin mx-auto mb-2 text-gray-400" />
                    Loading reports…
                  </td>
                </tr>
              ) : paginatedReports.length ? (
                paginatedReports.map((report) => (
                  <tr key={report.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 font-medium text-gray-900">
                      {REPORT_CATEGORIES.find((c) => c.id === report.scope)?.display || report.scope}
                    </td>
                    <td className="px-6 py-4 text-gray-600">{formatDateTime(report.generatedAt)}</td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${
                        reportStatuses[report.id] === "Reviewed"
                          ? "bg-green-100 text-green-700 border-green-300"
                          : "bg-amber-100 text-amber-700 border-amber-300"
                      }`}>
                        {reportStatuses[report.id] === "Reviewed" ? "✓ Reviewed" : "Pending"}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="relative flex justify-center">
                        <button
                          onClick={() => setActionMenuId((prev) => (prev === report.id ? null : report.id))}
                          className="p-2 rounded-lg border border-gray-300 hover:bg-gray-100"
                          title="Actions"
                        >
                          <MoreVertical size={16} />
                        </button>
                        {actionMenuId === report.id && (
                          <div className="absolute right-0 top-10 z-20 w-40 bg-white border border-gray-200 rounded-lg shadow-lg py-1">
                            <button
                              onClick={() => { 
                                setActionMenuId(null); 
                                setPreviewReport(report);
                                const now = new Date().toLocaleString('en-IN', { 
                                  year: 'numeric', 
                                  month: 'short', 
                                  day: 'numeric', 
                                  hour: '2-digit', 
                                  minute: '2-digit',
                                  second: '2-digit'
                                });
                                setReportStatuses((prev) => ({ ...prev, [report.id]: `Reviewed - ${now}` }));
                                toast.success("Report marked as Reviewed");
                              }}
                              className="w-full text-left px-3 py-2 text-sm hover:bg-gray-50 inline-flex items-center gap-2 text-gray-700"
                            >
                              <Eye size={14} /> View Report
                            </button>
                          </div>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="px-6 py-10 text-center text-gray-500">
                    No reports found. Generate a new report to get started.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
 
        {/* Pagination — rows-per-page style matching ExpiryMonitoring */}
        {filteredReports.length > 0 && (
          <div className="px-6 py-4 border-t border-gray-200 flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-gray-50">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <span>Rows per page</span>
              <select
                value={rowsPerPage}
                onChange={(e) => { setRowsPerPage(Number(e.target.value)); setCurrentPage(1); }}
                className="border border-gray-300 rounded-md px-2 py-1 text-sm bg-white"
              >
                <option value={5}>5</option>
                <option value={10}>10</option>
                <option value={20}>20</option>
                <option value={50}>50</option>
              </select>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="px-3 py-1.5 border border-gray-300 rounded-md text-sm disabled:opacity-50 hover:bg-gray-100 inline-flex items-center gap-1"
              >
                <ChevronLeft size={15} /> Previous
              </button>
              <span className="text-sm text-gray-600 px-1">
                Page <span className="font-semibold text-gray-900">{currentPage}</span> of{" "}
                <span className="font-semibold text-gray-900">{totalPages}</span>
              </span>
              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="px-3 py-1.5 border border-gray-300 rounded-md text-sm disabled:opacity-50 hover:bg-gray-100 inline-flex items-center gap-1"
              >
                Next <ChevronRight size={15} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
 