import { useState, useEffect } from "react";
import {
  ShieldCheck,
  Search,
  Filter,
  Download,
  User,
  Edit,
  Plus,
  LogIn,
  LogOut,
  Trash2,
  Package,
  PillBottle,
  ShoppingCart,
  ChevronUp,
  ChevronDown,
  Activity,
  Users,
  Clock,
  AlertTriangle,
} from "lucide-react";
import { auditAPI } from "../../services/api";
import { usersAPI } from "../../services/api";
 
// ─── Action metadata ───────────────────────────────────────────────────────────
const ACTION_META = {
  LOGIN:                      { label: "User logged in",                icon: LogIn,       color: "bg-green-100 text-green-700"   },
  LOGOUT:                     { label: "User logged out",               icon: LogOut,      color: "bg-gray-100 text-gray-600"     },
  USER_CREATED:               { label: "User created",                  icon: Plus,        color: "bg-blue-100 text-blue-700"     },
  USER_UPDATED:               { label: "User updated",                  icon: Edit,        color: "bg-yellow-100 text-yellow-700" },
  PRODUCT_CREATED:            { label: "Product created",               icon: Plus,        color: "bg-blue-100 text-blue-700"     },
  PRODUCT_UPDATED:            { label: "Product updated",               icon: Edit,        color: "bg-yellow-100 text-yellow-700" },
  PRODUCT_DELETED:            { label: "Product deleted",               icon: Trash2,      color: "bg-red-100 text-red-700"       },
  BATCH_CREATED:              { label: "Batch created",                 icon: Plus,        color: "bg-blue-100 text-blue-700"     },
  BATCH_UPDATED:              { label: "Batch updated",                 icon: Edit,        color: "bg-yellow-100 text-yellow-700" },
  BATCH_DELETED:              { label: "Batch deleted",                 icon: Trash2,      color: "bg-red-100 text-red-700"       },
  BATCH_QUARANTINED:          { label: "Batch quarantined",             icon: Package,     color: "bg-orange-100 text-orange-700" },
  SUPPLIER_CREATED:           { label: "Supplier created",              icon: Plus,        color: "bg-blue-100 text-blue-700"     },
  SUPPLIER_UPDATED:           { label: "Supplier updated",              icon: Edit,        color: "bg-yellow-100 text-yellow-700" },
  SUPPLIER_DELETED:           { label: "Supplier deleted",              icon: Trash2,      color: "bg-red-100 text-red-700"       },
  PURCHASE_ORDER_CREATED:     { label: "Purchase order created",        icon: Plus,        color: "bg-blue-100 text-blue-700"     },
  PURCHASE_ORDER_UPDATED:     { label: "Purchase order updated",        icon: Edit,        color: "bg-yellow-100 text-yellow-700" },
  PURCHASE_ORDER_DELETED:     { label: "Purchase order deleted",        icon: Trash2,      color: "bg-red-100 text-red-700"       },
  GOODS_RECEIPT_CREATED:      { label: "Goods receipt created",         icon: ShoppingCart,color: "bg-cyan-100 text-cyan-700"     },
  GOODS_RECEIPT_UPDATED:      { label: "Goods receipt updated",         icon: Edit,        color: "bg-yellow-100 text-yellow-700" },
  GOODS_RECEIPT_DELETED:      { label: "Goods receipt deleted",         icon: Trash2,      color: "bg-red-100 text-red-700"       },
  MEDICINE_REQUESTED:         { label: "Medicine requested",            icon: PillBottle,  color: "bg-purple-100 text-purple-700" },
  MEDICINE_DISPENSED:         { label: "Medicine dispensed",            icon: PillBottle,  color: "bg-purple-100 text-purple-700" },
  MEDICINE_RETURNED:          { label: "Medicine returned",             icon: PillBottle,  color: "bg-purple-100 text-purple-700" },
  RECALL_ISSUED:              { label: "Recall issued",                 icon: AlertTriangle, color: "bg-red-100 text-red-700"    },
  SCHEDULE_CREATED:           { label: "Schedule created",              icon: Plus,        color: "bg-blue-100 text-blue-700"     },
  SCHEDULE_DELETED:           { label: "Schedule deleted",              icon: Trash2,      color: "bg-red-100 text-red-700"       },
  RECONCILIATION_UPDATED:     { label: "Reconciliation updated",        icon: Edit,        color: "bg-yellow-100 text-yellow-700" },
  RECONCILIATION_ACCEPTED:    { label: "Reconciliation accepted",       icon: ShieldCheck, color: "bg-green-100 text-green-700"   },
  RECONCILIATION_REJECTED:    { label: "Reconciliation rejected",       icon: Trash2,      color: "bg-red-100 text-red-700"       },
  REPORT_GENERATED:           { label: "Report generated",              icon: Download,    color: "bg-indigo-100 text-indigo-700" },
};
 
const ALL_ACTIONS = ["ALL", ...Object.keys(ACTION_META)];
const ALL_RESOURCES = ["ALL"];
 
function formatTimestamp(ts) {
  if (!ts) return "—";
  try {
    return new Date(ts).toLocaleString("en-GB", {
      day: "2-digit", month: "short", year: "numeric",
      hour: "2-digit", minute: "2-digit", second: "2-digit",
    });
  } catch {
    return "—";
  }
}
 
function extractResourcesFromLogs(logs) {
  const resources = new Set();
  logs.forEach((log) => {
    if (log.resource) {
      resources.add(log.resource);
    }
  });
  return Array.from(resources).sort();
}
 
function getMostFrequentAction(logs) {
  if (logs.length === 0) return "—";
  const freq = {};
  logs.forEach((log) => {
    freq[log.action] = (freq[log.action] || 0) + 1;
  });
  const most = Object.entries(freq).sort((a, b) => b[1] - a[1])[0];
  return most ? (ACTION_META[most[0]]?.label || most[0]) : "—";
}
 
function getMostAffectedResource(logs) {
  if (logs.length === 0) return "—";
  const freq = {};
  logs.forEach((log) => {
    freq[log.resource] = (freq[log.resource] || 0) + 1;
  });
  const most = Object.entries(freq).sort((a, b) => b[1] - a[1])[0];
  return most ? most[0] : "—";
}
 
function getLast24HoursCount(logs) {
  const now = new Date();
  const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  return logs.filter((log) => {
    try {
      const logTime = new Date(log.timestamp);
      return logTime >= oneDayAgo && logTime <= now;
    } catch {
      return false;
    }
  }).length;
}
 
// ─── Component ─────────────────────────────────────────────────────────────────
export function AuditLog() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [user, setUser] = useState(null);
  const [userMap, setUserMap] = useState({}); // Map userID to userName
 
  // Filter states
  const [searchQuery, setSearchQuery] = useState("");
  const [actionFilter, setActionFilter] = useState("ALL");
  const [resourceFilter, setResourceFilter] = useState("ALL");
  const [userIDFilter, setUserIDFilter] = useState("");
  const [timestampFrom, setTimestampFrom] = useState("");
  const [timestampTo, setTimestampTo] = useState("");
 
  // Sorting
  const [sortBy, setSortBy] = useState("timestamp");
  const [sortOrder, setSortOrder] = useState("desc");
 
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const LOGS_PER_PAGE = 5;
 
  /* =========================
     Check user role on mount
  ========================= */
  useEffect(() => {
    const userData = localStorage.getItem("pharmaShelfUser");
    if (userData) {
      try {
        setUser(JSON.parse(userData));
      } catch {
        setError("Session error. Please log in again.");
        setLoading(false);
      }
    }
  }, []);
 
  /* =========================
     Fetch all users to create userID->userName mapping
  ========================= */
  useEffect(() => {
    if (!user) return;
 
    const fetchUsers = async () => {
      try {
        const usersData = await usersAPI.getAll();
        console.log("👥 Users Data:", usersData);
        const map = {};
        if (Array.isArray(usersData)) {
          usersData.forEach((u) => {
            const userId = u.id || u.userId || u.userID;
            const userName = u.name || u.userName || u.fullName || "Unknown";
            if (userId) {
              map[userId] = userName;
              console.log(`Mapping ${userId} -> ${userName}`);
            }
          });
        }
        console.log("📍 Final User Map:", map);
        setUserMap(map);
      } catch (err) {
        console.error("Failed to fetch users:", err);
      }
    };
 
    fetchUsers();
  }, [user]);
 
  /* =========================
     Fetch audit logs on mount
  ========================= */
  useEffect(() => {
    if (!user) return;
 
    const fetchLogs = async () => {
      try {
        setLoading(true);
        setError("");
        console.log("🔍 Fetching audit logs from API...");
        const data = await auditAPI.getAll();
       
        console.log("📦 Raw API Response:", data);
        console.log("📦 Response type:", typeof data);
        console.log("📦 Is Array:", Array.isArray(data));
       
        if (data) {
          console.log("📦 First item:", data[0] || data);
          console.table(Array.isArray(data) ? data.slice(0, 3) : [data]);
        }
       
        // Handle both array and object wrapped responses
        let logsArray = [];
        if (Array.isArray(data)) {
          logsArray = data;
        } else if (data && typeof data === 'object') {
          // Check if data has a logs, auditLogs, or data property
          logsArray = data.logs || data.auditLogs || data.data || data.auditLog || [];
          console.log("📦 Extracted logs from object:", logsArray);
        } else if (typeof data === 'string') {
          try {
            const parsed = JSON.parse(data);
            logsArray = Array.isArray(parsed) ? parsed : parsed.logs || parsed.auditLogs || [];
          } catch {
            console.log("📦 Could not parse string response");
          }
        }
       
        console.log("✅ Final logs array:", logsArray);
        console.log("✅ Total logs count:", logsArray.length);
        setLogs(logsArray);
      } catch (err) {
        console.error("❌ Failed to fetch audit logs:", err);
        console.error("❌ Error message:", err.message);
        console.error("❌ Error stack:", err.stack);
       
        // Handle specific error cases
        const errorMessage = err.message || "Failed to load audit logs";
        if (errorMessage.includes("403")) {
          setError("Access Denied: Your role does not have permission to view audit logs. Contact your administrator.");
        } else if (errorMessage.includes("401")) {
          setError("Session Expired: Please log in again.");
        } else {
          setError(errorMessage || "Failed to load audit logs. Please try again.");
        }
       
        setLogs([]);
      } finally {
        setLoading(false);
      }
    };
 
    fetchLogs();
  }, [user]);
 
  /* =========================
     Filter and sort logs
  ========================= */
  const filteredLogs = logs
    .filter((log) => {
      const matchesSearch =
        (log.userName?.toLowerCase() || "").includes(searchQuery.toLowerCase()) ||
        (userMap[log.userID]?.toLowerCase() || "").includes(searchQuery.toLowerCase()) ||
        (log.details?.toLowerCase() || "").includes(searchQuery.toLowerCase()) ||
        (log.resource?.toLowerCase() || "").includes(searchQuery.toLowerCase()) ||
        (log.action?.toLowerCase() || "").includes(searchQuery.toLowerCase());
 
      const matchesAction = actionFilter === "ALL" || log.action === actionFilter;
      const matchesResource = resourceFilter === "ALL" || log.resource === resourceFilter;
 
      const matchesUserID =
        !userIDFilter || String(log.userID) === String(userIDFilter);
 
      const logTimestamp = new Date(log.timestamp);
      const fromDate = timestampFrom
        ? new Date(timestampFrom)
        : new Date("1970-01-01");
      const toDate = timestampTo
        ? new Date(timestampTo)
        : new Date("2100-12-31");
 
      const matchesTimestamp =
        logTimestamp >= fromDate && logTimestamp <= toDate;
 
      return (
        matchesSearch &&
        matchesAction &&
        matchesResource &&
        matchesUserID &&
        matchesTimestamp
      );
    })
    .sort((a, b) => {
      let aVal, bVal;
 
      if (sortBy === "timestamp") {
        aVal = new Date(a.timestamp || 0).getTime();
        bVal = new Date(b.timestamp || 0).getTime();
      } else if (sortBy === "action") {
        aVal = a.action || "";
        bVal = b.action || "";
      } else if (sortBy === "resource") {
        aVal = a.resource || "";
        bVal = b.resource || "";
      } else if (sortBy === "userID") {
        aVal = a.userID || "";
        bVal = b.userID || "";
      } else {
        aVal = a[sortBy] || "";
        bVal = b[sortBy] || "";
      }
 
      if (typeof aVal === "string") {
        aVal = aVal.toLowerCase();
        bVal = bVal.toLowerCase();
      }
 
      if (sortOrder === "asc") {
        return aVal > bVal ? 1 : aVal < bVal ? -1 : 0;
      } else {
        return aVal < bVal ? 1 : aVal > bVal ? -1 : 0;
      }
    });
 
  const resources = extractResourcesFromLogs(logs);
  const paginatedLogs = filteredLogs.slice(
    (currentPage - 1) * LOGS_PER_PAGE,
    currentPage * LOGS_PER_PAGE
  );
 
  const totalPages = Math.ceil(filteredLogs.length / LOGS_PER_PAGE);
 
  // CSV export helper
  function exportToCSV() {
    const headers = [
      "Audit ID",
      "Timestamp",
      "User",
      "Action",
      "Resource",
      "Resource ID",
      "Details",
    ];
    const rows = filteredLogs.map((log) => [
      log.auditID || log.AuditID || "",
      log.timestamp || "",
      log.userName || "",
      log.action || "",
      log.resource || "",
      log.resourceID || log.ResourceID || "",
      log.details || "",
    ]);
    const csvContent = [
      headers.join(","),
      ...rows.map((row) =>
        row
          .map((field) => `"${String(field).replace(/"/g, '""')}"`)
          .join(",")
      ),
    ].join("\r\n");
 
    const blob = new Blob([csvContent], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "audit-logs.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
 
  const handleSort = (field) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(field);
      setSortOrder("desc");
    }
    setCurrentPage(1);
  };
 
  const SortIcon = ({ field }) => {
    if (sortBy !== field) return null;
    return sortOrder === "asc" ? (
      <ChevronUp className="size-4" />
    ) : (
      <ChevronDown className="size-4" />
    );
  };
 
  return (
    <div className="space-y-6">
      {/* ── Header ── */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Audit Log</h1>
          <p className="text-gray-600 mt-1">
            Immutable record of all user actions across PharmaShelf
          </p>
        </div>
      </div>
 
      {/* ── Summary Cards ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[
          {
            label: "Total Events",
            value: logs.length,
            icon: Activity,
            color: "bg-blue-500",
          },
          {
            label: "Unique Users",
            value: new Set(logs.map((l) => l.userID)).size,
            icon: Users,
            color: "bg-purple-500",
          },
          {
            label: "Logins in last 24 Hours",
            value: (() => {
              const now = new Date();
              const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
              const loginUserIDs = new Set(
                logs
                  .filter((log) => {
                    try {
                      const logTime = new Date(log.timestamp);
                      return (
                        log.action === "LOGIN" &&
                        logTime >= oneDayAgo &&
                        logTime <= now
                      );
                    } catch {
                      return false;
                    }
                  })
                  .map((log) => log.userID)
              );
              return loginUserIDs.size;
            })(),
            icon: Clock,
            color: "bg-green-500",
          },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="text-gray-600 text-sm font-medium">{label}</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">{value}</p>
              </div>
              <div className={`${color} p-3 rounded-lg`}>
                <Icon className="size-6 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>
 
      {/* ── Filters ── */}
      <div className="bg-white rounded-xl border p-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          {/* Search bar on the left */}
          <div className="flex items-center">
            <div className="relative" style={{ minWidth: 0, width: '220px' }}>
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
              <input
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="Search"
                className="w-full pl-9 pr-4 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#3C8C85]"
                style={{ maxWidth: 200 }}
              />
            </div>
          </div>
          {/* Filters and Export button on the right */}
          <div className="flex flex-col sm:flex-row gap-3 items-center">
            {/* Action filter */}
            <select
              value={actionFilter}
              onChange={(e) => {
                setActionFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#3C8C85]"
            >
              {ALL_ACTIONS.map((a) => (
                <option key={a} value={a}>
                  {a === "ALL" ? "All actions" : ACTION_META[a]?.label || a}
                </option>
              ))}
            </select>
            {/* Date range filters */}
            <input
              type="date"
              value={timestampFrom}
              onChange={(e) => {
                setTimestampFrom(e.target.value);
                setCurrentPage(1);
              }}
              className="border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#3C8C85]"
              style={{ minWidth: 0, width: '140px' }}
            />
            <input
              type="date"
              value={timestampTo}
              onChange={(e) => {
                setTimestampTo(e.target.value);
                setCurrentPage(1);
              }}
              className="border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#3C8C85]"
              style={{ minWidth: 0, width: '140px' }}
            />
            {/* Export button at extreme right */}
            <button
              type="button"
              onClick={exportToCSV}
              disabled={filteredLogs.length === 0}
              className="ml-2 px-4 py-2 bg-[#3C8C85] text-white rounded-lg hover:bg-[#36766F] text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Export
            </button>
          </div>
        </div>
      </div>
 
      {/* ── Table ── */}
      <div className="bg-white rounded-xl border overflow-hidden">
        {loading ? (
          <div className="p-10 text-center text-gray-500">Loading audit logs…</div>
        ) : error ? (
          <div className="p-10 text-center text-red-600">{error}</div>
        ) : logs.length === 0 ? (
          <div className="p-10 text-center text-gray-500">
            No audit logs found in database. Debug info: {JSON.stringify(logs).slice(0, 100)}
          </div>
        ) : filteredLogs.length === 0 ? (
          <div className="p-10 text-center text-gray-500">
            No audit entries match your filters.
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[900px] text-sm">
                <thead style={{ backgroundColor: "#3C8C85" }}>
                  <tr>
                    <th
                      onClick={() => handleSort("timestamp")}
                      className="px-6 py-4 text-center text-base font-bold tracking-wide cursor-pointer hover:bg-[#2e5e5a]"
                      style={{ color: '#fff' }}
                    >
                      <div className="flex items-center gap-2 justify-center">
                        Timestamp
                        <SortIcon field="timestamp" />
                      </div>
                    </th>
                    <th className="px-6 py-4 text-center text-base font-bold tracking-wide" style={{ color: '#fff' }}>
                      User
                    </th>
                    <th
                      className="px-6 py-4 text-center text-base font-bold tracking-wide"
                      style={{ color: '#fff' }}
                    >
                      Action
                    </th>
                    <th className="px-6 py-4 text-center text-base font-bold tracking-wide" style={{ color: '#fff' }}>
                      Details
                    </th>
                  </tr>
                </thead>
 
                <tbody className="divide-y divide-gray-100">
                  {paginatedLogs.map((log) => {
                    const meta = ACTION_META[log.action] ?? {
                      label: log.action,
                      icon: ShieldCheck,
                      color: "bg-gray-100 text-gray-600",
                    };
                    const ActionIcon = meta.icon;
 
                    return (
                      <tr
                        key={log.auditID || log.AuditID}
                        className="hover:bg-gray-50 transition-colors"
                      >
                        {/* Timestamp */}
                        <td className="px-6 py-4 text-gray-600 whitespace-nowrap text-center">
                          {formatTimestamp(log.timestamp)}
                        </td>
 
                        {/* User */}
                        <td className="px-6 py-4 text-gray-900 whitespace-nowrap text-center">
                          {userMap[log.userID] || log.userID || "—"}
                        </td>
 
                        {/* Action badge */}
                        <td className="px-6 py-4 text-center">
                          <span
                            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${meta.color}`}
                          >
                            <ActionIcon className="size-3" />
                            {meta.label}
                          </span>
                        </td>
 
                        {/* Details */}
                        <td
                          className="px-6 py-4 text-gray-500 max-w-xs truncate text-center"
                          title={log.details}
                        >
                          {log.details || "—"}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
 
            {/* Pagination */}
            {totalPages > 1 && (
              <div className="px-4 py-2 border-t bg-gray-50 flex items-center justify-between gap-2">
                <div className="text-xs text-gray-600 whitespace-nowrap">
                  Showing {(currentPage - 1) * LOGS_PER_PAGE + 1} to{" "}
                  {Math.min(currentPage * LOGS_PER_PAGE, filteredLogs.length)} of{" "}
                  {filteredLogs.length} entries
                </div>
 
                <div className="flex gap-1">
                  <button
                    onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                    disabled={currentPage === 1}
                    className="px-2 py-1 border rounded text-xs hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Prev
                  </button>
                  {Array.from({ length: totalPages }, (_, i) => i + 1)
                    .slice(Math.max(0, currentPage - 2), Math.min(totalPages, currentPage + 1))
                    .map((page) => (
                      <button
                        key={page}
                        onClick={() => setCurrentPage(page)}
                        className={`px-2 py-1 border rounded text-xs ${
                          currentPage === page
                            ? "bg-[#3C8C85] text-white border-[#3C8C85]"
                            : "hover:bg-gray-100"
                        }`}
                      >
                        {page}
                      </button>
                    ))}
                  <button
                    onClick={() =>
                      setCurrentPage(Math.min(totalPages, currentPage + 1))
                    }
                    disabled={currentPage === totalPages}
                    className="px-2 py-1 border rounded text-xs hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
 
          </>
        )}
      </div>
    </div>
  );
}