import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, Bell, FileText, Package, XCircle } from "lucide-react";
import { API_BASE_URL } from "../../services/apiClient";
 
const NOTIFICATIONS_BASE_URL =
  import.meta.env.VITE_NOTIFICATIONS_BASE_URL || "";
 
const getNotificationsUrl = (path) =>
  NOTIFICATIONS_BASE_URL
    ? `${NOTIFICATIONS_BASE_URL}/pharmaShelf/notifications/${path}`
    : `/pharmaShelf/notifications/${path}`;
 
function decodeJWT(token) {
  try {
    const payload = token.split(".")[1];
    return JSON.parse(atob(payload));
  } catch {
    return null;
  }
}
 
function extractUserIdFromToken() {
  const token = localStorage.getItem("authToken");
  if (!token) return null;
 
  const decoded = decodeJWT(token);
  if (!decoded) return null;
 
  return (
    decoded.userId ??
    decoded.userID ??
    decoded.userid ??
    decoded.UserID ??
    decoded.id ??
    decoded.uid ??
    decoded.user?.userId ??
    decoded.user?.userID ??
    decoded.user?.id ??
    null
  );
}
 
function isAdministratorRole(role) {
  return (
    String(role || "")
      .replace("ROLE_", "")
      .toUpperCase() === "ADMINISTRATOR"
  );
}
 
function getNotificationIcon(category = "") {
  const normalizedCategory = String(category).toUpperCase();
 
  if (normalizedCategory === "EXPIRY") return AlertTriangle;
  if (normalizedCategory === "STOCK") return Package;
  if (normalizedCategory === "RECALL") return XCircle;
  if (normalizedCategory === "PO") return FileText;
 
  return Bell;
}
 
function getRelativeTime(createdAt) {
  if (!createdAt) return "Just now";
 
  const date = new Date(createdAt);
  if (Number.isNaN(date.getTime())) return "Just now";
 
  const diffMs = Date.now() - date.getTime();
  const diffMinutes = Math.floor(diffMs / (1000 * 60));
 
  if (diffMinutes < 1) return "Just now";
  if (diffMinutes < 60) {
    return `${diffMinutes} minute${diffMinutes === 1 ? "" : "s"} ago`;
  }
 
  const diffHours = Math.floor(diffMinutes / 60);
  if (diffHours < 24) {
    return `${diffHours} hour${diffHours === 1 ? "" : "s"} ago`;
  }
 
  const diffDays = Math.floor(diffHours / 24);
  return `${diffDays} day${diffDays === 1 ? "" : "s"} ago`;
}
 
export function NotificationsPage() {
  const [notificationList, setNotificationList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
 
  const currentUser = JSON.parse(
    localStorage.getItem("pharmaShelfUser") || "null"
  );
 
  const targetUserId =
    currentUser?.userId ??
    currentUser?.userID ??
    currentUser?.userid ??
    currentUser?.UserID;
 
  const userEmail = currentUser?.email || "";
 
  const unreadCount = useMemo(
    () =>
      notificationList.filter(
        (item) => String(item.status || "").toUpperCase() === "UNREAD"
      ).length,
    [notificationList]
  );
 
  const markNotificationAsRead = async (notificationId) => {
    const token = localStorage.getItem("authToken");
    if (!token || !notificationId) return;
 
    const baseUrls = [NOTIFICATIONS_BASE_URL, API_BASE_URL].filter(
      (url, index, array) => url && array.indexOf(url) === index
    );
 
    if (!baseUrls.includes("")) {
      baseUrls.unshift("");
    }
 
    let success = false;
 
    for (const baseUrl of baseUrls) {
      try {
        const response = await fetch(
          baseUrl
            ? `${baseUrl}/pharmaShelf/notifications/markAsRead/${notificationId}`
            : getNotificationsUrl(`markAsRead/${notificationId}`),
          {
            method: "PUT",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
 
        if (response.ok) {
          success = true;
          break;
        }
      } catch {
        // try next base URL
      }
    }
 
    if (success) {
      setNotificationList((prev) =>
        prev.map((item) => {
          const itemId = item.notificationID ?? item.notificationId;
          return itemId === notificationId
            ? { ...item, status: "READ" }
            : item;
        })
      );
    }
  };
 
  useEffect(() => {
    const fetchNotifications = async () => {
      const token = localStorage.getItem("authToken");
      if (!token) {
        console.log("⚠️ No auth token found");
        setLoading(false);
        setNotificationList([]);
        return;
      }

      let resolvedUserId = targetUserId;
      console.log("📍 Initial targetUserId:", targetUserId);

      if (!resolvedUserId) {
        resolvedUserId = extractUserIdFromToken();
        console.log("📍 Extracted userId from token:", resolvedUserId);
      }

      if (userEmail) {
        try {
          const usersResponse = await fetch(
            `${API_BASE_URL}/pharmaShelf/users/fetchAllUsers`,
            {
              method: "GET",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`,
              },
            }
          );

          if (usersResponse.ok) {
            const users = await usersResponse.json();
            if (Array.isArray(users)) {
              const match = users.find(
                (item) =>
                  String(item.email || "").toLowerCase() ===
                  String(userEmail).toLowerCase()
              );

              const userIdFromLookup =
                match?.userID ?? match?.userId ?? null;

              if (userIdFromLookup) {
                resolvedUserId = userIdFromLookup;
                console.log("📍 Resolved userId from user lookup:", userIdFromLookup);
              }

              if (resolvedUserId) {
                localStorage.setItem(
                  "pharmaShelfUser",
                  JSON.stringify({
                    ...currentUser,
                    userId: resolvedUserId,
                  })
                );
              }
            }
          }
        } catch (err) {
          console.error("❌ Failed to lookup user:", err);
          resolvedUserId = null;
        }
      }

      if (!resolvedUserId) {
        console.error("❌ Could not resolve userId. Aborting fetch.");
        setLoading(false);
        setNotificationList([]);
        setError("Unable to identify user. Please log in again.");
        return;
      }

      console.log("✅ Final resolved userId:", resolvedUserId);

      try {
        setLoading(true);
        setError("");

        const requestOptions = {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        };

        const baseUrls = [NOTIFICATIONS_BASE_URL, API_BASE_URL].filter(
          (url, index, array) => url && array.indexOf(url) === index
        );

        if (!baseUrls.includes("")) {
          baseUrls.unshift("");
        }

        let response = null;
        for (const baseUrl of baseUrls) {
          try {
            const url = baseUrl
              ? `${baseUrl}/pharmaShelf/notifications/fetchNotificationsByUserId/${resolvedUserId}`
              : getNotificationsUrl(
                  `fetchNotificationsByUserId/${resolvedUserId}`
                );
            
            console.log(`🔍 Attempting to fetch notifications from: ${url}`);
            
            const attempt = await fetch(url, requestOptions);
            
            console.log(`📡 Response status: ${attempt.status} from ${baseUrl || 'default'}`);

            if (attempt.status === 404) {
              response = attempt;
              continue;
            }

            response = attempt;
            break;
          } catch (err) {
            console.error(`❌ Fetch failed for baseUrl "${baseUrl}":`, err);
            response = null;
          }
        }

        if (!response) {
          console.error("❌ No valid response received from any endpoint");
          setNotificationList([]);
          setError("Unable to load notifications. Backend service may be unavailable.");
          return;
        }

        if (response.status === 404) {
          console.log("ℹ️ No notifications found (404)");
          setNotificationList([]);
          setError("");
          return;
        }

        if (!response.ok) {
          const errorText = await response.text();
          console.error(`❌ Response error: ${response.status} - ${errorText}`);
          setNotificationList([]);
          setError(`Unable to load notifications. Server error: ${response.status}`);
          return;
        }

        const payload = await response.json();
        console.log("✅ Notifications fetched:", payload);
        setNotificationList(
          Array.isArray(payload?.notifications) ? payload.notifications : []
        );
      } catch (err) {
        console.error("❌ Notification page fetch failed:", err);
        setNotificationList([]);
        setError("Unable to load notifications. Please try again later.");
      } finally {
        setLoading(false);
      }
    };
 
    fetchNotifications();
  }, [targetUserId, userEmail]);
 
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Notifications</h1>
        <p className="text-gray-600 mt-1">
          All alerts for your account ({unreadCount} unread)
        </p>
      </div>
 
      <div className="bg-white rounded-xl border overflow-hidden">
        {loading ? (
          <div className="p-6 text-gray-500">Loading notifications…</div>
        ) : error ? (
          <div className="p-6 text-red-600">{error}</div>
        ) : notificationList.length === 0 ? (
          <div className="p-6 text-gray-500">No notifications available.</div>
        ) : (
          <ul className="divide-y divide-gray-100">
            {notificationList.map((notification) => {
              const status = String(notification.status || "").toUpperCase();
              const isUnread = status === "UNREAD";
              const category = notification.category || "GENERAL";
              const Icon = getNotificationIcon(category);
              const notificationId =
                notification.notificationID ?? notification.notificationId;
 
              return (
                <li
                  key={notificationId}
                  onClick={() => {
                    if (isUnread) {
                      markNotificationAsRead(notificationId);
                    }
                  }}
                  className={`px-6 py-4 cursor-pointer ${
                    isUnread ? "bg-blue-50" : "bg-white"
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <Icon className="size-5 text-gray-600 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <p
                        className={`text-sm text-gray-900 ${
                          isUnread ? "font-semibold" : "font-normal"
                        }`}
                      >
                        {notification.message}
                      </p>
                      <div className="mt-1 flex items-center gap-2 text-xs text-gray-500">
                        <span className="uppercase tracking-wide">{category}</span>
                        <span>•</span>
                        <span>{getRelativeTime(notification.createdAt)}</span>
                      </div>
                    </div>
                    {isUnread && <span className="size-2 rounded-full bg-blue-500 mt-2" />}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}