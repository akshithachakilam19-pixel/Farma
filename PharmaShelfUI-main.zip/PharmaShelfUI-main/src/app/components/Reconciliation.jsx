import { useState, useEffect } from "react";
import { CheckCircle, AlertCircle, GitCompareArrows, MoreVertical, FileText, Pencil, X } from "lucide-react";
import {
  fetchAllReconciliations,
  updateReconciliation,
} from "../../services/reconciliationService";
 
export function Reconciliation() {
  const [variances, setVariances] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [openActionMenu, setOpenActionMenu] = useState(null);
  const [selectedReasonId, setSelectedReasonId] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editForm, setEditForm] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5);
 
  const loadReconciliations = async () => {
    setLoading(true);
    setError("");
    try {
      const data = await fetchAllReconciliations();
      setVariances(data);
    } catch (err) {
      setError(err.message || "Failed to load reconciliations");
    } finally {
      setLoading(false);
    }
  };
 
  useEffect(() => {
    loadReconciliations();
  }, []);
 
  const formatDateTime = (dateString) => {
    if (!dateString) return "-";
    return dateString.replace("T", " ");
  };
 
  const USER_NAMES = {
    "101": "John Smith",
    "102": "Sarah Johnson",
    "103": "Mike Chen",
    "4001": "Emma Davis",
    "4002": "Sarah Johnson",
    "4003": "Mike Chen",
  };
 
  const formatCountId = (countId) => {
    if (!countId) return "-";
    return String(countId).replace(/^Count\s*ID\s*/i, "").trim();
  };
 
  const formatAdjustedBy = (adjustedBy) => {
    if (!adjustedBy) return "-";
    const userId = String(adjustedBy).replace(/^User\s*/i, "").trim();
    return USER_NAMES[userId] || userId;
  };
 
  const reconciliationStats = {
    pendingVariances: variances.filter((v) => String(v.status).toLowerCase() === "pending").length,
    resolvedToday: variances.filter((v) => ["completed", "resolved", "accepted", "released"].includes(String(v.status).toLowerCase())).length,
    adjustmentValue: `${variances.reduce((sum, v) => sum + Math.abs(Number(v.variance) || 0), 0)} units`,
  };
 
  const sortedVariances = [...variances].sort((a, b) => {
    const aTime = a?.adjustedAt ? new Date(a.adjustedAt).getTime() : Number.POSITIVE_INFINITY;
    const bTime = b?.adjustedAt ? new Date(b.adjustedAt).getTime() : Number.POSITIVE_INFINITY;
    const safeA = Number.isNaN(aTime) ? Number.POSITIVE_INFINITY : aTime;
    const safeB = Number.isNaN(bTime) ? Number.POSITIVE_INFINITY : bTime;
    return safeA - safeB;
  });
 
  const totalPages = Math.max(1, Math.ceil(sortedVariances.length / rowsPerPage));
  const pagedVariances = sortedVariances.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );
 
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages);
    }
  }, [currentPage, totalPages]);
 
  useEffect(() => {
    setCurrentPage(1);
  }, [rowsPerPage]);
 
  const handleStatusUpdate = async (variance, nextStatus) => {
    setOpenActionMenu(null);
    const previous = [...variances];
    setVariances((prev) =>
      prev.map((v) => (v.id === variance.id ? { ...v, status: nextStatus } : v))
    );
    try {
      await updateReconciliation(variance.reconId ?? variance.id, {
        reconId: variance.reconId ?? variance.id,
        countId: variance.countId,
        expectedQuantity: variance.expected,
        countedQuantity: variance.counted,
        variance: variance.variance,
        adjustedBy: variance.adjustedBy,
        adjustedAt: variance.adjustedAt,
        status: nextStatus,
      });
    } catch (err) {
      setVariances(previous);
      setError(err.message || "Failed to update reconciliation status");
    }
  };
 
  const goToReason = (id) => {
    setSelectedReasonId(id);
    setOpenActionMenu(null);
  };
 
  const openEdit = (variance) => {
    setEditForm({ ...variance });
    setShowEditModal(true);
    setOpenActionMenu(null);
  };
 
  const handleEditSubmit = async (e) => {
    e.preventDefault();
    const previous = [...variances];
    setVariances((prev) => prev.map((v) => v.id === editForm.id ? { ...v, ...editForm } : v));
    setShowEditModal(false);
    try {
      await updateReconciliation(editForm.reconId ?? editForm.id, {
        reconId: editForm.reconId ?? editForm.id,
        countId: editForm.countId,
        expectedQuantity: Number(editForm.expected),
        countedQuantity: Number(editForm.counted),
        variance: Number(editForm.counted) - Number(editForm.expected),
        adjustedBy: editForm.adjustedBy,
        adjustedAt: editForm.adjustedAt,
        status: editForm.status,
      });
    } catch (err) {
      setVariances(previous);
      setError(err.message || "Failed to update reconciliation");
    }
  };
 
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Reconciliation</h1>
          <p className="text-gray-600 mt-1">Review, approve, and resolve stock variances</p>
        </div>
      </div>
 
      {error && (
        <div className="flex items-center justify-between bg-red-50 border border-red-200 rounded-lg px-4 py-3">
          <p className="text-sm text-red-700">{error}</p>
          <button
            onClick={() => setError("")}
            className="text-red-400 hover:text-red-600 ml-4 text-lg leading-none"
          >
            &times;
          </button>
        </div>
      )}
 
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Pending Variances</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{reconciliationStats.pendingVariances}</p>
            </div>
            <div className="bg-orange-500 p-3 rounded-lg">
              <AlertCircle className="size-6 text-white" />
            </div>
          </div>
        </div>
 
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Resolved Today</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{reconciliationStats.resolvedToday}</p>
            </div>
            <div className="bg-green-500 p-3 rounded-lg">
              <CheckCircle className="size-6 text-white" />
            </div>
          </div>
        </div>
 
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Adjustment Value</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{reconciliationStats.adjustmentValue}</p>
            </div>
            <div className="bg-brand-500 p-3 rounded-lg">
              <GitCompareArrows className="size-6 text-white" />
            </div>
          </div>
        </div>
      </div>
 
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-6 border-b border-green-200 bg-green-50">
          <h2 className="text-lg font-semibold text-gray-900">Pending Variance Reconciliation</h2>
          <p className="text-sm text-gray-600 mt-1">Review and approve stock adjustments</p>
        </div>
        <div className="overflow-x-hidden">
          <table className="w-full table-auto">
            <thead style={{ backgroundColor: '#3C8C85' }} className="border-b border-[#3C8C85]/20">
              <tr>
                <th className="px-2 py-2 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Rec Id</th>
                <th className="px-2 py-2 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Adjusted By</th>
                <th className="px-2 py-2 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Expected</th>
                <th className="px-2 py-2 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Counted</th>
                <th className="px-2 py-2 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Adjusted At</th>
                <th className="px-2 py-2 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Status</th>
                <th className="px-2 py-2 text-center text-[11px] font-semibold uppercase tracking-wide" style={{ color: '#fff' }}>Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {!loading && pagedVariances.map((variance) => (
                <tr key={variance.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-2 py-3 text-center">
                    <span className="text-sm text-gray-700">{variance.batch}</span>
                  </td>
                  <td className="px-2 py-3 text-center">
                    <span className="text-sm text-gray-700">{formatAdjustedBy(variance.location)}</span>
                  </td>
                  <td className="px-2 py-3 text-center">
                    <span className="text-sm text-gray-900">{variance.expected}</span>
                  </td>
                  <td className="px-2 py-3 text-center">
                    <span className="text-sm text-gray-900">{variance.counted}</span>
                  </td>
                  <td className="px-2 py-3 text-center">
                    <span className="text-sm text-gray-700">{formatDateTime(variance.adjustedAt)}</span>
                  </td>
                  <td className="px-2 py-3 text-center">
                    <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                      (() => {
                        const s = String(variance.status).toLowerCase();
                        if (s === "pending") return "bg-orange-100 text-orange-700";
                        if (s === "rejected") return "bg-red-100 text-red-700";
                        if (s === "adjusted") return "bg-blue-100 text-blue-700";
                        return "bg-green-100 text-green-700";
                      })()
                    }`}>
                      {variance.status}
                    </span>
                  </td>
                  <td className="px-2 py-3 text-center">
                    <div className="relative inline-block text-left">
                      <button
                        onClick={() =>
                          setOpenActionMenu(openActionMenu === variance.id ? null : variance.id)
                        }
                        className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                        aria-label="More actions"
                      >
                        <MoreVertical className="size-4 text-gray-700" />
                      </button>
 
                      {openActionMenu === variance.id && (
                        <div className="absolute right-0 z-20 mt-1 w-28 rounded-md border border-gray-200 bg-white shadow-lg">
                          <button
                            onClick={() => openEdit(variance)}
                            className="w-full px-3 py-2 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                          >
                            <Pencil className="size-3.5 text-blue-600" />
                            Edit
                          </button>
                          <button
                            onClick={() => handleStatusUpdate(variance, "Completed")}
                            className="w-full px-3 py-2 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                          >
                            <CheckCircle className="size-3.5 text-green-600" />
                            Accept
                          </button>
                          <button
                            onClick={() => handleStatusUpdate(variance, "Rejected")}
                            className="w-full px-3 py-2 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                          >
                            <AlertCircle className="size-3.5 text-red-600" />
                            Reject
                          </button>
                        </div>
                      )}
 
 
                    </div>
                  </td>
                </tr>
              ))}
 
              {!loading && pagedVariances.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-3 py-8 text-center text-sm text-gray-500">
                    No reconciliations found.
                  </td>
                </tr>
              )}
 
              {loading && (
                <tr>
                  <td colSpan={7} className="px-3 py-8 text-center text-sm text-gray-500">
                    Loading reconciliations...
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
 
        <div className="flex items-center justify-between border-t border-gray-200 px-4 py-3 bg-gray-50">
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-600">Rows per page</span>
            <select
              value={rowsPerPage}
              onChange={(e) => setRowsPerPage(Number(e.target.value))}
              className="text-xs border border-gray-300 rounded-md px-2 py-1 bg-white text-gray-700"
            >
              <option value={5}>5</option>
              <option value={10}>10</option>
              <option value={15}>15</option>
            </select>
          </div>
 
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
              className="px-3 py-1.5 text-xs rounded-md border border-gray-300 bg-white text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Previous
            </button>
            <button
              onClick={() => setCurrentPage((prev) => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages}
              className="px-3 py-1.5 text-xs rounded-md border border-gray-300 bg-white text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next
            </button>
          </div>
        </div>
      </div>
 
      {showEditModal && editForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Edit Reconciliation</h2>
              <button onClick={() => setShowEditModal(false)} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <X className="size-5 text-gray-500" />
              </button>
            </div>
            <form onSubmit={handleEditSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Expected Qty</label>
                  <input type="number" value={editForm.expected} onChange={(e) => setEditForm((p) => ({ ...p, expected: e.target.value }))} required className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Counted Qty</label>
                  <input type="number" value={editForm.counted} onChange={(e) => setEditForm((p) => ({ ...p, counted: e.target.value }))} required className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Status</label>
                  <select value={editForm.status} onChange={(e) => setEditForm((p) => ({ ...p, status: e.target.value }))} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                    <option value="Pending">Pending</option>
                    <option value="Completed">Completed</option>
                    <option value="Rejected">Rejected</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button type="button" onClick={() => setShowEditModal(false)} className="px-4 py-2 text-sm text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50">Cancel</button>
                <button type="submit" className="px-4 py-2 text-sm bg-brand-600 text-white rounded-lg hover:bg-brand-700">Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
