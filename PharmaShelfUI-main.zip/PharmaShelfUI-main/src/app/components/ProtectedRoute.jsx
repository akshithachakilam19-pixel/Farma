import { Navigate } from "react-router-dom";
import { authAPI } from "../../services/authService";

/**
 * Protected Route Component
 * Redirects to login if not authenticated
 * Redirects to unauthorized if user doesn't have required roles
 */
export function ProtectedRoute({ children, allowedRoles = [] }) {
  if (!authAPI.isAuthenticated()) {
    return <Navigate to="/login" replace />;
  }

  // If specific roles are required, check if user has them
  if (allowedRoles.length > 0 && !authAPI.hasAnyRole(allowedRoles)) {
    return (
      <div style={{ 
        padding: "20px", 
        textAlign: "center",
        color: "#d32f2f"
      }}>
        <h2>Access Denied</h2>
        <p>You don't have permission to access this page.</p>
        <p>Required roles: {allowedRoles.join(", ")}</p>
      </div>
    );
  }

  return children;
}

export default ProtectedRoute;
