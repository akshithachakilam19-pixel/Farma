import { useState } from "react";
import { X } from "lucide-react";
import { usersAPI } from "../../services/api";
import {
  ROLE_DEFINITIONS,
  ASSIGNABLE_ROLES,
  ALL_ROLES,
} from "../constants/roleConstants";
 
export function EditUserModal({ user, onClose, onUserUpdated }) {
  const [formData, setFormData] = useState({
    name: user.name,
    phone: user.phone,
    role: user.role, // ✅ enum only
  });
 
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
 
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
 
    try {
      // ✅ ENTERPRISE-SAFE PAYLOAD
      const payload = {
        userID: user.userID,  // ✅ MUST match DTO
        name: formData.name,
        email: user.email,    // ✅ required
        role: formData.role,  // ✅ enum
        phone: formData.phone,
        status: user.status,  // ✅ preserve
        // ❌ password NOT sent
      };
 
      const updatedUser = await usersAPI.update(user.userID, payload);
      onUserUpdated(updatedUser);
      onClose();
    } catch (err) {
      console.error("Update user failed:", err);
      setError("Failed to update user");
    } finally {
      setLoading(false);
    }
  };
 
  const inputClass =
    "w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none";
 
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <X className="size-5" />
        </button>
 
        <h2 className="text-xl font-bold mb-4">Edit User</h2>
 
        {error && (
          <div className="mb-3 text-sm text-red-600">{error}</div>
        )}
 
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium">Name</label>
            <input
              name="name"
              className={inputClass}
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>
 
          <div>
            <label className="text-sm font-medium">Email</label>
            <input
              className={`${inputClass} bg-gray-100`}
              value={user.email}
              disabled
            />
          </div>
 
          <div>
            <label className="text-sm font-medium">Phone</label>
            <input
              name="phone"
              className={inputClass}
              value={formData.phone}
              onChange={handleChange}
              required
            />
          </div>
 
          <div>
            <label className="text-sm font-medium">Role</label>
            <select
              name="role"
              className={inputClass}
              value={formData.role}
              onChange={handleChange}
              required
            >
              {ALL_ROLES.map((role) => (
                <option key={role} value={role}>
                  {ROLE_DEFINITIONS[role].label}
                </option>
              ))}
            </select>
          </div>
 
          <button
            type="submit"
            disabled={loading}
            className="w-full mt-4 py-2 bg-[#3C8C85] text-white rounded-lg hover:bg-[#36766F] disabled:opacity-50"
          >
            {loading ? "Updating..." : "Update"}
          </button>
        </form>
      </div>
    </div>
  );
}