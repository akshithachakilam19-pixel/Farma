import React, { useEffect, useState, useRef } from "react";
import { Package, Layers, CheckCircle2, XCircle } from "lucide-react";
import Product from "./Product";
import Batch from "./Batch";
import { productsAPI, batchesAPI } from "../../services/api";
 
export function ProductMaster() {
  const [activeTab, setActiveTab] = useState("product");
  const [loading, setLoading] = useState(false);
 
  const [products, setProducts] = useState([]);
  const [batches, setBatches] = useState([]);
 
  const [toast, setToast] = useState(null);
  const toastTimer = useRef(null);
 
  function showToast(msg, type = "success") {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast({ message: msg, type });
    toastTimer.current = setTimeout(() => setToast(null), 3000);
  }
 
  async function loadData() {
    setLoading(true);
    try {
      const [productsData, batchesData] = await Promise.all([
        productsAPI.getAll().catch(() => []),
        batchesAPI.getAll().catch(() => []),
      ]);
      setProducts(Array.isArray(productsData) ? productsData : []);
      setBatches(Array.isArray(batchesData) ? batchesData : []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }
 
  useEffect(() => {
    loadData();
  }, []);
 
  return (
    <div className="space-y-3 p-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-gray-900">Product Master & Batch Management</h1>
          <p className="text-gray-500 text-xs mt-0.5">Manage your pharmaceutical product catalog and batch inventory</p>
        </div>
      </div>
 
      {/* Summary Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {[
          {
            label: "Total Products",
            value: products.length,
            icon: Package,
            color: "bg-emerald-500",
          },
          {
            label: "Total Batches",
            value: batches.length,
            icon: Layers,
            color: "bg-purple-500",
          },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="text-gray-600 text-sm font-medium">{label}</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">{value}</p>
              </div>
              <div className={`${color} p-3 rounded-lg`}>
                <Icon className="size-6 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>
 
      {/* Tab Navigation */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="border-b border-gray-200">
          <div className="flex">
            {[
              { key: 'product', label: `Product (${products.length})` },
              { key: 'batch', label: `Batch (${batches.length})` },
            ].map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex-1 px-6 py-2 text-sm font-semibold transition-colors whitespace-nowrap ${
                  activeTab === tab.key
                    ? 'text-[#3C8C85] border-b-2 border-[#3C8C85] bg-[#3C8C85]/10'
                    : 'text-gray-500 hover:text-[#3C8C85] hover:bg-[#3C8C85]/5'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>
 
      {/* Tab Content */}
      <div>
        {activeTab === 'product' && (
          <Product
            allProducts={products}
            allBatches={batches}
            onDataChange={loadData}
            showToast={showToast}
          />
        )}
 
        {activeTab === 'batch' && (
          <Batch
            allBatches={batches}
            allProducts={products}
            showToast={showToast}
            onDataChange={loadData}
          />
        )}
      </div>
 
      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-4 right-4 z-50">
          <div className={`min-w-[280px] max-w-[420px] rounded-xl border px-4 py-3 shadow-lg backdrop-blur-sm ${
            toast.type === "success"
              ? "bg-emerald-50 border-emerald-200 text-emerald-800"
              : "bg-red-50 border-red-200 text-red-800"
          }`}>
            <div className="flex items-start gap-2">
              {toast.type === "success" ? (
                <CheckCircle2 className="size-5 mt-0.5 text-emerald-600" />
              ) : (
                <XCircle className="size-5 mt-0.5 text-red-600" />
              )}
              <p className="text-sm font-medium">{toast.message}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
 
export default ProductMaster;