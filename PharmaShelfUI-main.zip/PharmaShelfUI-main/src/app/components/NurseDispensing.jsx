import { useEffect, useMemo, useRef, useState } from "react";
import { CheckCircle, XCircle, Clock, AlertCircle, MoreVertical, Search, Plus, X, Trash2 } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { dispensingAPI } from "../../services/api";
import { productsAPI, batchesAPI } from "../../services/api";

// Toast Component
function Toast({ message, type = "success", onClose }) {
  return (
    <div
      className={`fixed top-5 right-5 z-50 px-4 py-3 rounded-lg shadow-lg
        text-white animate-slide-in
        ${type === "success" ? "bg-green-600" : type === "error" ? "bg-red-600" : "bg-blue-600"}`}
    >
      {message}
      <button onClick={onClose} className="ml-3 font-bold">
        ×
      </button>
    </div>
  );
}

export function NurseDispensing() {
  const currentUser = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem("pharmaShelfUser") || "{}");
    } catch {
      return {};
    }
  }, []);

  const currentUserId =
    currentUser?.userId ?? currentUser?.id ?? currentUser?.userID ?? null;
  const currentUserName =
    currentUser?.name || currentUser?.email || "Staff";

  // Ward options with IDs
  const wardOptions = [
    { id: 1, name: "General" },
    { id: 2, name: "Medical" },
    { id: 3, name: "Surgery" },
    { id: 4, name: "ICU" },
    { id: 5, name: "Emergency/ER" },
    { id: 6, name: "Maternity" },
    { id: 7, name: "Pediatrics" },
    { id: 8, name: "Oncology" },
    { id: 9, name: "Psychiatric" },
    { id: 10, name: "Isolation" },
    { id: 11, name: "Rehab" },
    { id: 12, name: "Private" },
  ];

  const [activeTab, setActiveTab] = useState("requests");
  const [searchQuery, setSearchQuery] = useState("");
  const [toast, setToast] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const [requests, setRequests] = useState([]);
  const [products, setProducts] = useState([]);
  const [batches, setBatches] = useState([]);

  // Form state
  const [showForm, setShowForm] = useState(false);
  const [newRequest, setNewRequest] = useState({
    patientId: "",
    wardId: "",
    productId: "",
    quantity: "",
    reason: "",
    batchId: "",
  });
  const [formErrors, setFormErrors] = useState({});

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const PAGE_SIZE = 10;

  // Actions menu state
  const [openActionsMenu, setOpenActionsMenu] = useState(null);
  const actionsMenuRef = useRef(null);

  // Load all data in parallel
  const loadAllData = async () => {
    try {
      setLoading(true);
      setError("");
      
      // Try to fetch from both requested and approved endpoints since getAll might not return data
      const [requestedData, approvedData, productsData, batchesData] = await Promise.all([
        dispensingAPI.getRequestedDispenses().catch(() => []),
        dispensingAPI.getApprovedDispenses().catch(() => []),
        productsAPI.getAll().catch(() => []),
        batchesAPI.getAll().catch(() => []),
      ]);

      console.log("🔍 Raw API Response - Requested:", requestedData);
      console.log("🔍 Raw API Response - Approved:", approvedData);
      console.log("🔍 Raw API Response - Products:", productsData);
      console.log("🔍 Raw API Response - Batches:", batchesData);

      // Extract data from wrapped responses
      const requestedArray = Array.isArray(requestedData) ? requestedData : (requestedData?.data || []);
      const approvedArray = Array.isArray(approvedData) ? approvedData : (approvedData?.data || []);
      const productsArray = Array.isArray(productsData) ? productsData : (productsData?.data || []);
      const batchesArray = Array.isArray(batchesData) ? batchesData : (batchesData?.data || []);

      // Combine both requested and approved data
      const requestsData = [...requestedArray, ...approvedArray];
      
      console.log("📌 Combined Requests:", requestsData);

      const requestsRows = Array.isArray(requestsData) ? requestsData : [];
      console.log("📌 Requests Rows (after array check):", requestsRows);
      
      const productsRows = Array.isArray(productsArray) ? productsArray : [];
      
      // Create a product map for quick lookup
      const productMap = {};
      productsRows.forEach(product => {
        const prodId = product.productId || product.id;
        productMap[prodId] = product.name || product.productName || `Product ${prodId}`;
      });

      // Normalize requests with product names
      const normalized = requestsRows.map(row => normalizeRequest(row, productMap));
      console.log("📋 Normalized Requests:", normalized);
      console.log("🔍 Request Statuses:", normalized.map(r => r.status));
      setRequests(normalized);

      const activeProducts = productsRows.filter((product) => {
        const status = String(product.status || "").trim().toUpperCase();
        const isActive = product.isActive !== false;
        return status === "ACTIVE" && isActive;
      });
      setProducts(activeProducts);

      // Filter batches - exclude expired and near expired (within 30 days)
      const batchesRows = Array.isArray(batchesArray) ? batchesArray : [];
      const now = new Date();
      const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      
      const availableBatches = batchesRows.filter(batch => {
        const expiryDate = batch.expiryDate ? new Date(batch.expiryDate) : null;
        const isExpired = expiryDate && expiryDate < now;
        const isNearExpiry = expiryDate && expiryDate <= thirtyDaysFromNow && expiryDate > now;
        const isQuarantined = String(batch.status || "").toUpperCase() === "QUARANTINED";
        const hasQuantity = Number(batch.quantityAvailable || batch.quantity || 0) > 0;
        
        return !isExpired && !isNearExpiry && !isQuarantined && hasQuantity;
      });
      setBatches(availableBatches);
    } catch (err) {
      console.error("Failed to fetch data:", err);
      setError(err?.message || "Failed to load data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  const normalizeRequest = (row, productMap = {}) => {
    const id = row?.dispenseID ?? row?.dispenseId ?? row?.id;
    const patientId = row?.patientID ?? row?.patientId ?? "";
    const ward = row?.wardID ?? row?.wardId ?? "";
    const productId = row?.productID ?? row?.productId ?? "";
    const purpose = row?.purpose ?? "";
    const status = String(row?.status || "PENDING").toUpperCase();

    return {
      id,
      batchId: row?.batchID ?? row?.batchId ?? null,
      productId,
      productName: row?.productName || productMap[productId] || `Product ${productId}`,
      patientId,
      ward,
      quantity: Number(row?.quantity ?? 0),
      purpose,
      reason: purpose,
      status,
      requestedBy: row?.requestedBy || row?.createdBy || row?.nurseName || null,
      requestedByRole: row?.requestedByRole || row?.createdByRole || row?.role || "User",
      requestedByUserId: row?.requestedByUserId || row?.createdByUserId || row?.nurseId || null,
      requestedAt: row?.requestedAt || row?.createdAt || "-",
      approvedBy: row?.approvedBy || null,
      approvedAt: row?.approvedAt || null,
      rejectedBy: row?.rejectedBy || null,
      rejectedAt: row?.rejectedAt || null,
      rejectionReason: row?.rejectionReason || null,
      dispensedBy: row?.dispensedBy ?? null,
      dispensedAt: row?.dispensedAt ?? null,
    };
  };

  const showToast = (message, type = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const deleteRequest = async (requestId) => {
    if (!window.confirm("Are you sure you want to delete this request?")) {
      return;
    }

    try {
      await dispensingAPI.delete(requestId);
      showToast("Request deleted successfully!");
      loadAllData();
    } catch (err) {
      showToast("Failed to delete request", "error");
      console.error(err);
    }
  };

  const validateForm = () => {
    const errors = {};
    if (!newRequest.patientId.trim()) errors.patientId = "Patient ID is required";
    if (!newRequest.wardId) errors.wardId = "Ward is required";
    if (!newRequest.productId) errors.productId = "Product is required";
    if (!newRequest.quantity || Number(newRequest.quantity) <= 0) errors.quantity = "Quantity must be greater than 0";
    if (!newRequest.reason.trim()) errors.reason = "Reason is required";
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const submitRequest = async () => {
    if (!validateForm()) {
      showToast("Please fill in all required fields", "error");
      return;
    }

    try {
      setSubmitting(true);
      const payload = {
        patientId: newRequest.patientId,
        wardId: Number(newRequest.wardId),
        productId: Number(newRequest.productId),
        quantity: Number(newRequest.quantity),
        reason: newRequest.reason,
        batchId: newRequest.batchId ? Number(newRequest.batchId) : null,
        requestedBy: currentUserName,
        requestedAt: new Date().toISOString(),
        status: "REQUESTED",
      };

      await dispensingAPI.requestDispense(payload);
      showToast("Request submitted successfully!");
      
      setNewRequest({
        patientId: "",
        wardId: "",
        productId: "",
        quantity: "",
        reason: "",
        batchId: "",
      });
      setShowForm(false);
      loadAllData();
    } catch (err) {
      showToast("Failed to submit request", "error");
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const myRequests = useMemo(() => {
    console.log("🔍 All Requests:", requests);
    // Show all requests since we're already filtering by requested/approved endpoints
    return requests;
  }, [requests]);

  // Helper function to get ward name by ID
  const getWardName = (wardId) => {
    const ward = wardOptions.find(w => w.id === Number(wardId));
    return ward ? ward.name : `Ward ${wardId}`;
  };

  const filteredRequests = useMemo(() => {
    const baseList = myRequests;
    return baseList.filter((r) => {
      const matchesSearch =
        !searchQuery ||
        r.productName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.patientId.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesSearch;
    });
  }, [myRequests, searchQuery]);

  const totalPages = Math.ceil(filteredRequests.length / PAGE_SIZE);
  const paginatedRequests = filteredRequests.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE
  );

  const selectedProduct = products.find(p => p.productId === Number(newRequest.productId) || p.id === Number(newRequest.productId));

  return (
    <div className="space-y-4 p-4">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Nurse - Dispensing Requests</h1>
        <p className="text-gray-600 text-sm mt-1">Create and manage your medication dispensing requests</p>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      {/* New Request Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center">
          <Card className="w-full max-w-2xl border-0 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-[#3C8C85]/10 to-transparent border-b">
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>New Medication Request</CardTitle>
                  <CardDescription>Fill in the form to submit a medication request</CardDescription>
                </div>
                <button
                  onClick={() => setShowForm(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Patient ID */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Patient ID <span className="text-red-500">*</span>
                  </label>
                  <Input
                    type="text"
                    placeholder="e.g. PAT-101"
                    value={newRequest.patientId}
                    onChange={(e) => {
                      setNewRequest({ ...newRequest, patientId: e.target.value });
                      if (formErrors.patientId) setFormErrors({ ...formErrors, patientId: "" });
                    }}
                    className={formErrors.patientId ? "border-red-500" : ""}
                  />
                </div>

                {/* Ward */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Ward <span className="text-red-500">*</span>
                  </label>
                  <Select value={newRequest.wardId} onValueChange={(value) => {
                    setNewRequest({ ...newRequest, wardId: value });
                    if (formErrors.wardId) setFormErrors({ ...formErrors, wardId: "" });
                  }}>
                    <SelectTrigger className={formErrors.wardId ? "border-red-500" : ""}>
                      <SelectValue placeholder="Select ward" />
                    </SelectTrigger>
                    <SelectContent>
                      {wardOptions.map((ward) => (
                        <SelectItem key={ward.id} value={String(ward.id)}>
                          {ward.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Product */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Product <span className="text-red-500">*</span>
                  </label>
                  <Select value={newRequest.productId} onValueChange={(value) => {
                    setNewRequest({ ...newRequest, productId: value });
                    if (formErrors.productId) setFormErrors({ ...formErrors, productId: "" });
                  }}>
                    <SelectTrigger className={formErrors.productId ? "border-red-500" : ""}>
                      <SelectValue placeholder="Select product" />
                    </SelectTrigger>
                    <SelectContent>
                      {products.map((product) => (
                        <SelectItem key={product.productId || product.id} value={String(product.productId || product.id)}>
                          {product.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Quantity */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Quantity <span className="text-red-500">*</span>
                  </label>
                  <Input
                    type="number"
                    placeholder="e.g. 10"
                    value={newRequest.quantity}
                    onChange={(e) => {
                      setNewRequest({ ...newRequest, quantity: e.target.value });
                      if (formErrors.quantity) setFormErrors({ ...formErrors, quantity: "" });
                    }}
                    min="1"
                    className={formErrors.quantity ? "border-red-500" : ""}
                  />
                </div>

                {/* Batch (Optional) */}
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Batch (Optional)
                  </label>
                  <Select value={newRequest.batchId} onValueChange={(value) => setNewRequest({ ...newRequest, batchId: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select batch (optional)" />
                    </SelectTrigger>
                    <SelectContent>
                      {batches.map((batch) => (
                        <SelectItem key={batch.batchId || batch.id} value={String(batch.batchId || batch.id)}>
                          {batch.batchNumber} - Exp: {batch.expiryDate}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Reason */}
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Reason <span className="text-red-500">*</span>
                  </label>
                  <Textarea
                    placeholder="Describe the reason for this medication request"
                    value={newRequest.reason}
                    onChange={(e) => {
                      setNewRequest({ ...newRequest, reason: e.target.value });
                      if (formErrors.reason) setFormErrors({ ...formErrors, reason: "" });
                    }}
                    rows={3}
                    className={formErrors.reason ? "border-red-500" : ""}
                  />
                </div>
              </div>

              {/* Form Actions */}
              <div className="mt-6 flex gap-3 justify-end border-t pt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowForm(false)}
                >
                  Cancel
                </Button>
                <Button
                  className="bg-[#3C8C85] hover:bg-[#2a6460] text-white"
                  onClick={submitRequest}
                  disabled={submitting}
                >
                  {submitting ? "Submitting..." : "Submit"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Tab Navigation with Add Button */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-4 border-b flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex gap-0">
            <div className="px-6 py-2 font-medium text-sm text-[#3C8C85] border-b-2 border-[#3C8C85]">
              Requests
              <span className="ml-2 text-gray-500">({myRequests.length})</span>
            </div>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center justify-center w-8 h-8 bg-[#3C8C85] hover:bg-[#337872] text-white rounded-md text-xs font-medium"
            title="New Request"
          >
            <Plus size={16} />
          </button>
        </div>

      {/* Search */}
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-3 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search by product name or patient ID..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            className="pl-10"
          />
        </div>
      </div>

      {/* Requests Table */}
      <Card>
        <CardHeader>
          <CardTitle>Dispensing Requests</CardTitle>
          <CardDescription>
            Total: {filteredRequests.length} requests
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-gray-500">Loading...</div>
          ) : paginatedRequests.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No requests found
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-[#3C8C85]">
                      <TableHead className="text-white">Product</TableHead>
                      <TableHead className="text-white">Patient ID</TableHead>
                      <TableHead className="text-white">Ward</TableHead>
                      <TableHead className="text-white">Quantity</TableHead>
                      <TableHead className="text-white">Status</TableHead>
                      <TableHead className="text-white">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedRequests.map((request) => (
                      <TableRow key={request.id}>
                        <TableCell className="font-medium">
                          {request.productName}
                        </TableCell>
                        <TableCell>{request.patientId}</TableCell>
                        <TableCell>{getWardName(request.ward)}</TableCell>
                        <TableCell>{request.quantity}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            request.status === "REQUESTED"
                              ? "bg-yellow-100 text-yellow-800"
                              : request.status === "APPROVED"
                              ? "bg-green-100 text-green-800"
                              : request.status === "REJECTED"
                              ? "bg-red-100 text-red-800"
                              : "bg-blue-100 text-blue-800"
                          }`}>
                            {request.status}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="relative inline-block">
                            <button
                              onClick={(e) => {
                                const rect = e.currentTarget.getBoundingClientRect();
                                const spaceBelow = window.innerHeight - rect.bottom;
                                const dir = spaceBelow < 90 ? 'up' : 'down';
                                setOpenActionsMenu(prev => prev?.id === request.id ? null : {
                                  id: request.id,
                                  dir,
                                  top: rect.bottom + 4,
                                  bottom: window.innerHeight - rect.top + 4,
                                  right: window.innerWidth - rect.right,
                                });
                              }}
                              className="p-1.5 rounded hover:bg-gray-100 text-gray-600 hover:text-gray-800"
                            >
                              <MoreVertical size={16} />
                            </button>
                            {openActionsMenu?.id === request.id && (
                              <div
                                ref={actionsMenuRef}
                                className="w-28 bg-white border border-gray-200 rounded-lg shadow-lg overflow-hidden"
                                style={{
                                  position: 'fixed',
                                  zIndex: 9999,
                                  right: openActionsMenu.right,
                                  ...(openActionsMenu.dir === 'up'
                                    ? { bottom: openActionsMenu.bottom }
                                    : { top: openActionsMenu.top }),
                                }}
                              >
                                <button
                                  onClick={() => { deleteRequest(request.id); setOpenActionsMenu(null); }}
                                  className="w-full px-3 py-1.5 text-left text-xs font-normal text-red-600 hover:bg-red-50 flex items-center gap-1.5 whitespace-nowrap"
                                >
                                  <Trash2 size={12} className="shrink-0" /> Delete
                                </button>
                              </div>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex justify-between items-center mt-4 pt-4 border-t">
                  <div className="text-sm text-gray-600">
                    Page {currentPage} of {totalPages}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                      disabled={currentPage === 1}
                    >
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        setCurrentPage(Math.min(totalPages, currentPage + 1))
                      }
                      disabled={currentPage === totalPages}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  </div>
  );
}

export default NurseDispensing;
