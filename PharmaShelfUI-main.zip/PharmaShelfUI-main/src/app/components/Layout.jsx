import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import {
  Bell,
  Search,
  Menu,
  LogOut,
  User,
  Settings,
  ChevronDown,
  AlertTriangle,
  Package,
  XCircle,
  FileText,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { API_BASE_URL } from "../../services/apiClient";
import { authAPI } from "../../services/api";

import {
  LAYOUT_NAV_ITEMS,
  ROLE_DISPLAY_MAP,
  LAYOUT_TEXT,
} from "../constants/layoutConstants";
import { normalizeRole } from "../constants/accessControl";

const NOTIFICATIONS_BASE_URL =
  import.meta.env.VITE_NOTIFICATIONS_BASE_URL || "";

const getNotificationsUrl = (path) =>
  NOTIFICATIONS_BASE_URL
    ? `${NOTIFICATIONS_BASE_URL}/pharmaShelf/notifications/${path}`
    : `/pharmaShelf/notifications/${path}`;

export function Layout() {
  const location = useLocation();
  const navigate = useNavigate();

  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isMobile, setIsMobile] = useState(false);
  const [notificationList, setNotificationList] = useState([]);
  const [showNotifDropdown, setShowNotifDropdown] = useState(false);
  const [notifError, setNotifError] = useState("");
  const [user, setUser] = useState(null);
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [openSidebarGroups, setOpenSidebarGroups] = useState({
    "Dispense & Returns": true,
  });

  const dropdownRef = useRef(null);
  const notifDropdownRef = useRef(null);

  const decodeJWT = (token) => {
    try {
      const payload = token.split(".")[1];
      return JSON.parse(atob(payload));
    } catch {
      return null;
    }
  };

  const extractUserIdFromToken = () => {
    const token = localStorage.getItem("authToken");
    if (!token) return null;

    const decoded = decodeJWT(token);
    if (!decoded) return null;

    return (
      decoded.userId ??
      decoded.userID ??
      decoded.userid ??
      decoded.UserID ??
      decoded.id ??
      decoded.uid ??
      decoded.user?.userId ??
      decoded.user?.userID ??
      decoded.user?.id ??
      null
    );
  };

  const isAdministratorRole = (role) =>
    String(role || "")
      .replace("ROLE_", "")
      .toUpperCase() === "ADMINISTRATOR";

  /* =========================
     Auth Check
  ========================= */
  useEffect(() => {
    const storedUser = localStorage.getItem("pharmaShelfUser");
    const token = localStorage.getItem("authToken");

    if (!storedUser || !token) {
      navigate("/login", { replace: true });
      return;
    }

    try {
      setUser(JSON.parse(storedUser));
    } catch {
      localStorage.clear();
      navigate("/login", { replace: true });
    }
  }, [navigate]);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 1024);
    };

    handleResize();
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  useEffect(() => {
    if (isMobile) {
      setSidebarOpen(false);
    }
  }, [isMobile]);

  /* =========================
     Close dropdown on outside click
  ========================= */
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target)
      ) {
        setShowProfileDropdown(false);
      }

      if (
        notifDropdownRef.current &&
        !notifDropdownRef.current.contains(event.target)
      ) {
        setShowNotifDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () =>
      document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  /* =========================
     Notifications API
  ========================= */
  const fetchNotificationsByUserId = async (targetUserId) => {
    const token = localStorage.getItem("authToken");
    if (!token || !targetUserId) {
      setNotificationList([]);
      return;
    }

    try {
      setNotifError("");
      const requestOptions = {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      };

      const baseUrls = [NOTIFICATIONS_BASE_URL, API_BASE_URL].filter(
        (url, index, array) => url && array.indexOf(url) === index
      );

      let response = null;

      for (const baseUrl of baseUrls) {
        try {
          const attempt = await fetch(
            baseUrl
              ? `${baseUrl}/pharmaShelf/notifications/fetchNotificationsByUserId/${targetUserId}`
              : getNotificationsUrl(
                  `fetchNotificationsByUserId/${targetUserId}`
                ),
            requestOptions
          );

          if (attempt.status === 404) {
            response = attempt;
            continue;
          }

          response = attempt;
          break;
        } catch {
          response = null;
        }
      }

      if (!response) {
        setNotificationList([]);
        setNotifError("Unable to load notifications.");
        return;
      }

      if (response.status === 403) {
        setNotificationList([]);
        setNotifError("You are not allowed to view notifications.");
        return;
      }

      if (response.status >= 500) {
        setNotificationList([]);
        setNotifError("Notifications are temporarily unavailable.");
        return;
      }

      if (response.status === 404) {
        setNotificationList([]);
        setNotifError("");
        return;
      }

      if (!response.ok) {
        setNotificationList([]);
        setNotifError("Unable to load notifications.");
        return;
      }

      const payload = await response.json();
      const notifications = Array.isArray(payload?.notifications)
        ? payload.notifications
        : [];

      setNotificationList(notifications);
    } catch (err) {
      console.error("Notification fetch failed:", err);
      setNotificationList([]);
      setNotifError("Unable to load notifications.");
    }
  };

  const resolveUserIdByEmail = async (email) => {
    const token = localStorage.getItem("authToken");
    if (!token || !email) return null;

    try {
      const response = await fetch(
        `${API_BASE_URL}/pharmaShelf/users/fetchAllUsers`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      // Handle 403 (user doesn't have permission to fetch all users)
      if (response.status === 403) {
        console.warn("User role does not have permission to fetch all users");
        return null;
      }

      if (!response.ok) return null;

      const users = await response.json();
      if (!Array.isArray(users)) return null;

      const match = users.find(
        (item) =>
          String(item.email || "").toLowerCase() ===
          String(email || "").toLowerCase()
      );

      return match?.userID ?? match?.userId ?? null;
    } catch {
      return null;
    }
  };

  const markNotificationAsRead = async (notificationId) => {
    const token = localStorage.getItem("authToken");
    if (!token || !notificationId) return;

    try {
      const requestOptions = {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      };

      const baseUrls = [NOTIFICATIONS_BASE_URL, API_BASE_URL].filter(
        (url, index, array) => url && array.indexOf(url) === index
      );

      if (!baseUrls.includes("")) {
        baseUrls.unshift("");
      }

      let response = null;
      for (const baseUrl of baseUrls) {
        try {
          const attempt = await fetch(
            baseUrl
              ? `${baseUrl}/pharmaShelf/notifications/markAsRead/${notificationId}`
              : getNotificationsUrl(`markAsRead/${notificationId}`),
            requestOptions
          );

          response = attempt;
          if (attempt.ok) break;
        } catch {
          response = null;
        }
      }

      if (!response || !response.ok) {
        return;
      }

      setNotificationList((prev) =>
        prev.map((item) => {
          const itemId = item.notificationID ?? item.notificationId;
          return itemId === notificationId
            ? { ...item, status: "READ" }
            : item;
        })
      );
    } catch (err) {
      console.error("Mark as read failed:", err);
    }
  };

  useEffect(() => {
    if (!user) return;

    const loadNotifications = async () => {
      let targetUserId =
        user.userId ?? user.userID ?? user.userid ?? user.UserID;

      if (!targetUserId) {
        targetUserId = extractUserIdFromToken();
      }

      const userIdFromEmail = await resolveUserIdByEmail(user.email);
      if (userIdFromEmail) {
        targetUserId = userIdFromEmail;

        if (user.userId !== userIdFromEmail) {
          const patchedUser = { ...user, userId: userIdFromEmail };
          setUser(patchedUser);
          localStorage.setItem(
            "pharmaShelfUser",
            JSON.stringify(patchedUser)
          );
          return; // Exit early to prevent fetching twice
        }
      }

      if (!targetUserId) {
        setNotificationList([]);
        setNotifError("No notifications available.");
        return;
      }

      fetchNotificationsByUserId(targetUserId);
    };

    loadNotifications();
  }, [user?.email, user?.userId]);

  /* =========================
     Logout
  ========================= */
  const handleLogout = async () => {
    try {
      await authAPI.logout();
    } catch (error) {
      console.error("Logout API error:", error);
    } finally {
      setUser(null);
      localStorage.clear();
      setTimeout(() => {
        navigate("/login", { replace: true });
      }, 100);
    }
  };

  const toggleGroup = (groupLabel) => {
    setOpenSidebarGroups((prev) => ({
      ...prev,
      [groupLabel]: !prev[groupLabel],
    }));
  };

  /* =========================
     Helpers
  ========================= */
  const getRoleDisplay = (role = "") =>
    ROLE_DISPLAY_MAP[role] || "User";

  const getInitials = (value = "") => {
    if (!value) return "";
    return value
      .split(" ")
      .map((part) => part.charAt(0))
      .join("")
      .toUpperCase();
  };

  const isActive = (path) => {
    if (path === "/") return location.pathname === "/";
    return location.pathname.startsWith(path);
  };

  const unreadCount = notificationList.filter(
    (item) => String(item.status || "").toUpperCase() === "UNREAD"
  ).length;

  const getNotificationIcon = (category = "") => {
    const normalizedCategory = String(category).toUpperCase();

    if (normalizedCategory === "EXPIRY") return AlertTriangle;
    if (normalizedCategory === "STOCK") return Package;
    if (normalizedCategory === "RECALL") return XCircle;
    if (normalizedCategory === "PO") return FileText;

    return Bell;
  };

  const getRelativeTime = (createdAt) => {
    if (!createdAt) return "Just now";

    const date = new Date(createdAt);
    if (Number.isNaN(date.getTime())) return "Just now";

    const diffMs = Date.now() - date.getTime();
    const diffMinutes = Math.floor(diffMs / (1000 * 60));

    if (diffMinutes < 1) return "Just now";
    if (diffMinutes < 60)
      return `${diffMinutes} minute${diffMinutes === 1 ? "" : "s"} ago`;

    const diffHours = Math.floor(diffMinutes / 60);
    if (diffHours < 24)
      return `${diffHours} hour${diffHours === 1 ? "" : "s"} ago`;

    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} day${diffDays === 1 ? "" : "s"} ago`;
  };

  if (!user) return null;

  const displayName = user.name || user.email || "";

  const isAdmin = isAdministratorRole(user.role);

  // ✅ Filter nav items for RBAC - Aligned with backend SecurityConfig
  const visibleNavItems = LAYOUT_NAV_ITEMS.filter((item) => {
    const userRole = user?.role ? normalizeRole(user.role) : "";
    
    // Check parent item paths
    if (item.path) {
      // Admin-only paths: Users, Alert Rules, KPI Dashboard
      if ((item.path === "/users" || item.path === "/alert-rules" || item.path === "/kpi") && userRole !== "ADMINISTRATOR") {
        return false;
      }
      // Audit Log - ADMINISTRATOR or AUDITOR
      if (item.path === "/audit-log" && !["ADMINISTRATOR", "AUDITOR"].includes(userRole)) {
        return false;
      }
      // Quarantine - PHARMACIST only
      if (item.path === "/quarantine" && userRole !== "PHARMACIST") {
        return false;
      }
      // Recalls - COMPLIANCE_OFFICER only
      if (item.path === "/recalls" && userRole !== "COMPLIANCE_OFFICER") {
        return false;
      }
      // Expiry Monitoring - PHARMACIST, COMPLIANCE_OFFICER
      if (item.path === "/expiry" && !["PHARMACIST", "COMPLIANCE_OFFICER"].includes(userRole)) {
        return false;
      }
      // Stock Counts - STOREKEEPER, PROCUREMENT_OFFICER, ADMINISTRATOR
      if ((item.path === "/stock-counts" || item.path === "/reconciliation") && !["STOREKEEPER", "PROCUREMENT_OFFICER", "ADMINISTRATOR"].includes(userRole)) {
        return false;
      }
      // Reports - COMPLIANCE_OFFICER, AUDITOR, ADMINISTRATOR
      if (item.path === "/reports" && !["COMPLIANCE_OFFICER", "AUDITOR", "ADMINISTRATOR"].includes(userRole)) {
        return false;
      }
    }
    
    // For group items, filter children
    if (item.children && item.children.length > 0) {
      const visibleChildren = item.children.filter((child) => {
        const childPath = child.path;
        
        // Admin-only paths
        if ((childPath === "/users" || childPath === "/alert-rules" || childPath === "/kpi") && userRole !== "ADMINISTRATOR") {
          return false;
        }
        // Audit logs - ADMINISTRATOR or AUDITOR
        if (childPath === "/audit-log" && !["ADMINISTRATOR", "AUDITOR"].includes(userRole)) {
          return false;
        }
        // Consumption Log access
        if (childPath === "/consumption-log" && !["STOREKEEPER", "COMPLIANCE_OFFICER", "ADMINISTRATOR"].includes(userRole)) {
          return false;
        }
        
        return true;
      });
      return visibleChildren.length > 0;
    }
    
    return true;
  });

  // Logo icon
  const LogoIcon = LAYOUT_NAV_ITEMS.find(
    (item) => item.path === "/dispensing"
  )?.icon;

  /* =========================
     JSX
  ========================= */
  return (
    <div className="flex h-screen bg-gray-50">
      <style>{`
        .no-scrollbar {
          scrollbar-width: none;
          -ms-overflow-style: none;
        }
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
      `}</style>
      {/* Sidebar */}
      <aside
        className={
          `${
            isMobile
              ? `fixed inset-y-0 left-0 z-40 w-64 transform ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`
              : sidebarOpen
              ? "w-64"
              : "w-20"
          } bg-gradient-to-b from-[#3C8C85] to-[#2e5e5a] text-white transition-all duration-300 flex flex-col`
        }
      >
        {/* Logo */}
        <div className="p-6 border-b" style={{ borderColor: '#3C8C85' }}>
          <div className="flex items-center gap-3">
            <div className="bg-white rounded-lg p-2">
              {LogoIcon && (
                <LogoIcon className="size-6" style={{ color: '#3C8C85' }} />
              )}
            </div>
            {sidebarOpen && (
              <div>
                <h1 className="font-bold text-lg">
                  {LAYOUT_TEXT.APP_NAME}
                </h1>
                <p className="text-xs" style={{ color: '#7fc1bb' }}>
                  {LAYOUT_TEXT.APP_TAGLINE}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 overflow-y-auto no-scrollbar">
          <ul className="space-y-2">
            {visibleNavItems.map((item) => {
              // Check if this item has children (is a group)
              if (item.children && item.children.length > 0) {
                const isOpen = !!openSidebarGroups[item.label];
                const Icon = item.icon;

                return (
                  <li key={item.label}>
                    {/* Parent/Group Button */}
                    <button
                      onClick={() => toggleGroup(item.label)}
                      className={`w-full flex items-center justify-between gap-3 px-3 py-3 rounded-lg transition-all text-left ${
                        isOpen
                          ? "bg-[#35736e] text-[#b2dfd7]"
                          : "text-[#b2dfd7] hover:bg-[#35736e]"
                      }`}
                    >
                      <div className="flex items-center gap-3 flex-1">
                        <Icon
                          className={`size-5 ${
                            !sidebarOpen ? "mx-auto" : ""
                          }`}
                        />
                        {sidebarOpen && (
                          <span className="text-sm font-medium">
                            {item.label}
                          </span>
                        )}
                      </div>
                      {sidebarOpen && (
                        <ChevronDown
                          className={`size-4 transition-transform ${
                            isOpen ? "rotate-0" : "-rotate-90"
                          }`}
                        />
                      )}
                    </button>

                    {/* Children Items */}
                    {isOpen && (
                      <ul className="mt-1 space-y-1 ml-2 border-l-2 border-[#35736e] pl-2">
                        {item.children.map((child) => (
                          <li key={child.path}>
                            <Link
                              to={child.path}
                              className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-all text-sm ${
                                isActive(child.path)
                                  ? "bg-white text-[#3C8C85] shadow-lg"
                                  : "text-[#b2dfd7] hover:bg-[#2e5e5a]"
                              }`}
                            >
                              {sidebarOpen && (
                                <span>{child.label}</span>
                              )}
                              {!sidebarOpen && (
                                <span title={child.label}>•</span>
                              )}
                            </Link>
                          </li>
                        ))}
                      </ul>
                    )}
                  </li>
                );
              }

              // Regular item (not a group)
              const Icon = item.icon;
              return (
                <li key={item.path}>
                  <Link
                    to={item.path}
                    className={`flex items-center gap-3 px-3 py-3 rounded-lg transition-all ${
                      isActive(item.path)
                        ? "bg-white text-[#3C8C85] shadow-lg"
                        : "text-[#b2dfd7] hover:bg-[#35736e]"
                    }`}
                  >
                    <Icon
                      className={`size-5 ${
                        !sidebarOpen ? "mx-auto" : ""
                      }`}
                    />
                    {sidebarOpen && (
                      <span className="text-sm font-medium">
                        {item.label}
                      </span>
                    )}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Toggle */}
        {!isMobile && (
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-4 border-t hover:bg-[#35736e]"
            style={{ borderColor: '#3C8C85' }}
          >
            <Menu
              className={`size-5 ${
                !sidebarOpen ? "mx-auto" : ""
              }`}
            />
          </button>
        )}
      </aside>

      {isMobile && sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-30"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white border-b px-4 sm:px-6 py-4">
          <div className="flex flex-col sm:flex-row gap-4 sm:justify-between sm:items-center">
            <div className="flex items-center gap-3 w-full sm:max-w-md">
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 rounded-lg border border-gray-200 hover:bg-gray-50"
              >
                <Menu className="size-5 text-gray-600" />
              </button>

              <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-gray-400" />
              <input
                className="w-full pl-10 pr-4 py-2 border rounded-lg"
                placeholder={LAYOUT_TEXT.SEARCH_PLACEHOLDER}
              />
            </div>
            </div>

            <div className="flex items-center gap-2 sm:gap-4 justify-end">
              <div ref={notifDropdownRef} className="relative">
                <button
                  onClick={() =>
                    setShowNotifDropdown(!showNotifDropdown)
                  }
                  className="relative p-2 hover:bg-gray-100 rounded-lg"
                >
                  <Bell className="size-6 text-gray-600" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs size-5 rounded-full flex items-center justify-center">
                      {unreadCount}
                    </span>
                  )}
                </button>

                {showNotifDropdown && (
                  <div className="absolute right-0 mt-2 w-80 bg-white border rounded-lg shadow-lg overflow-hidden z-30">
                    <div className="px-4 py-3 border-b bg-gray-50">
                      <p className="text-sm font-semibold text-gray-900">
                        Notifications
                      </p>
                      <p className="text-xs text-gray-500">
                        {unreadCount} unread
                      </p>
                    </div>

                    <div className="max-h-[400px] overflow-y-auto no-scrollbar">
                      {notifError ? (
                        <div className="p-4 text-sm text-red-600">
                          {notifError}
                        </div>
                      ) : notificationList.length === 0 ? (
                        <div className="p-4 text-sm text-gray-500">
                          No notifications available.
                        </div>
                      ) : (
                        notificationList.map((notification) => {
                          const status = String(
                            notification.status || ""
                          ).toUpperCase();
                          const isUnread = status === "UNREAD";
                          const category =
                            notification.category || "GENERAL";
                          const Icon = getNotificationIcon(category);
                          const notificationId =
                            notification.notificationID ??
                            notification.notificationId;

                          return (
                            <button
                              key={notificationId}
                              type="button"
                              onClick={() => {
                                if (isUnread) {
                                  markNotificationAsRead(
                                    notificationId
                                  );
                                }
                              }}
                              className={`w-full text-left px-4 py-3 border-b last:border-b-0 hover:bg-[#e0f4f2]/60 transition-colors ${
                                isUnread ? "bg-[#e0f4f2]" : "bg-white"
                              }`}
                            >
                              <div className="flex items-start gap-3">
                                <div className="mt-0.5">
                                  <Icon className="size-4 text-gray-600" />
                                </div>

                                <div className="flex-1 min-w-0">
                                  <p
                                    className={`text-sm text-gray-900 ${
                                      isUnread
                                        ? "font-semibold"
                                        : "font-normal"
                                    }`}
                                  >
                                    {notification.message}
                                  </p>

                                  <div className="mt-1 flex items-center gap-2 text-xs text-gray-500">
                                    <span className="uppercase tracking-wide">
                                      {category}
                                    </span>
                                    <span>•</span>
                                    <span>
                                      {getRelativeTime(
                                        notification.createdAt
                                      )}
                                    </span>
                                  </div>
                                </div>

                                {isUnread && (
                                  <span className="mt-1 size-2 rounded-full" style={{ backgroundColor: '#3C8C85' }} />
                                )}
                              </div>
                            </button>
                          );
                        })
                      )}
                    </div>

                    <button
                      onClick={() => {
                        setShowNotifDropdown(false);
                        navigate("/notifications");
                      }}
                      className="w-full px-4 py-3 text-sm font-medium border-t bg-white hover:bg-[#e0f4f2]"
                      style={{ color: '#3C8C85', borderColor: '#3C8C85' }}
                    >
                      View All Notifications
                    </button>
                  </div>
                )}
              </div>

              <div ref={dropdownRef} className="relative">
                <button
                  onClick={() =>
                    setShowProfileDropdown(!showProfileDropdown)
                  }
                  className="flex items-center gap-3"
                >
                  <div className="text-right">
                    <p className="text-sm font-semibold">
                      {displayName}
                    </p>
                    <p className="text-xs text-gray-500">
                      {getRoleDisplay(user.role)}
                    </p>
                  </div>
                  <div className="size-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-semibold">
                    {getInitials(displayName)}
                  </div>
                  <ChevronDown
                    className={`size-4 transition-transform ${
                      showProfileDropdown ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {showProfileDropdown && (
                  <div className="absolute right-0 mt-2 w-64 bg-white border rounded-lg shadow-lg">
                    <div className="px-4 py-3 border-b">
                      <p className="font-semibold">
                        {displayName}
                      </p>
                      <p className="text-sm text-gray-500">
                        {user.email}
                      </p>
                    </div>

                    <button className="w-full px-4 py-2 flex gap-3 hover:bg-gray-50">
                      <User className="size-4" />
                      {LAYOUT_TEXT.MY_PROFILE}
                    </button>

                    <button className="w-full px-4 py-2 flex gap-3 hover:bg-gray-50">
                      <Settings className="size-4" />
                      {LAYOUT_TEXT.SETTINGS}
                    </button>

                    <button
                      onClick={handleLogout}
                      className="w-full px-4 py-2 flex gap-3 text-red-600 hover:bg-red-50"
                    >
                      <LogOut className="size-4" />
                      {LAYOUT_TEXT.SIGN_OUT}
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto no-scrollbar p-4 sm:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}


