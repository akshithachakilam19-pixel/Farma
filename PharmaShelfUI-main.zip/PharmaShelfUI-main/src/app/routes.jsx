import { createBrowserRouter } from "react-router-dom";
import { Navigate } from "react-router-dom";
import { Dashboard } from "./components/Dashboard";
import { ProductMaster } from "./components/ProductMaster";
import { GoodsReceipt } from "./components/GoodsReceipt";
import { Requisition } from "./components/DispensingWorkflow";
import { StaffReturns } from "./components/StaffReturns";
import { ConsumptionLog } from "./components/ConsumptionLog";
import { ExpiryMonitoring } from "./components/ExpiryMonitoring";
import { RecallManagement } from "./components/RecallManagement";
import { BatchManagement } from "./components/BatchMangement";
import { StockCounts } from "./components/StockCounts";
import { Reconciliation } from "./components/Reconciliation";
import { KPI } from "./components/KPI";
import { ReportManagement } from "./components/Reports";
import { AuditLog } from "./components/AuditLog";
import { UserManagement } from "./components/UserManagement";
import { AlertRules } from "./components/AlertRules";
import { Layout } from "./components/Layout";
import { Login } from "./components/Login";
import { Signup } from "./components/Signup";
import { NotificationsPage } from "./components/NotificationsPage";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { authAPI } from "../services/authService";

function AuthGuard({ children }) {
  return <ProtectedRoute>{children}</ProtectedRoute>;
}

function RoleBasedRoute({ children, roles = [] }) {
  return <ProtectedRoute allowedRoles={roles}>{children}</ProtectedRoute>;
}

export const router = createBrowserRouter([
  {
    path: "/login",
    element: !authAPI.isAuthenticated() ? <Login /> : <Navigate to="/" replace />,
  },
  {
    path: "/signup",
    element: !authAPI.isAuthenticated() ? <Signup /> : <Navigate to="/" replace />,
  },
  {
    path: "/",
    Component: Layout,
    children: [
      { 
        index: true, 
        element: <AuthGuard><Dashboard /></AuthGuard>
      },
      {
        path: "dashboard",
        element: <AuthGuard><Dashboard /></AuthGuard>,
      },
      {
        path: "products",
        element: <AuthGuard><ProductMaster /></AuthGuard>,
      },
      {
        path: "goods-receipt",
        element: <RoleBasedRoute roles={["PROCUREMENT_OFFICER"]}><GoodsReceipt /></RoleBasedRoute>,
      },
      {
        path: "requisition",
        element: <RoleBasedRoute roles={["PHARMACIST", "CLINICIAN"]}><Requisition /></RoleBasedRoute>,
      },
      {
        path: "dispense",
        element: <RoleBasedRoute roles={["PHARMACIST", "CLINICIAN"]}><Requisition /></RoleBasedRoute>,
      },
      {
        path: "returns",
        element: <RoleBasedRoute roles={["PHARMACIST", "CLINICIAN", "NURSE"]}><StaffReturns /></RoleBasedRoute>,
      },
      {
        path: "consumption-log",
        element: <RoleBasedRoute roles={["PHARMACIST", "COMPLIANCE_OFFICER", "STOREKEEPER", "AUDITOR"]}><ConsumptionLog /></RoleBasedRoute>,
      },
      {
        path: "expiry",
        element: <RoleBasedRoute roles={["COMPLIANCE_OFFICER"]}><ExpiryMonitoring /></RoleBasedRoute>,
      },
      {
        path: "recalls",
        element: <RoleBasedRoute roles={["PHARMACIST", "COMPLIANCE_OFFICER"]}><RecallManagement /></RoleBasedRoute>,
      },
      {
        path: "quarantine",
        element: <RoleBasedRoute roles={["PHARMACIST", "COMPLIANCE_OFFICER"]}><BatchManagement /></RoleBasedRoute>,
      },
      {
        path: "batch-management",
        element: <RoleBasedRoute roles={["COMPLIANCE_OFFICER"]}><BatchManagement /></RoleBasedRoute>,
      },
      {
        path: "stock-counts",
        element: <RoleBasedRoute roles={["STOREKEEPER"]}><StockCounts /></RoleBasedRoute>,
      },
      {
        path: "reconciliation",
        element: <RoleBasedRoute roles={["STOREKEEPER"]}><Reconciliation /></RoleBasedRoute>,
      },
      {
        path: "kpi",
        element: <RoleBasedRoute roles={["ADMINISTRATOR"]}><KPI /></RoleBasedRoute>,
      },
      {
        path: "reports",
        element: <RoleBasedRoute roles={["COMPLIANCE_OFFICER", "ADMINISTRATOR"]}><ReportManagement /></RoleBasedRoute>,
      },
      {
        path: "audit-log",
        element: <RoleBasedRoute roles={["AUDITOR"]}><AuditLog /></RoleBasedRoute>,
      },
      {
        path: "alert-rules",
        element: <RoleBasedRoute roles={["ADMINISTRATOR"]}><AlertRules /></RoleBasedRoute>,
      },
      {
        path: "users",
        element: <RoleBasedRoute roles={["ADMINISTRATOR"]}><UserManagement /></RoleBasedRoute>,
      },
      { 
        path: "notifications", 
        element: <AuthGuard><NotificationsPage /></AuthGuard>
      },
    ],
  },
]);


