import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  PillBottle,
  AlertTriangle,
  ClipboardCheck,
  BarChart3,
  BellRing,
  FileSearch,
  Users,
  Archive,
  AlertCircle,
  CheckSquare,
} from "lucide-react";
import { MODULES } from "./accessControl";

export const LAYOUT_NAV_ITEMS = [
  { path: "/", label: "Dashboard", icon: LayoutDashboard },
  {
    path: "/products",
    label: "Product Master",
    icon: Package,
    module: MODULES.PRODUCT,
  },
  {
    path: "/goods-receipt",
    label: "Goods Receipt",
    icon: ShoppingCart,
    module: MODULES.GOODS_RECEIPT,
  },
  {
    label: "Dispense & Returns",
    icon: PillBottle,
    children: [
      {
        path: "/requisition",
        label: "Requisition",
        module: MODULES.DISPENSE,
      },
      { path: "/returns", label: "Returns", module: MODULES.RETURN },
      {
        path: "/consumption-log",
        label: "Consumption Log",
        module: MODULES.KPI,
      },
    ],
  },
  {
    path: "/expiry",
    label: "Expiry Monitoring",
    icon: AlertTriangle,
    module: MODULES.EXPIRY_ALERT,
  },
  {
    path: "/quarantine",
    label: "Quarantine",
    icon: Archive,
    module: MODULES.EXPIRY_ALERT,
  },
  {
    path: "/recalls",
    label: "Recalls",
    icon: AlertCircle,
    module: MODULES.EXPIRY_ALERT,
  },
  {
    path: "/stock-counts",
    label: "Stock Counts",
    icon: ClipboardCheck,
    module: MODULES.STOCK_COUNT,
  },
  {
    path: "/reconciliation",
    label: "Reconciliation",
    icon: CheckSquare,
    module: MODULES.STOCK_COUNT,
  },
  {
    path: "/kpi",
    label: "KPI Dashboard",
    icon: BarChart3,
    module: MODULES.KPI,
  },
  {
    path: "/reports",
    label: "Reports",
    icon: BarChart3,
    module: MODULES.REPORT,
  },
  {
    path: "/audit-log",
    label: "Audit Log",
    icon: FileSearch,
    module: MODULES.AUDIT_LOG,
  },
  {
    path: "/alert-rules",
    label: "Alert Rules",
    icon: BellRing,
    module: MODULES.ALERT_RULE,
  },
  {
    path: "/users",
    label: "User Management",
    icon: Users,
    module: MODULES.USER,
  },
];

export const ROLE_DISPLAY_MAP = {
  PHARMACIST: "Pharmacist",
  PROCUREMENT_OFFICER: "Procurement Officer",
  STOREKEEPER: "Storekeeper / Inventory Clerk",
  CLINICIAN: "Clinician / Nurse",
  COMPLIANCE_OFFICER: "Compliance Officer",
  ADMINISTRATOR: "Administrator",
  AUDITOR: "Auditor",

  pharmacist: "Pharmacist",
  procurement: "Procurement Officer",
  storekeeper: "Storekeeper",
  clinician: "Clinician",
  compliance: "Compliance Officer",
  admin: "Administrator",
  auditor: "Auditor",
};

export const LAYOUT_TEXT = {
  APP_NAME: "PharmaShelf",
  APP_TAGLINE: "Pharmacy Management",
  SEARCH_PLACEHOLDER: "Search products, batches, orders...",
  MY_PROFILE: "My Profile",
  SETTINGS: "Settings",
  SIGN_OUT: "Sign Out",
};