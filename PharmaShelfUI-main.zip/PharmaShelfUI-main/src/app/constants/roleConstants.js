export const ROLE_DEFINITIONS = {
  PHARMACIST: {
    label: "Pharmacist",
    description:
      "Manages stock, dispenses medications, handles expiries",
    assignable: true,
    badgeClass: "bg-green-100 text-green-700 ring-1 ring-green-300",
  },
  PROCUREMENT_OFFICER: {
    label: "Procurement Officer",
    description:
      "Creates purchase orders and manages suppliers",
    assignable: true,
    badgeClass: "bg-orange-100 text-orange-700 ring-1 ring-orange-300",
  },
  STOREKEEPER: {
    label: "Storekeeper",
    description:
      "Handles inventory counts and stock movement",
    assignable: true,
    badgeClass: "bg-yellow-100 text-yellow-700 ring-1 ring-yellow-300",
  },
  CLINICIAN: {
    label: "Clinician",
    description:
      "Views medication availability and requests supplies",
    assignable: true,
    badgeClass: "bg-cyan-100 text-cyan-700 ring-1 ring-cyan-300",
  },
  COMPLIANCE_OFFICER: {
    label: "Compliance Officer",
    description:
      "Reviews audits, recalls, and compliance reports",
    assignable: true,
    badgeClass: "bg-purple-100 text-purple-700 ring-1 ring-purple-300",
  },
  ADMINISTRATOR: {
    label: "Administrator",
    description:
      "Manages system configuration and users",
    assignable: false,
    badgeClass: "bg-blue-100 text-blue-700 ring-1 ring-blue-300",
  },
  AUDITOR: {
    label: "Auditor",
    description:
      "Reviews immutable audit trails",
    assignable: false,
    badgeClass: "bg-red-100 text-red-700 ring-1 ring-red-300",
  },
};

// ✅ Convenience exports
export const ALL_ROLES = Object.keys(ROLE_DEFINITIONS);

export const ASSIGNABLE_ROLES = ALL_ROLES.filter(
  (role) => ROLE_DEFINITIONS[role].assignable
);
