export const MODULES = {
  DISPENSE: "DISPENSE",
  BATCH: "BATCH",
  EXPIRY_ALERT: "EXPIRY_ALERT",
  QUARANTINE: "QUARANTINE",
  RETURN: "RETURN",
  SUPPLIER: "SUPPLIER",
  PURCHASE_ORDER: "PURCHASE_ORDER",
  GOODS_RECEIPT: "GOODS_RECEIPT",
  STOCK_COUNT: "STOCK_COUNT",
  RECONCILIATION: "RECONCILIATION",
  LOCATION: "LOCATION",
  PRODUCT: "PRODUCT",
  RECALL: "RECALL",
  KPI: "KPI",
  AUDIT_LOG: "AUDIT_LOG",
  USER: "USER",
  ALERT_RULE: "ALERT_RULE",
  REPORT: "REPORT",
};

export const ROLE_MODULE_ACCESS = {
  // PHARMACIST: products, batches, dispenses, returns, expiry alerts, quarantine, recalls
  PHARMACIST: [
    MODULES.PRODUCT,
    MODULES.BATCH,
    MODULES.DISPENSE,
    MODULES.RETURN,
    MODULES.EXPIRY_ALERT,
    MODULES.QUARANTINE,
    MODULES.RECALL,
  ],
  // PROCUREMENT_OFFICER: products, batches, suppliers, purchase orders, goods receipts
  PROCUREMENT_OFFICER: [
    MODULES.PRODUCT,
    MODULES.BATCH,
    MODULES.SUPPLIER,
    MODULES.PURCHASE_ORDER,
    MODULES.GOODS_RECEIPT,
  ],
  // STOREKEEPER: products, batches, stock counts, reconciliations, location, consumption logs
  STOREKEEPER: [
    MODULES.PRODUCT,
    MODULES.BATCH,
    MODULES.STOCK_COUNT,
    MODULES.RECONCILIATION,
    MODULES.LOCATION,
    MODULES.CONSUMPTION_LOG,
  ],
  // CLINICIAN: products, batches, dispenses, returns
  CLINICIAN: [
    MODULES.PRODUCT,
    MODULES.BATCH,
    MODULES.DISPENSE,
    MODULES.RETURN,
  ],
  // COMPLIANCE_OFFICER: products, batches, dispenses, returns, consumption logs, expiry alerts, recalls, reports
  COMPLIANCE_OFFICER: [
    MODULES.PRODUCT,
    MODULES.BATCH,
    MODULES.DISPENSE,
    MODULES.RETURN,
    MODULES.CONSUMPTION_LOG,
    MODULES.EXPIRY_ALERT,
    MODULES.RECALL,
    MODULES.REPORT,
  ],
  // ADMINISTRATOR: users, products, batches, suppliers, purchase orders, goods receipts, alert rules, KPI
  ADMINISTRATOR: [
    MODULES.USER,
    MODULES.PRODUCT,
    MODULES.BATCH,
    MODULES.SUPPLIER,
    MODULES.PURCHASE_ORDER,
    MODULES.GOODS_RECEIPT,
    MODULES.ALERT_RULE,
    MODULES.KPI,
  ],
  // AUDITOR: products, batches, audit logs, reports, KPI
  AUDITOR: [
    MODULES.PRODUCT,
    MODULES.BATCH,
    MODULES.AUDIT_LOG,
    MODULES.REPORT,
    MODULES.KPI,
  ],
};

const ROLE_ALIASES = {
  pharmacist: "PHARMACIST",
  procurement_officer: "PROCUREMENT_OFFICER",
  procurement: "PROCUREMENT_OFFICER",
  storekeeper: "STOREKEEPER",
  clinician: "CLINICIAN",
  compliance_officer: "COMPLIANCE_OFFICER",
  compliance: "COMPLIANCE_OFFICER",
  administrator: "ADMINISTRATOR",
  adminstrator: "ADMINISTRATOR",
  admin: "ADMINISTRATOR",
  auditor: "AUDITOR",
};

export const normalizeRole = (role) => {
  const value = String(role || "").trim();
  if (!value) return "";

  // Remove ROLE_ prefix if present (from Spring Security)
  let cleanedRole = value.startsWith("ROLE_") 
    ? value.substring(5) 
    : value;

  // Normalize to uppercase and replace spaces/hyphens with underscores
  const canonical = cleanedRole
    .replace(/[\s-]+/g, "_")
    .toUpperCase();

  // Check if the normalized role exists in our module access control
  if (ROLE_MODULE_ACCESS[canonical]) return canonical;
  
  // Check alias mappings
  const alias = ROLE_ALIASES[cleanedRole.toLowerCase()] ||
    ROLE_ALIASES[canonical.toLowerCase()];
  
  return alias || canonical;
};

export const getCurrentUserRole = () => {
  try {
    const raw = localStorage.getItem("pharmaShelfUser");
    if (!raw) return "";
    const parsed = JSON.parse(raw);
    return normalizeRole(parsed?.role);
  } catch {
    return "";
  }
};

export const canAccessModule = (role, moduleOrModules) => {
  if (!moduleOrModules) return true;

  const normalizedRole = normalizeRole(role);
  const allowed = ROLE_MODULE_ACCESS[normalizedRole] || [];
  const modules = Array.isArray(moduleOrModules)
    ? moduleOrModules
    : [moduleOrModules];

  return modules.some((m) => allowed.includes(m));
};

// Role-specific action permissions aligned with backend @PreAuthorize annotations
export const ROLE_ACTION_PERMISSIONS = {
  PRODUCT: {
    CREATE: ["ADMINISTRATOR"],
    READ: ["ADMINISTRATOR", "PHARMACIST", "PROCUREMENT_OFFICER", "STOREKEEPER", "CLINICIAN", "COMPLIANCE_OFFICER", "AUDITOR"],
    UPDATE: ["ADMINISTRATOR"],
    DELETE: ["ADMINISTRATOR"],
  },
  BATCH: {
    CREATE: ["ADMINISTRATOR"],
    READ: ["ADMINISTRATOR", "PHARMACIST", "PROCUREMENT_OFFICER", "STOREKEEPER", "CLINICIAN", "COMPLIANCE_OFFICER", "AUDITOR"],
    UPDATE: ["ADMINISTRATOR"],
    DELETE: ["ADMINISTRATOR"],
  },
  DISPENSE: {
    CREATE: ["PHARMACIST", "COMPLIANCE_OFFICER"],
    READ: ["PHARMACIST", "COMPLIANCE_OFFICER"],
    UPDATE: ["PHARMACIST", "COMPLIANCE_OFFICER"],
    DELETE: ["PHARMACIST", "COMPLIANCE_OFFICER"],
  },
  RETURN: {
    CREATE: ["PHARMACIST", "COMPLIANCE_OFFICER"],
    READ: ["PHARMACIST", "COMPLIANCE_OFFICER"],
    UPDATE: ["PHARMACIST", "COMPLIANCE_OFFICER"],
    DELETE: ["PHARMACIST", "COMPLIANCE_OFFICER"],
  },
  CONSUMPTION_LOG: {
    CREATE: ["STOREKEEPER", "COMPLIANCE_OFFICER"],
    READ: ["STOREKEEPER", "COMPLIANCE_OFFICER"],
    UPDATE: ["COMPLIANCE_OFFICER"],
    DELETE: ["COMPLIANCE_OFFICER"],
  },
  EXPIRY_ALERT: {
    CREATE: ["COMPLIANCE_OFFICER"],
    READ: ["PHARMACIST", "COMPLIANCE_OFFICER"],
    UPDATE: ["COMPLIANCE_OFFICER"],
    DELETE: ["COMPLIANCE_OFFICER"],
  },
  QUARANTINE: {
    CREATE: ["PHARMACIST"],
    READ: ["PHARMACIST"],
    UPDATE: ["PHARMACIST"],
    DELETE: ["PHARMACIST"],
  },
  RECALL: {
    CREATE: ["COMPLIANCE_OFFICER"],
    READ: ["COMPLIANCE_OFFICER"],
    UPDATE: ["COMPLIANCE_OFFICER"],
    DELETE: ["COMPLIANCE_OFFICER"],
  },
  STOCK_COUNT: {
    CREATE: ["STOREKEEPER"],
    READ: ["STOREKEEPER"],
    UPDATE: ["STOREKEEPER"],
    DELETE: ["STOREKEEPER"],
  },
  RECONCILIATION: {
    CREATE: ["STOREKEEPER"],
    READ: ["STOREKEEPER"],
    UPDATE: ["STOREKEEPER"],
    DELETE: ["STOREKEEPER"],
  },
  GOODSRECEIPT: {
    CREATE: ["ADMINISTRATOR", "PROCUREMENT_OFFICER"],
    READ: ["ADMINISTRATOR", "PROCUREMENT_OFFICER"],
    UPDATE: ["ADMINISTRATOR", "PROCUREMENT_OFFICER"],
    DELETE: ["ADMINISTRATOR", "PROCUREMENT_OFFICER"],
  },
  PURCHASE_ORDER: {
    CREATE: ["ADMINISTRATOR", "PROCUREMENT_OFFICER"],
    READ: ["ADMINISTRATOR", "PROCUREMENT_OFFICER"],
    UPDATE: ["ADMINISTRATOR", "PROCUREMENT_OFFICER"],
    DELETE: ["ADMINISTRATOR", "PROCUREMENT_OFFICER"],
  },
  SUPPLIER: {
    CREATE: ["ADMINISTRATOR", "PROCUREMENT_OFFICER"],
    READ: ["ADMINISTRATOR", "PROCUREMENT_OFFICER"],
    UPDATE: ["ADMINISTRATOR", "PROCUREMENT_OFFICER"],
    DELETE: ["ADMINISTRATOR", "PROCUREMENT_OFFICER"],
  },
  AUDIT_LOG: {
    READ: ["ADMINISTRATOR", "AUDITOR"],
  },
  KPI: {
    READ: ["ADMINISTRATOR"],
  },
  REPORT: {
    READ: ["COMPLIANCE_OFFICER"],
  },
  ALERT_RULE: {
    CREATE: ["ADMINISTRATOR"],
    READ: ["ADMINISTRATOR"],
    UPDATE: ["ADMINISTRATOR"],
    DELETE: ["ADMINISTRATOR"],
  },
  NOTIFICATION: {
    READ: ["ADMINISTRATOR", "PHARMACIST", "STOREKEEPER", "PROCUREMENT_OFFICER", "COMPLIANCE_OFFICER", "CLINICIAN", "AUDITOR"],
  },
  USER: {
    CREATE: ["ADMINISTRATOR"],
    READ: ["ADMINISTRATOR"],
    UPDATE: ["ADMINISTRATOR"],
    DELETE: ["ADMINISTRATOR"],
  },
};

export const canPerformAction = (role, resource, action) => {
  const normalizedRole = normalizeRole(role);
  const permissions = ROLE_ACTION_PERMISSIONS[resource];
  
  if (!permissions) return false;
  
  const allowedRoles = permissions[action];
  if (!allowedRoles) return false;
  
  return allowedRoles.includes(normalizedRole);
};
