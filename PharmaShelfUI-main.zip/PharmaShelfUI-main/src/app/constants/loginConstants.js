export const LOGIN_CONSTANTS = {
  APP_NAME: "PharmaShelf",
  APP_TAGLINE: "Pharmacy Management System",

  TITLE: "Welcome Back",
  SUBTITLE: "Sign in to access your pharmacy dashboard",

  EMAIL_LABEL: "Email Address",
  EMAIL_PLACEHOLDER: "your.email@hospital.com",

  PASSWORD_LABEL: "Password",
  PASSWORD_PLACEHOLDER: "Enter your password",

  REMEMBER_ME: "Remember me",
  FORGOT_PASSWORD: "Forgot Password?",

  SIGN_IN: "Sign In",
  SIGNING_IN: "Signing In...",

  FEATURES: [
    {
      title: "Expiry Monitoring",
      description:
        "Track medication expiry dates and reduce wastage",
    },
    {
      title: "Batch Tracking",
      description:
        "Complete traceability from receipt to dispensing",
    },
    {
      title: "Compliance Ready",
      description:
        "Audit trails and regulatory reporting built-in",
    },
  ],
};
