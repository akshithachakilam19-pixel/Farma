export const signupRoles = [
  { value: '', label: 'Select Role' },
  { value: 'PHARMACIST', label: 'Pharmacist' },
  { value: 'PROCUREMENT_OFFICER', label: 'Procurement Officer' },
  { value: 'STOREKEEPER', label: 'Storekeeper' },
  { value: 'CLINICIAN', label: 'Clinician' },
  { value: 'COMPLIANCE_OFFICER', label: 'Compliance Officer' },
  { value: 'ADMINISTRATOR', label: 'Administrator' },
  { value: 'AUDITOR', label: 'Auditor' }
]

export const signupText = {
  pageTitle: 'Create Account',
  pageSubtitle: 'Start managing inventory, recalls, and dispensing from one place.',
  nameLabel: 'Name',
  namePlaceholder: 'Enter your full name',
  emailLabel: 'Email Address',
  emailPlaceholder: 'Enter your email',
  phoneLabel: 'Phone Number',
  phonePlaceholder: 'Enter your phone number',
  roleLabel: 'Role',
  passwordLabel: 'Password',
  passwordPlaceholder: 'Create a strong password',
  confirmPasswordLabel: 'Confirm Password',
  confirmPasswordPlaceholder: 'Confirm your password',
  signupButton: 'Sign Up',
  switchToLoginText: 'Already have an account?',
  loginButtonText: 'Login',
  signupSuccess: 'Signup successful! User ID: ',
  passwordMismatch: 'Passwords do not match',
  signupFailedPrefix: 'Signup failed: ',
  errorPrefix: 'Error: '
}
